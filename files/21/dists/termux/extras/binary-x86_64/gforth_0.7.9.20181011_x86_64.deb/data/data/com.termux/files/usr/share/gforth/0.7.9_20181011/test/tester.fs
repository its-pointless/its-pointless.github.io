\ drop-in replacement for John Hayes' tester

\ This file is in the public domain. NO WARRANTY.
\ Note licensing for ttester.fs

S" ./ttester.fs" INCLUDED

warnings off
: { T{ ;
warnings on

: } }T ;

HEX
