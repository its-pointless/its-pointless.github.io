\ This file has been generated using SWIG and fsi,
\ and is already platform dependent, search for the corresponding
\ fsi-file to compile it where no one has compiled it before ;)
\ Forth systems have their own own dynamic loader and don't need addional C-Code.
\ That's why this file will just print normal forth-code once compiled
\ and can be used directly with include or require.
\ As all comments are stripped during the compilation, please
\ insert the copyright notice of the original file here.

\ ----===< int constants ===>-----
#1	constant __gl3_h_
#1	constant GL_GLES_PROTOTYPES
#1	constant GL_ES_VERSION_2_0
#256	constant GL_DEPTH_BUFFER_BIT
#1024	constant GL_STENCIL_BUFFER_BIT
#16384	constant GL_COLOR_BUFFER_BIT
#0	constant GL_FALSE
#1	constant GL_TRUE
#0	constant GL_POINTS
#1	constant GL_LINES
#2	constant GL_LINE_LOOP
#3	constant GL_LINE_STRIP
#4	constant GL_TRIANGLES
#5	constant GL_TRIANGLE_STRIP
#6	constant GL_TRIANGLE_FAN
#0	constant GL_ZERO
#1	constant GL_ONE
#768	constant GL_SRC_COLOR
#769	constant GL_ONE_MINUS_SRC_COLOR
#770	constant GL_SRC_ALPHA
#771	constant GL_ONE_MINUS_SRC_ALPHA
#772	constant GL_DST_ALPHA
#773	constant GL_ONE_MINUS_DST_ALPHA
#774	constant GL_DST_COLOR
#775	constant GL_ONE_MINUS_DST_COLOR
#776	constant GL_SRC_ALPHA_SATURATE
#32774	constant GL_FUNC_ADD
#32777	constant GL_BLEND_EQUATION
#32777	constant GL_BLEND_EQUATION_RGB
#34877	constant GL_BLEND_EQUATION_ALPHA
#32778	constant GL_FUNC_SUBTRACT
#32779	constant GL_FUNC_REVERSE_SUBTRACT
#32968	constant GL_BLEND_DST_RGB
#32969	constant GL_BLEND_SRC_RGB
#32970	constant GL_BLEND_DST_ALPHA
#32971	constant GL_BLEND_SRC_ALPHA
#32769	constant GL_CONSTANT_COLOR
#32770	constant GL_ONE_MINUS_CONSTANT_COLOR
#32771	constant GL_CONSTANT_ALPHA
#32772	constant GL_ONE_MINUS_CONSTANT_ALPHA
#32773	constant GL_BLEND_COLOR
#34962	constant GL_ARRAY_BUFFER
#34963	constant GL_ELEMENT_ARRAY_BUFFER
#34964	constant GL_ARRAY_BUFFER_BINDING
#34965	constant GL_ELEMENT_ARRAY_BUFFER_BINDING
#35040	constant GL_STREAM_DRAW
#35044	constant GL_STATIC_DRAW
#35048	constant GL_DYNAMIC_DRAW
#34660	constant GL_BUFFER_SIZE
#34661	constant GL_BUFFER_USAGE
#34342	constant GL_CURRENT_VERTEX_ATTRIB
#1028	constant GL_FRONT
#1029	constant GL_BACK
#1032	constant GL_FRONT_AND_BACK
#3553	constant GL_TEXTURE_2D
#2884	constant GL_CULL_FACE
#3042	constant GL_BLEND
#3024	constant GL_DITHER
#2960	constant GL_STENCIL_TEST
#2929	constant GL_DEPTH_TEST
#3089	constant GL_SCISSOR_TEST
#32823	constant GL_POLYGON_OFFSET_FILL
#32926	constant GL_SAMPLE_ALPHA_TO_COVERAGE
#32928	constant GL_SAMPLE_COVERAGE
#0	constant GL_NO_ERROR
#1280	constant GL_INVALID_ENUM
#1281	constant GL_INVALID_VALUE
#1282	constant GL_INVALID_OPERATION
#1285	constant GL_OUT_OF_MEMORY
#2304	constant GL_CW
#2305	constant GL_CCW
#2849	constant GL_LINE_WIDTH
#33901	constant GL_ALIASED_POINT_SIZE_RANGE
#33902	constant GL_ALIASED_LINE_WIDTH_RANGE
#2885	constant GL_CULL_FACE_MODE
#2886	constant GL_FRONT_FACE
#2928	constant GL_DEPTH_RANGE
#2930	constant GL_DEPTH_WRITEMASK
#2931	constant GL_DEPTH_CLEAR_VALUE
#2932	constant GL_DEPTH_FUNC
#2961	constant GL_STENCIL_CLEAR_VALUE
#2962	constant GL_STENCIL_FUNC
#2964	constant GL_STENCIL_FAIL
#2965	constant GL_STENCIL_PASS_DEPTH_FAIL
#2966	constant GL_STENCIL_PASS_DEPTH_PASS
#2967	constant GL_STENCIL_REF
#2963	constant GL_STENCIL_VALUE_MASK
#2968	constant GL_STENCIL_WRITEMASK
#34816	constant GL_STENCIL_BACK_FUNC
#34817	constant GL_STENCIL_BACK_FAIL
#34818	constant GL_STENCIL_BACK_PASS_DEPTH_FAIL
#34819	constant GL_STENCIL_BACK_PASS_DEPTH_PASS
#36003	constant GL_STENCIL_BACK_REF
#36004	constant GL_STENCIL_BACK_VALUE_MASK
#36005	constant GL_STENCIL_BACK_WRITEMASK
#2978	constant GL_VIEWPORT
#3088	constant GL_SCISSOR_BOX
#3106	constant GL_COLOR_CLEAR_VALUE
#3107	constant GL_COLOR_WRITEMASK
#3317	constant GL_UNPACK_ALIGNMENT
#3333	constant GL_PACK_ALIGNMENT
#3379	constant GL_MAX_TEXTURE_SIZE
#3386	constant GL_MAX_VIEWPORT_DIMS
#3408	constant GL_SUBPIXEL_BITS
#3410	constant GL_RED_BITS
#3411	constant GL_GREEN_BITS
#3412	constant GL_BLUE_BITS
#3413	constant GL_ALPHA_BITS
#3414	constant GL_DEPTH_BITS
#3415	constant GL_STENCIL_BITS
#10752	constant GL_POLYGON_OFFSET_UNITS
#32824	constant GL_POLYGON_OFFSET_FACTOR
#32873	constant GL_TEXTURE_BINDING_2D
#32936	constant GL_SAMPLE_BUFFERS
#32937	constant GL_SAMPLES
#32938	constant GL_SAMPLE_COVERAGE_VALUE
#32939	constant GL_SAMPLE_COVERAGE_INVERT
#34466	constant GL_NUM_COMPRESSED_TEXTURE_FORMATS
#34467	constant GL_COMPRESSED_TEXTURE_FORMATS
#4352	constant GL_DONT_CARE
#4353	constant GL_FASTEST
#4354	constant GL_NICEST
#33170	constant GL_GENERATE_MIPMAP_HINT
#5120	constant GL_BYTE
#5121	constant GL_UNSIGNED_BYTE
#5122	constant GL_SHORT
#5123	constant GL_UNSIGNED_SHORT
#5124	constant GL_INT
#5125	constant GL_UNSIGNED_INT
#5126	constant GL_FLOAT
#5132	constant GL_FIXED
#6402	constant GL_DEPTH_COMPONENT
#6406	constant GL_ALPHA
#6407	constant GL_RGB
#6408	constant GL_RGBA
#6409	constant GL_LUMINANCE
#6410	constant GL_LUMINANCE_ALPHA
#32819	constant GL_UNSIGNED_SHORT_4_4_4_4
#32820	constant GL_UNSIGNED_SHORT_5_5_5_1
#33635	constant GL_UNSIGNED_SHORT_5_6_5
#35632	constant GL_FRAGMENT_SHADER
#35633	constant GL_VERTEX_SHADER
#34921	constant GL_MAX_VERTEX_ATTRIBS
#36347	constant GL_MAX_VERTEX_UNIFORM_VECTORS
#36348	constant GL_MAX_VARYING_VECTORS
#35661	constant GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS
#35660	constant GL_MAX_VERTEX_TEXTURE_IMAGE_UNITS
#34930	constant GL_MAX_TEXTURE_IMAGE_UNITS
#36349	constant GL_MAX_FRAGMENT_UNIFORM_VECTORS
#35663	constant GL_SHADER_TYPE
#35712	constant GL_DELETE_STATUS
#35714	constant GL_LINK_STATUS
#35715	constant GL_VALIDATE_STATUS
#35717	constant GL_ATTACHED_SHADERS
#35718	constant GL_ACTIVE_UNIFORMS
#35719	constant GL_ACTIVE_UNIFORM_MAX_LENGTH
#35721	constant GL_ACTIVE_ATTRIBUTES
#35722	constant GL_ACTIVE_ATTRIBUTE_MAX_LENGTH
#35724	constant GL_SHADING_LANGUAGE_VERSION
#35725	constant GL_CURRENT_PROGRAM
#512	constant GL_NEVER
#513	constant GL_LESS
#514	constant GL_EQUAL
#515	constant GL_LEQUAL
#516	constant GL_GREATER
#517	constant GL_NOTEQUAL
#518	constant GL_GEQUAL
#519	constant GL_ALWAYS
#7680	constant GL_KEEP
#7681	constant GL_REPLACE
#7682	constant GL_INCR
#7683	constant GL_DECR
#5386	constant GL_INVERT
#34055	constant GL_INCR_WRAP
#34056	constant GL_DECR_WRAP
#7936	constant GL_VENDOR
#7937	constant GL_RENDERER
#7938	constant GL_VERSION
#7939	constant GL_EXTENSIONS
#9728	constant GL_NEAREST
#9729	constant GL_LINEAR
#9984	constant GL_NEAREST_MIPMAP_NEAREST
#9985	constant GL_LINEAR_MIPMAP_NEAREST
#9986	constant GL_NEAREST_MIPMAP_LINEAR
#9987	constant GL_LINEAR_MIPMAP_LINEAR
#10240	constant GL_TEXTURE_MAG_FILTER
#10241	constant GL_TEXTURE_MIN_FILTER
#10242	constant GL_TEXTURE_WRAP_S
#10243	constant GL_TEXTURE_WRAP_T
#5890	constant GL_TEXTURE
#34067	constant GL_TEXTURE_CUBE_MAP
#34068	constant GL_TEXTURE_BINDING_CUBE_MAP
#34069	constant GL_TEXTURE_CUBE_MAP_POSITIVE_X
#34070	constant GL_TEXTURE_CUBE_MAP_NEGATIVE_X
#34071	constant GL_TEXTURE_CUBE_MAP_POSITIVE_Y
#34072	constant GL_TEXTURE_CUBE_MAP_NEGATIVE_Y
#34073	constant GL_TEXTURE_CUBE_MAP_POSITIVE_Z
#34074	constant GL_TEXTURE_CUBE_MAP_NEGATIVE_Z
#34076	constant GL_MAX_CUBE_MAP_TEXTURE_SIZE
#33984	constant GL_TEXTURE0
#33985	constant GL_TEXTURE1
#33986	constant GL_TEXTURE2
#33987	constant GL_TEXTURE3
#33988	constant GL_TEXTURE4
#33989	constant GL_TEXTURE5
#33990	constant GL_TEXTURE6
#33991	constant GL_TEXTURE7
#33992	constant GL_TEXTURE8
#33993	constant GL_TEXTURE9
#33994	constant GL_TEXTURE10
#33995	constant GL_TEXTURE11
#33996	constant GL_TEXTURE12
#33997	constant GL_TEXTURE13
#33998	constant GL_TEXTURE14
#33999	constant GL_TEXTURE15
#34000	constant GL_TEXTURE16
#34001	constant GL_TEXTURE17
#34002	constant GL_TEXTURE18
#34003	constant GL_TEXTURE19
#34004	constant GL_TEXTURE20
#34005	constant GL_TEXTURE21
#34006	constant GL_TEXTURE22
#34007	constant GL_TEXTURE23
#34008	constant GL_TEXTURE24
#34009	constant GL_TEXTURE25
#34010	constant GL_TEXTURE26
#34011	constant GL_TEXTURE27
#34012	constant GL_TEXTURE28
#34013	constant GL_TEXTURE29
#34014	constant GL_TEXTURE30
#34015	constant GL_TEXTURE31
#34016	constant GL_ACTIVE_TEXTURE
#10497	constant GL_REPEAT
#33071	constant GL_CLAMP_TO_EDGE
#33648	constant GL_MIRRORED_REPEAT
#35664	constant GL_FLOAT_VEC2
#35665	constant GL_FLOAT_VEC3
#35666	constant GL_FLOAT_VEC4
#35667	constant GL_INT_VEC2
#35668	constant GL_INT_VEC3
#35669	constant GL_INT_VEC4
#35670	constant GL_BOOL
#35671	constant GL_BOOL_VEC2
#35672	constant GL_BOOL_VEC3
#35673	constant GL_BOOL_VEC4
#35674	constant GL_FLOAT_MAT2
#35675	constant GL_FLOAT_MAT3
#35676	constant GL_FLOAT_MAT4
#35678	constant GL_SAMPLER_2D
#35680	constant GL_SAMPLER_CUBE
#34338	constant GL_VERTEX_ATTRIB_ARRAY_ENABLED
#34339	constant GL_VERTEX_ATTRIB_ARRAY_SIZE
#34340	constant GL_VERTEX_ATTRIB_ARRAY_STRIDE
#34341	constant GL_VERTEX_ATTRIB_ARRAY_TYPE
#34922	constant GL_VERTEX_ATTRIB_ARRAY_NORMALIZED
#34373	constant GL_VERTEX_ATTRIB_ARRAY_POINTER
#34975	constant GL_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING
#35738	constant GL_IMPLEMENTATION_COLOR_READ_TYPE
#35739	constant GL_IMPLEMENTATION_COLOR_READ_FORMAT
#35713	constant GL_COMPILE_STATUS
#35716	constant GL_INFO_LOG_LENGTH
#35720	constant GL_SHADER_SOURCE_LENGTH
#36346	constant GL_SHADER_COMPILER
#36344	constant GL_SHADER_BINARY_FORMATS
#36345	constant GL_NUM_SHADER_BINARY_FORMATS
#36336	constant GL_LOW_FLOAT
#36337	constant GL_MEDIUM_FLOAT
#36338	constant GL_HIGH_FLOAT
#36339	constant GL_LOW_INT
#36340	constant GL_MEDIUM_INT
#36341	constant GL_HIGH_INT
#36160	constant GL_FRAMEBUFFER
#36161	constant GL_RENDERBUFFER
#32854	constant GL_RGBA4
#32855	constant GL_RGB5_A1
#36194	constant GL_RGB565
#33189	constant GL_DEPTH_COMPONENT16
#36168	constant GL_STENCIL_INDEX8
#36162	constant GL_RENDERBUFFER_WIDTH
#36163	constant GL_RENDERBUFFER_HEIGHT
#36164	constant GL_RENDERBUFFER_INTERNAL_FORMAT
#36176	constant GL_RENDERBUFFER_RED_SIZE
#36177	constant GL_RENDERBUFFER_GREEN_SIZE
#36178	constant GL_RENDERBUFFER_BLUE_SIZE
#36179	constant GL_RENDERBUFFER_ALPHA_SIZE
#36180	constant GL_RENDERBUFFER_DEPTH_SIZE
#36181	constant GL_RENDERBUFFER_STENCIL_SIZE
#36048	constant GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE
#36049	constant GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME
#36050	constant GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL
#36051	constant GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE
#36064	constant GL_COLOR_ATTACHMENT0
#36096	constant GL_DEPTH_ATTACHMENT
#36128	constant GL_STENCIL_ATTACHMENT
#0	constant GL_NONE
#36053	constant GL_FRAMEBUFFER_COMPLETE
#36054	constant GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT
#36055	constant GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT
#36057	constant GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS
#36061	constant GL_FRAMEBUFFER_UNSUPPORTED
#36006	constant GL_FRAMEBUFFER_BINDING
#36007	constant GL_RENDERBUFFER_BINDING
#34024	constant GL_MAX_RENDERBUFFER_SIZE
#1286	constant GL_INVALID_FRAMEBUFFER_OPERATION
#1	constant GL_ES_VERSION_3_0
#3074	constant GL_READ_BUFFER
#3314	constant GL_UNPACK_ROW_LENGTH
#3315	constant GL_UNPACK_SKIP_ROWS
#3316	constant GL_UNPACK_SKIP_PIXELS
#3330	constant GL_PACK_ROW_LENGTH
#3331	constant GL_PACK_SKIP_ROWS
#3332	constant GL_PACK_SKIP_PIXELS
#6144	constant GL_COLOR
#6145	constant GL_DEPTH
#6146	constant GL_STENCIL
#6403	constant GL_RED
#32849	constant GL_RGB8
#32856	constant GL_RGBA8
#32857	constant GL_RGB10_A2
#32874	constant GL_TEXTURE_BINDING_3D
#32877	constant GL_UNPACK_SKIP_IMAGES
#32878	constant GL_UNPACK_IMAGE_HEIGHT
#32879	constant GL_TEXTURE_3D
#32882	constant GL_TEXTURE_WRAP_R
#32883	constant GL_MAX_3D_TEXTURE_SIZE
#33640	constant GL_UNSIGNED_INT_2_10_10_10_REV
#33000	constant GL_MAX_ELEMENTS_VERTICES
#33001	constant GL_MAX_ELEMENTS_INDICES
#33082	constant GL_TEXTURE_MIN_LOD
#33083	constant GL_TEXTURE_MAX_LOD
#33084	constant GL_TEXTURE_BASE_LEVEL
#33085	constant GL_TEXTURE_MAX_LEVEL
#32775	constant GL_MIN
#32776	constant GL_MAX
#33190	constant GL_DEPTH_COMPONENT24
#34045	constant GL_MAX_TEXTURE_LOD_BIAS
#34892	constant GL_TEXTURE_COMPARE_MODE
#34893	constant GL_TEXTURE_COMPARE_FUNC
#34917	constant GL_CURRENT_QUERY
#34918	constant GL_QUERY_RESULT
#34919	constant GL_QUERY_RESULT_AVAILABLE
#35004	constant GL_BUFFER_MAPPED
#35005	constant GL_BUFFER_MAP_POINTER
#35041	constant GL_STREAM_READ
#35042	constant GL_STREAM_COPY
#35045	constant GL_STATIC_READ
#35046	constant GL_STATIC_COPY
#35049	constant GL_DYNAMIC_READ
#35050	constant GL_DYNAMIC_COPY
#34852	constant GL_MAX_DRAW_BUFFERS
#34853	constant GL_DRAW_BUFFER0
#34854	constant GL_DRAW_BUFFER1
#34855	constant GL_DRAW_BUFFER2
#34856	constant GL_DRAW_BUFFER3
#34857	constant GL_DRAW_BUFFER4
#34858	constant GL_DRAW_BUFFER5
#34859	constant GL_DRAW_BUFFER6
#34860	constant GL_DRAW_BUFFER7
#34861	constant GL_DRAW_BUFFER8
#34862	constant GL_DRAW_BUFFER9
#34863	constant GL_DRAW_BUFFER10
#34864	constant GL_DRAW_BUFFER11
#34865	constant GL_DRAW_BUFFER12
#34866	constant GL_DRAW_BUFFER13
#34867	constant GL_DRAW_BUFFER14
#34868	constant GL_DRAW_BUFFER15
#35657	constant GL_MAX_FRAGMENT_UNIFORM_COMPONENTS
#35658	constant GL_MAX_VERTEX_UNIFORM_COMPONENTS
#35679	constant GL_SAMPLER_3D
#35682	constant GL_SAMPLER_2D_SHADOW
#35723	constant GL_FRAGMENT_SHADER_DERIVATIVE_HINT
#35051	constant GL_PIXEL_PACK_BUFFER
#35052	constant GL_PIXEL_UNPACK_BUFFER
#35053	constant GL_PIXEL_PACK_BUFFER_BINDING
#35055	constant GL_PIXEL_UNPACK_BUFFER_BINDING
#35685	constant GL_FLOAT_MAT2x3
#35686	constant GL_FLOAT_MAT2x4
#35687	constant GL_FLOAT_MAT3x2
#35688	constant GL_FLOAT_MAT3x4
#35689	constant GL_FLOAT_MAT4x2
#35690	constant GL_FLOAT_MAT4x3
#35904	constant GL_SRGB
#35905	constant GL_SRGB8
#35907	constant GL_SRGB8_ALPHA8
#34894	constant GL_COMPARE_REF_TO_TEXTURE
#33307	constant GL_MAJOR_VERSION
#33308	constant GL_MINOR_VERSION
#33309	constant GL_NUM_EXTENSIONS
#34836	constant GL_RGBA32F
#34837	constant GL_RGB32F
#34842	constant GL_RGBA16F
#34843	constant GL_RGB16F
#35069	constant GL_VERTEX_ATTRIB_ARRAY_INTEGER
#35071	constant GL_MAX_ARRAY_TEXTURE_LAYERS
#35076	constant GL_MIN_PROGRAM_TEXEL_OFFSET
#35077	constant GL_MAX_PROGRAM_TEXEL_OFFSET
#35659	constant GL_MAX_VARYING_COMPONENTS
#35866	constant GL_TEXTURE_2D_ARRAY
#35869	constant GL_TEXTURE_BINDING_2D_ARRAY
#35898	constant GL_R11F_G11F_B10F
#35899	constant GL_UNSIGNED_INT_10F_11F_11F_REV
#35901	constant GL_RGB9_E5
#35902	constant GL_UNSIGNED_INT_5_9_9_9_REV
#35958	constant GL_TRANSFORM_FEEDBACK_VARYING_MAX_LENGTH
#35967	constant GL_TRANSFORM_FEEDBACK_BUFFER_MODE
#35968	constant GL_MAX_TRANSFORM_FEEDBACK_SEPARATE_COMPONENTS
#35971	constant GL_TRANSFORM_FEEDBACK_VARYINGS
#35972	constant GL_TRANSFORM_FEEDBACK_BUFFER_START
#35973	constant GL_TRANSFORM_FEEDBACK_BUFFER_SIZE
#35976	constant GL_TRANSFORM_FEEDBACK_PRIMITIVES_WRITTEN
#35977	constant GL_RASTERIZER_DISCARD
#35978	constant GL_MAX_TRANSFORM_FEEDBACK_INTERLEAVED_COMPONENTS
#35979	constant GL_MAX_TRANSFORM_FEEDBACK_SEPARATE_ATTRIBS
#35980	constant GL_INTERLEAVED_ATTRIBS
#35981	constant GL_SEPARATE_ATTRIBS
#35982	constant GL_TRANSFORM_FEEDBACK_BUFFER
#35983	constant GL_TRANSFORM_FEEDBACK_BUFFER_BINDING
#36208	constant GL_RGBA32UI
#36209	constant GL_RGB32UI
#36214	constant GL_RGBA16UI
#36215	constant GL_RGB16UI
#36220	constant GL_RGBA8UI
#36221	constant GL_RGB8UI
#36226	constant GL_RGBA32I
#36227	constant GL_RGB32I
#36232	constant GL_RGBA16I
#36233	constant GL_RGB16I
#36238	constant GL_RGBA8I
#36239	constant GL_RGB8I
#36244	constant GL_RED_INTEGER
#36248	constant GL_RGB_INTEGER
#36249	constant GL_RGBA_INTEGER
#36289	constant GL_SAMPLER_2D_ARRAY
#36292	constant GL_SAMPLER_2D_ARRAY_SHADOW
#36293	constant GL_SAMPLER_CUBE_SHADOW
#36294	constant GL_UNSIGNED_INT_VEC2
#36295	constant GL_UNSIGNED_INT_VEC3
#36296	constant GL_UNSIGNED_INT_VEC4
#36298	constant GL_INT_SAMPLER_2D
#36299	constant GL_INT_SAMPLER_3D
#36300	constant GL_INT_SAMPLER_CUBE
#36303	constant GL_INT_SAMPLER_2D_ARRAY
#36306	constant GL_UNSIGNED_INT_SAMPLER_2D
#36307	constant GL_UNSIGNED_INT_SAMPLER_3D
#36308	constant GL_UNSIGNED_INT_SAMPLER_CUBE
#36311	constant GL_UNSIGNED_INT_SAMPLER_2D_ARRAY
#37151	constant GL_BUFFER_ACCESS_FLAGS
#37152	constant GL_BUFFER_MAP_LENGTH
#37153	constant GL_BUFFER_MAP_OFFSET
#36012	constant GL_DEPTH_COMPONENT32F
#36013	constant GL_DEPTH32F_STENCIL8
#36269	constant GL_FLOAT_32_UNSIGNED_INT_24_8_REV
#33296	constant GL_FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING
#33297	constant GL_FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE
#33298	constant GL_FRAMEBUFFER_ATTACHMENT_RED_SIZE
#33299	constant GL_FRAMEBUFFER_ATTACHMENT_GREEN_SIZE
#33300	constant GL_FRAMEBUFFER_ATTACHMENT_BLUE_SIZE
#33301	constant GL_FRAMEBUFFER_ATTACHMENT_ALPHA_SIZE
#33302	constant GL_FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE
#33303	constant GL_FRAMEBUFFER_ATTACHMENT_STENCIL_SIZE
#33304	constant GL_FRAMEBUFFER_DEFAULT
#33305	constant GL_FRAMEBUFFER_UNDEFINED
#33306	constant GL_DEPTH_STENCIL_ATTACHMENT
#34041	constant GL_DEPTH_STENCIL
#34042	constant GL_UNSIGNED_INT_24_8
#35056	constant GL_DEPTH24_STENCIL8
#35863	constant GL_UNSIGNED_NORMALIZED
#36006	constant GL_DRAW_FRAMEBUFFER_BINDING
#36008	constant GL_READ_FRAMEBUFFER
#36009	constant GL_DRAW_FRAMEBUFFER
#36010	constant GL_READ_FRAMEBUFFER_BINDING
#36011	constant GL_RENDERBUFFER_SAMPLES
#36052	constant GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER
#36063	constant GL_MAX_COLOR_ATTACHMENTS
#36065	constant GL_COLOR_ATTACHMENT1
#36066	constant GL_COLOR_ATTACHMENT2
#36067	constant GL_COLOR_ATTACHMENT3
#36068	constant GL_COLOR_ATTACHMENT4
#36069	constant GL_COLOR_ATTACHMENT5
#36070	constant GL_COLOR_ATTACHMENT6
#36071	constant GL_COLOR_ATTACHMENT7
#36072	constant GL_COLOR_ATTACHMENT8
#36073	constant GL_COLOR_ATTACHMENT9
#36074	constant GL_COLOR_ATTACHMENT10
#36075	constant GL_COLOR_ATTACHMENT11
#36076	constant GL_COLOR_ATTACHMENT12
#36077	constant GL_COLOR_ATTACHMENT13
#36078	constant GL_COLOR_ATTACHMENT14
#36079	constant GL_COLOR_ATTACHMENT15
#36080	constant GL_COLOR_ATTACHMENT16
#36081	constant GL_COLOR_ATTACHMENT17
#36082	constant GL_COLOR_ATTACHMENT18
#36083	constant GL_COLOR_ATTACHMENT19
#36084	constant GL_COLOR_ATTACHMENT20
#36085	constant GL_COLOR_ATTACHMENT21
#36086	constant GL_COLOR_ATTACHMENT22
#36087	constant GL_COLOR_ATTACHMENT23
#36088	constant GL_COLOR_ATTACHMENT24
#36089	constant GL_COLOR_ATTACHMENT25
#36090	constant GL_COLOR_ATTACHMENT26
#36091	constant GL_COLOR_ATTACHMENT27
#36092	constant GL_COLOR_ATTACHMENT28
#36093	constant GL_COLOR_ATTACHMENT29
#36094	constant GL_COLOR_ATTACHMENT30
#36095	constant GL_COLOR_ATTACHMENT31
#36182	constant GL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE
#36183	constant GL_MAX_SAMPLES
#5131	constant GL_HALF_FLOAT
#1	constant GL_MAP_READ_BIT
#2	constant GL_MAP_WRITE_BIT
#4	constant GL_MAP_INVALIDATE_RANGE_BIT
#8	constant GL_MAP_INVALIDATE_BUFFER_BIT
#16	constant GL_MAP_FLUSH_EXPLICIT_BIT
#32	constant GL_MAP_UNSYNCHRONIZED_BIT
#33319	constant GL_RG
#33320	constant GL_RG_INTEGER
#33321	constant GL_R8
#33323	constant GL_RG8
#33325	constant GL_R16F
#33326	constant GL_R32F
#33327	constant GL_RG16F
#33328	constant GL_RG32F
#33329	constant GL_R8I
#33330	constant GL_R8UI
#33331	constant GL_R16I
#33332	constant GL_R16UI
#33333	constant GL_R32I
#33334	constant GL_R32UI
#33335	constant GL_RG8I
#33336	constant GL_RG8UI
#33337	constant GL_RG16I
#33338	constant GL_RG16UI
#33339	constant GL_RG32I
#33340	constant GL_RG32UI
#34229	constant GL_VERTEX_ARRAY_BINDING
#36756	constant GL_R8_SNORM
#36757	constant GL_RG8_SNORM
#36758	constant GL_RGB8_SNORM
#36759	constant GL_RGBA8_SNORM
#36764	constant GL_SIGNED_NORMALIZED
#36201	constant GL_PRIMITIVE_RESTART_FIXED_INDEX
#36662	constant GL_COPY_READ_BUFFER
#36663	constant GL_COPY_WRITE_BUFFER
#36662	constant GL_COPY_READ_BUFFER_BINDING
#36663	constant GL_COPY_WRITE_BUFFER_BINDING
#35345	constant GL_UNIFORM_BUFFER
#35368	constant GL_UNIFORM_BUFFER_BINDING
#35369	constant GL_UNIFORM_BUFFER_START
#35370	constant GL_UNIFORM_BUFFER_SIZE
#35371	constant GL_MAX_VERTEX_UNIFORM_BLOCKS
#35373	constant GL_MAX_FRAGMENT_UNIFORM_BLOCKS
#35374	constant GL_MAX_COMBINED_UNIFORM_BLOCKS
#35375	constant GL_MAX_UNIFORM_BUFFER_BINDINGS
#35376	constant GL_MAX_UNIFORM_BLOCK_SIZE
#35377	constant GL_MAX_COMBINED_VERTEX_UNIFORM_COMPONENTS
#35379	constant GL_MAX_COMBINED_FRAGMENT_UNIFORM_COMPONENTS
#35380	constant GL_UNIFORM_BUFFER_OFFSET_ALIGNMENT
#35381	constant GL_ACTIVE_UNIFORM_BLOCK_MAX_NAME_LENGTH
#35382	constant GL_ACTIVE_UNIFORM_BLOCKS
#35383	constant GL_UNIFORM_TYPE
#35384	constant GL_UNIFORM_SIZE
#35385	constant GL_UNIFORM_NAME_LENGTH
#35386	constant GL_UNIFORM_BLOCK_INDEX
#35387	constant GL_UNIFORM_OFFSET
#35388	constant GL_UNIFORM_ARRAY_STRIDE
#35389	constant GL_UNIFORM_MATRIX_STRIDE
#35390	constant GL_UNIFORM_IS_ROW_MAJOR
#35391	constant GL_UNIFORM_BLOCK_BINDING
#35392	constant GL_UNIFORM_BLOCK_DATA_SIZE
#35393	constant GL_UNIFORM_BLOCK_NAME_LENGTH
#35394	constant GL_UNIFORM_BLOCK_ACTIVE_UNIFORMS
#35395	constant GL_UNIFORM_BLOCK_ACTIVE_UNIFORM_INDICES
#35396	constant GL_UNIFORM_BLOCK_REFERENCED_BY_VERTEX_SHADER
#35398	constant GL_UNIFORM_BLOCK_REFERENCED_BY_FRAGMENT_SHADER
#4294967295	constant GL_INVALID_INDEX
#37154	constant GL_MAX_VERTEX_OUTPUT_COMPONENTS
#37157	constant GL_MAX_FRAGMENT_INPUT_COMPONENTS
#37137	constant GL_MAX_SERVER_WAIT_TIMEOUT
#37138	constant GL_OBJECT_TYPE
#37139	constant GL_SYNC_CONDITION
#37140	constant GL_SYNC_STATUS
#37141	constant GL_SYNC_FLAGS
#37142	constant GL_SYNC_FENCE
#37143	constant GL_SYNC_GPU_COMMANDS_COMPLETE
#37144	constant GL_UNSIGNALED
#37145	constant GL_SIGNALED
#37146	constant GL_ALREADY_SIGNALED
#37147	constant GL_TIMEOUT_EXPIRED
#37148	constant GL_CONDITION_SATISFIED
#37149	constant GL_WAIT_FAILED
#1	constant GL_SYNC_FLUSH_COMMANDS_BIT
#35070	constant GL_VERTEX_ATTRIB_ARRAY_DIVISOR
#35887	constant GL_ANY_SAMPLES_PASSED
#36202	constant GL_ANY_SAMPLES_PASSED_CONSERVATIVE
#35097	constant GL_SAMPLER_BINDING
#36975	constant GL_RGB10_A2UI
#36418	constant GL_TEXTURE_SWIZZLE_R
#36419	constant GL_TEXTURE_SWIZZLE_G
#36420	constant GL_TEXTURE_SWIZZLE_B
#36421	constant GL_TEXTURE_SWIZZLE_A
#6404	constant GL_GREEN
#6405	constant GL_BLUE
#36255	constant GL_INT_2_10_10_10_REV
#36386	constant GL_TRANSFORM_FEEDBACK
#36387	constant GL_TRANSFORM_FEEDBACK_PAUSED
#36388	constant GL_TRANSFORM_FEEDBACK_ACTIVE
#36389	constant GL_TRANSFORM_FEEDBACK_BINDING
#33367	constant GL_PROGRAM_BINARY_RETRIEVABLE_HINT
#34625	constant GL_PROGRAM_BINARY_LENGTH
#34814	constant GL_NUM_PROGRAM_BINARY_FORMATS
#34815	constant GL_PROGRAM_BINARY_FORMATS
#37488	constant GL_COMPRESSED_R11_EAC
#37489	constant GL_COMPRESSED_SIGNED_R11_EAC
#37490	constant GL_COMPRESSED_RG11_EAC
#37491	constant GL_COMPRESSED_SIGNED_RG11_EAC
#37492	constant GL_COMPRESSED_RGB8_ETC2
#37493	constant GL_COMPRESSED_SRGB8_ETC2
#37494	constant GL_COMPRESSED_RGB8_PUNCHTHROUGH_ALPHA1_ETC2
#37495	constant GL_COMPRESSED_SRGB8_PUNCHTHROUGH_ALPHA1_ETC2
#37496	constant GL_COMPRESSED_RGBA8_ETC2_EAC
#37497	constant GL_COMPRESSED_SRGB8_ALPHA8_ETC2_EAC
#37167	constant GL_TEXTURE_IMMUTABLE_FORMAT
#36203	constant GL_MAX_ELEMENT_INDEX
#37760	constant GL_NUM_SAMPLE_COUNTS
#33503	constant GL_TEXTURE_IMMUTABLE_LEVELS

\ ----===< long constants ===>-----
#18446744073709551615.	2constant GL_TIMEOUT_IGNORED

\ ------===< functions >===-------
c-function glActiveTexture glActiveTexture u -- void	( texture -- )
c-function glAttachShader glAttachShader u u -- void	( program shader -- )
c-function glBindAttribLocation glBindAttribLocation u u s -- void	( program index name -- )
c-function glBindBuffer glBindBuffer u u -- void	( target buffer -- )
c-function glBindFramebuffer glBindFramebuffer u u -- void	( target framebuffer -- )
c-function glBindRenderbuffer glBindRenderbuffer u u -- void	( target renderbuffer -- )
c-function glBindTexture glBindTexture u u -- void	( target texture -- )
c-function glBlendColor glBlendColor r r r r -- void	( red green blue alpha -- )
c-function glBlendEquation glBlendEquation u -- void	( mode -- )
c-function glBlendEquationSeparate glBlendEquationSeparate u u -- void	( modeRGB modeAlpha -- )
c-function glBlendFunc glBlendFunc u u -- void	( sfactor dfactor -- )
c-function glBlendFuncSeparate glBlendFuncSeparate u u u u -- void	( sfactorRGB dfactorRGB sfactorAlpha dfactorAlpha -- )
c-function glBufferData glBufferData u a a u -- void	( target size data usage -- )
c-function glBufferSubData glBufferSubData u a a a -- void	( target offset size data -- )
c-function glCheckFramebufferStatus glCheckFramebufferStatus u -- u	( target -- )
c-function glClear glClear u -- void	( mask -- )
c-function glClearColor glClearColor r r r r -- void	( red green blue alpha -- )
c-function glClearDepthf glClearDepthf r -- void	( d -- )
c-function glClearStencil glClearStencil n -- void	( s -- )
c-function glColorMask glColorMask u u u u -- void	( red green blue alpha -- )
c-function glCompileShader glCompileShader u -- void	( shader -- )
c-function glCompressedTexImage2D glCompressedTexImage2D u n u n n n n a -- void	( target level internalformat width height border imageSize data -- )
c-function glCompressedTexSubImage2D glCompressedTexSubImage2D u n n n n n u n a -- void	( target level xoffset yoffset width height format imageSize data -- )
c-function glCopyTexImage2D glCopyTexImage2D u n u n n n n n -- void	( target level internalformat x y width height border -- )
c-function glCopyTexSubImage2D glCopyTexSubImage2D u n n n n n n n -- void	( target level xoffset yoffset x y width height -- )
c-function glCreateProgram glCreateProgram  -- u	( -- )
c-function glCreateShader glCreateShader u -- u	( type -- )
c-function glCullFace glCullFace u -- void	( mode -- )
c-function glDeleteBuffers glDeleteBuffers n a -- void	( n buffers -- )
c-function glDeleteFramebuffers glDeleteFramebuffers n a -- void	( n framebuffers -- )
c-function glDeleteProgram glDeleteProgram u -- void	( program -- )
c-function glDeleteRenderbuffers glDeleteRenderbuffers n a -- void	( n renderbuffers -- )
c-function glDeleteShader glDeleteShader u -- void	( shader -- )
c-function glDeleteTextures glDeleteTextures n a -- void	( n textures -- )
c-function glDepthFunc glDepthFunc u -- void	( func -- )
c-function glDepthMask glDepthMask u -- void	( flag -- )
c-function glDepthRangef glDepthRangef r r -- void	( n f -- )
c-function glDetachShader glDetachShader u u -- void	( program shader -- )
c-function glDisable glDisable u -- void	( cap -- )
c-function glDisableVertexAttribArray glDisableVertexAttribArray u -- void	( index -- )
c-function glDrawArrays glDrawArrays u n n -- void	( mode first count -- )
c-function glDrawElements glDrawElements u n u a -- void	( mode count type indices -- )
c-function glEnable glEnable u -- void	( cap -- )
c-function glEnableVertexAttribArray glEnableVertexAttribArray u -- void	( index -- )
c-function glFinish glFinish  -- void	( -- )
c-function glFlush glFlush  -- void	( -- )
c-function glFramebufferRenderbuffer glFramebufferRenderbuffer u u u u -- void	( target attachment renderbuffertarget renderbuffer -- )
c-function glFramebufferTexture2D glFramebufferTexture2D u u u u n -- void	( target attachment textarget texture level -- )
c-function glFrontFace glFrontFace u -- void	( mode -- )
c-function glGenBuffers glGenBuffers n a -- void	( n buffers -- )
c-function glGenerateMipmap glGenerateMipmap u -- void	( target -- )
c-function glGenFramebuffers glGenFramebuffers n a -- void	( n framebuffers -- )
c-function glGenRenderbuffers glGenRenderbuffers n a -- void	( n renderbuffers -- )
c-function glGenTextures glGenTextures n a -- void	( n textures -- )
c-function glGetActiveAttrib glGetActiveAttrib u u n a a a a -- void	( program index bufSize length size type name -- )
c-function glGetActiveUniform glGetActiveUniform u u n a a a a -- void	( program index bufSize length size type name -- )
c-function glGetAttachedShaders glGetAttachedShaders u n a a -- void	( program maxCount count shaders -- )
c-function glGetAttribLocation glGetAttribLocation u s -- n	( program name -- )
c-function glGetBooleanv glGetBooleanv u a -- void	( pname data -- )
c-function glGetBufferParameteriv glGetBufferParameteriv u u a -- void	( target pname params -- )
c-function glGetError glGetError  -- u	( -- )
c-function glGetFloatv glGetFloatv u a -- void	( pname data -- )
c-function glGetFramebufferAttachmentParameteriv glGetFramebufferAttachmentParameteriv u u u a -- void	( target attachment pname params -- )
c-function glGetIntegerv glGetIntegerv u a -- void	( pname data -- )
c-function glGetProgramiv glGetProgramiv u u a -- void	( program pname params -- )
c-function glGetProgramInfoLog glGetProgramInfoLog u n a a -- void	( program bufSize length infoLog -- )
c-function glGetRenderbufferParameteriv glGetRenderbufferParameteriv u u a -- void	( target pname params -- )
c-function glGetShaderiv glGetShaderiv u u a -- void	( shader pname params -- )
c-function glGetShaderInfoLog glGetShaderInfoLog u n a a -- void	( shader bufSize length infoLog -- )
c-function glGetShaderPrecisionFormat glGetShaderPrecisionFormat u u a a -- void	( shadertype precisiontype range precision -- )
c-function glGetShaderSource glGetShaderSource u n a a -- void	( shader bufSize length source -- )
c-function glGetString glGetString u -- a	( name -- )
c-function glGetTexParameterfv glGetTexParameterfv u u a -- void	( target pname params -- )
c-function glGetTexParameteriv glGetTexParameteriv u u a -- void	( target pname params -- )
c-function glGetUniformfv glGetUniformfv u n a -- void	( program location params -- )
c-function glGetUniformiv glGetUniformiv u n a -- void	( program location params -- )
c-function glGetUniformLocation glGetUniformLocation u s -- n	( program name -- )
c-function glGetVertexAttribfv glGetVertexAttribfv u u a -- void	( index pname params -- )
c-function glGetVertexAttribiv glGetVertexAttribiv u u a -- void	( index pname params -- )
c-function glGetVertexAttribPointerv glGetVertexAttribPointerv u u a -- void	( index pname pointer -- )
c-function glHint glHint u u -- void	( target mode -- )
c-function glIsBuffer glIsBuffer u -- u	( buffer -- )
c-function glIsEnabled glIsEnabled u -- u	( cap -- )
c-function glIsFramebuffer glIsFramebuffer u -- u	( framebuffer -- )
c-function glIsProgram glIsProgram u -- u	( program -- )
c-function glIsRenderbuffer glIsRenderbuffer u -- u	( renderbuffer -- )
c-function glIsShader glIsShader u -- u	( shader -- )
c-function glIsTexture glIsTexture u -- u	( texture -- )
c-function glLineWidth glLineWidth r -- void	( width -- )
c-function glLinkProgram glLinkProgram u -- void	( program -- )
c-function glPixelStorei glPixelStorei u n -- void	( pname param -- )
c-function glPolygonOffset glPolygonOffset r r -- void	( factor units -- )
c-function glReadPixels glReadPixels n n n n u u a -- void	( x y width height format type pixels -- )
c-function glReleaseShaderCompiler glReleaseShaderCompiler  -- void	( -- )
c-function glRenderbufferStorage glRenderbufferStorage u u n n -- void	( target internalformat width height -- )
c-function glSampleCoverage glSampleCoverage r u -- void	( value invert -- )
c-function glScissor glScissor n n n n -- void	( x y width height -- )
c-function glShaderBinary glShaderBinary n a u a n -- void	( count shaders binaryformat binary length -- )
c-function glShaderSource glShaderSource u n a a -- void	( shader count string length -- )
c-function glStencilFunc glStencilFunc u n u -- void	( func ref mask -- )
c-function glStencilFuncSeparate glStencilFuncSeparate u u n u -- void	( face func ref mask -- )
c-function glStencilMask glStencilMask u -- void	( mask -- )
c-function glStencilMaskSeparate glStencilMaskSeparate u u -- void	( face mask -- )
c-function glStencilOp glStencilOp u u u -- void	( fail zfail zpass -- )
c-function glStencilOpSeparate glStencilOpSeparate u u u u -- void	( face sfail dpfail dppass -- )
c-function glTexImage2D glTexImage2D u n n n n n u u a -- void	( target level internalformat width height border format type pixels -- )
c-function glTexParameterf glTexParameterf u u r -- void	( target pname param -- )
c-function glTexParameterfv glTexParameterfv u u a -- void	( target pname params -- )
c-function glTexParameteri glTexParameteri u u n -- void	( target pname param -- )
c-function glTexParameteriv glTexParameteriv u u a -- void	( target pname params -- )
c-function glTexSubImage2D glTexSubImage2D u n n n n n u u a -- void	( target level xoffset yoffset width height format type pixels -- )
c-function glUniform1f glUniform1f n r -- void	( location v0 -- )
c-function glUniform1fv glUniform1fv n n a -- void	( location count value -- )
c-function glUniform1i glUniform1i n n -- void	( location v0 -- )
c-function glUniform1iv glUniform1iv n n a -- void	( location count value -- )
c-function glUniform2f glUniform2f n r r -- void	( location v0 v1 -- )
c-function glUniform2fv glUniform2fv n n a -- void	( location count value -- )
c-function glUniform2i glUniform2i n n n -- void	( location v0 v1 -- )
c-function glUniform2iv glUniform2iv n n a -- void	( location count value -- )
c-function glUniform3f glUniform3f n r r r -- void	( location v0 v1 v2 -- )
c-function glUniform3fv glUniform3fv n n a -- void	( location count value -- )
c-function glUniform3i glUniform3i n n n n -- void	( location v0 v1 v2 -- )
c-function glUniform3iv glUniform3iv n n a -- void	( location count value -- )
c-function glUniform4f glUniform4f n r r r r -- void	( location v0 v1 v2 v3 -- )
c-function glUniform4fv glUniform4fv n n a -- void	( location count value -- )
c-function glUniform4i glUniform4i n n n n n -- void	( location v0 v1 v2 v3 -- )
c-function glUniform4iv glUniform4iv n n a -- void	( location count value -- )
c-function glUniformMatrix2fv glUniformMatrix2fv n n u a -- void	( location count transpose value -- )
c-function glUniformMatrix3fv glUniformMatrix3fv n n u a -- void	( location count transpose value -- )
c-function glUniformMatrix4fv glUniformMatrix4fv n n u a -- void	( location count transpose value -- )
c-function glUseProgram glUseProgram u -- void	( program -- )
c-function glValidateProgram glValidateProgram u -- void	( program -- )
c-function glVertexAttrib1f glVertexAttrib1f u r -- void	( index x -- )
c-function glVertexAttrib1fv glVertexAttrib1fv u a -- void	( index v -- )
c-function glVertexAttrib2f glVertexAttrib2f u r r -- void	( index x y -- )
c-function glVertexAttrib2fv glVertexAttrib2fv u a -- void	( index v -- )
c-function glVertexAttrib3f glVertexAttrib3f u r r r -- void	( index x y z -- )
c-function glVertexAttrib3fv glVertexAttrib3fv u a -- void	( index v -- )
c-function glVertexAttrib4f glVertexAttrib4f u r r r r -- void	( index x y z w -- )
c-function glVertexAttrib4fv glVertexAttrib4fv u a -- void	( index v -- )
c-function glVertexAttribPointer glVertexAttribPointer u n u u n a -- void	( index size type normalized stride pointer -- )
c-function glViewport glViewport n n n n -- void	( x y width height -- )
c-function glReadBuffer glReadBuffer u -- void	( src -- )
c-function glDrawRangeElements glDrawRangeElements u u u n u a -- void	( mode start end count type indices -- )
c-function glTexImage3D glTexImage3D u n n n n n n u u a -- void	( target level internalformat width height depth border format type pixels -- )
c-function glTexSubImage3D glTexSubImage3D u n n n n n n n u u a -- void	( target level xoffset yoffset zoffset width height depth format type pixels -- )
c-function glCopyTexSubImage3D glCopyTexSubImage3D u n n n n n n n n -- void	( target level xoffset yoffset zoffset x y width height -- )
c-function glCompressedTexImage3D glCompressedTexImage3D u n u n n n n n a -- void	( target level internalformat width height depth border imageSize data -- )
c-function glCompressedTexSubImage3D glCompressedTexSubImage3D u n n n n n n n u n a -- void	( target level xoffset yoffset zoffset width height depth format imageSize data -- )
c-function glGenQueries glGenQueries n a -- void	( n ids -- )
c-function glDeleteQueries glDeleteQueries n a -- void	( n ids -- )
c-function glIsQuery glIsQuery u -- u	( id -- )
c-function glBeginQuery glBeginQuery u u -- void	( target id -- )
c-function glEndQuery glEndQuery u -- void	( target -- )
c-function glGetQueryiv glGetQueryiv u u a -- void	( target pname params -- )
c-function glGetQueryObjectuiv glGetQueryObjectuiv u u a -- void	( id pname params -- )
c-function glUnmapBuffer glUnmapBuffer u -- u	( target -- )
c-function glGetBufferPointerv glGetBufferPointerv u u a -- void	( target pname params -- )
c-function glDrawBuffers glDrawBuffers n a -- void	( n bufs -- )
c-function glUniformMatrix2x3fv glUniformMatrix2x3fv n n u a -- void	( location count transpose value -- )
c-function glUniformMatrix3x2fv glUniformMatrix3x2fv n n u a -- void	( location count transpose value -- )
c-function glUniformMatrix2x4fv glUniformMatrix2x4fv n n u a -- void	( location count transpose value -- )
c-function glUniformMatrix4x2fv glUniformMatrix4x2fv n n u a -- void	( location count transpose value -- )
c-function glUniformMatrix3x4fv glUniformMatrix3x4fv n n u a -- void	( location count transpose value -- )
c-function glUniformMatrix4x3fv glUniformMatrix4x3fv n n u a -- void	( location count transpose value -- )
c-function glBlitFramebuffer glBlitFramebuffer n n n n n n n n u u -- void	( srcX0 srcY0 srcX1 srcY1 dstX0 dstY0 dstX1 dstY1 mask filter -- )
c-function glRenderbufferStorageMultisample glRenderbufferStorageMultisample u n u n n -- void	( target samples internalformat width height -- )
c-function glFramebufferTextureLayer glFramebufferTextureLayer u u u n n -- void	( target attachment texture level layer -- )
c-function glMapBufferRange glMapBufferRange u a a u -- a	( target offset length access -- )
c-function glFlushMappedBufferRange glFlushMappedBufferRange u a a -- void	( target offset length -- )
c-function glBindVertexArray glBindVertexArray u -- void	( array -- )
c-function glDeleteVertexArrays glDeleteVertexArrays n a -- void	( n arrays -- )
c-function glGenVertexArrays glGenVertexArrays n a -- void	( n arrays -- )
c-function glIsVertexArray glIsVertexArray u -- u	( array -- )
c-function glGetIntegeri_v glGetIntegeri_v u u a -- void	( target index data -- )
c-function glBeginTransformFeedback glBeginTransformFeedback u -- void	( primitiveMode -- )
c-function glEndTransformFeedback glEndTransformFeedback  -- void	( -- )
c-function glBindBufferRange glBindBufferRange u u u a a -- void	( target index buffer offset size -- )
c-function glBindBufferBase glBindBufferBase u u u -- void	( target index buffer -- )
c-function glTransformFeedbackVaryings glTransformFeedbackVaryings u n a u -- void	( program count varyings bufferMode -- )
c-function glGetTransformFeedbackVarying glGetTransformFeedbackVarying u u n a a a a -- void	( program index bufSize length size type name -- )
c-function glVertexAttribIPointer glVertexAttribIPointer u n u n a -- void	( index size type stride pointer -- )
c-function glGetVertexAttribIiv glGetVertexAttribIiv u u a -- void	( index pname params -- )
c-function glGetVertexAttribIuiv glGetVertexAttribIuiv u u a -- void	( index pname params -- )
c-function glVertexAttribI4i glVertexAttribI4i u n n n n -- void	( index x y z w -- )
c-function glVertexAttribI4ui glVertexAttribI4ui u u u u u -- void	( index x y z w -- )
c-function glVertexAttribI4iv glVertexAttribI4iv u a -- void	( index v -- )
c-function glVertexAttribI4uiv glVertexAttribI4uiv u a -- void	( index v -- )
c-function glGetUniformuiv glGetUniformuiv u n a -- void	( program location params -- )
c-function glGetFragDataLocation glGetFragDataLocation u s -- n	( program name -- )
c-function glUniform1ui glUniform1ui n u -- void	( location v0 -- )
c-function glUniform2ui glUniform2ui n u u -- void	( location v0 v1 -- )
c-function glUniform3ui glUniform3ui n u u u -- void	( location v0 v1 v2 -- )
c-function glUniform4ui glUniform4ui n u u u u -- void	( location v0 v1 v2 v3 -- )
c-function glUniform1uiv glUniform1uiv n n a -- void	( location count value -- )
c-function glUniform2uiv glUniform2uiv n n a -- void	( location count value -- )
c-function glUniform3uiv glUniform3uiv n n a -- void	( location count value -- )
c-function glUniform4uiv glUniform4uiv n n a -- void	( location count value -- )
c-function glClearBufferiv glClearBufferiv u n a -- void	( buffer drawbuffer value -- )
c-function glClearBufferuiv glClearBufferuiv u n a -- void	( buffer drawbuffer value -- )
c-function glClearBufferfv glClearBufferfv u n a -- void	( buffer drawbuffer value -- )
c-function glClearBufferfi glClearBufferfi u n r n -- void	( buffer drawbuffer depth stencil -- )
c-function glGetStringi glGetStringi u u -- a	( name index -- )
c-function glCopyBufferSubData glCopyBufferSubData u u a a a -- void	( readTarget writeTarget readOffset writeOffset size -- )
c-function glGetUniformIndices glGetUniformIndices u n a a -- void	( program uniformCount uniformNames uniformIndices -- )
c-function glGetActiveUniformsiv glGetActiveUniformsiv u n a u a -- void	( program uniformCount uniformIndices pname params -- )
c-function glGetUniformBlockIndex glGetUniformBlockIndex u s -- u	( program uniformBlockName -- )
c-function glGetActiveUniformBlockiv glGetActiveUniformBlockiv u u u a -- void	( program uniformBlockIndex pname params -- )
c-function glGetActiveUniformBlockName glGetActiveUniformBlockName u u n a a -- void	( program uniformBlockIndex bufSize length uniformBlockName -- )
c-function glUniformBlockBinding glUniformBlockBinding u u u -- void	( program uniformBlockIndex uniformBlockBinding -- )
c-function glDrawArraysInstanced glDrawArraysInstanced u n n n -- void	( mode first count instancecount -- )
c-function glDrawElementsInstanced glDrawElementsInstanced u n u a n -- void	( mode count type indices instancecount -- )
c-function glFenceSync glFenceSync u u -- a	( condition flags -- )
c-function glIsSync glIsSync a -- u	( sync -- )
c-function glDeleteSync glDeleteSync a -- void	( sync -- )
c-function glClientWaitSync glClientWaitSync a u d -- u	( sync flags timeout -- )
c-function glWaitSync glWaitSync a u d -- void	( sync flags timeout -- )
c-function glGetInteger64v glGetInteger64v u a -- void	( pname data -- )
c-function glGetSynciv glGetSynciv a u n a a -- void	( sync pname bufSize length values -- )
c-function glGetInteger64i_v glGetInteger64i_v u u a -- void	( target index data -- )
c-function glGetBufferParameteri64v glGetBufferParameteri64v u u a -- void	( target pname params -- )
c-function glGenSamplers glGenSamplers n a -- void	( count samplers -- )
c-function glDeleteSamplers glDeleteSamplers n a -- void	( count samplers -- )
c-function glIsSampler glIsSampler u -- u	( sampler -- )
c-function glBindSampler glBindSampler u u -- void	( unit sampler -- )
c-function glSamplerParameteri glSamplerParameteri u u n -- void	( sampler pname param -- )
c-function glSamplerParameteriv glSamplerParameteriv u u a -- void	( sampler pname param -- )
c-function glSamplerParameterf glSamplerParameterf u u r -- void	( sampler pname param -- )
c-function glSamplerParameterfv glSamplerParameterfv u u a -- void	( sampler pname param -- )
c-function glGetSamplerParameteriv glGetSamplerParameteriv u u a -- void	( sampler pname params -- )
c-function glGetSamplerParameterfv glGetSamplerParameterfv u u a -- void	( sampler pname params -- )
c-function glVertexAttribDivisor glVertexAttribDivisor u u -- void	( index divisor -- )
c-function glBindTransformFeedback glBindTransformFeedback u u -- void	( target id -- )
c-function glDeleteTransformFeedbacks glDeleteTransformFeedbacks n a -- void	( n ids -- )
c-function glGenTransformFeedbacks glGenTransformFeedbacks n a -- void	( n ids -- )
c-function glIsTransformFeedback glIsTransformFeedback u -- u	( id -- )
c-function glPauseTransformFeedback glPauseTransformFeedback  -- void	( -- )
c-function glResumeTransformFeedback glResumeTransformFeedback  -- void	( -- )
c-function glGetProgramBinary glGetProgramBinary u n a a a -- void	( program bufSize length binaryFormat binary -- )
c-function glProgramBinary glProgramBinary u u a n -- void	( program binaryFormat binary length -- )
c-function glProgramParameteri glProgramParameteri u u n -- void	( program pname value -- )
c-function glInvalidateFramebuffer glInvalidateFramebuffer u n a -- void	( target numAttachments attachments -- )
c-function glInvalidateSubFramebuffer glInvalidateSubFramebuffer u n a n n n n -- void	( target numAttachments attachments x y width height -- )
c-function glTexStorage2D glTexStorage2D u n u n n -- void	( target levels internalformat width height -- )
c-function glTexStorage3D glTexStorage3D u n u n n n -- void	( target levels internalformat width height depth -- )
c-function glGetInternalformativ glGetInternalformativ u u u n a -- void	( target internalformat pname bufSize params -- )
