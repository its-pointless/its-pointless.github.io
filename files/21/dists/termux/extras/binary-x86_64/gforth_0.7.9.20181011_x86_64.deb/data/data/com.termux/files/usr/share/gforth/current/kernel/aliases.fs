\ run-time routine headers

\ Copyright (C) 1997,1998,2002,2003,2006,2007,2010,2013,2015,2016 Free Software Foundation, Inc.

\ This file is part of Gforth.

\ Gforth is free software; you can redistribute it and/or
\ modify it under the terms of the GNU General Public License
\ as published by the Free Software Foundation, either version 3
\ of the License, or (at your option) any later version.

\ This program is distributed in the hope that it will be useful,
\ but WITHOUT ANY WARRANTY; without even the implied warranty of
\ MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
\ GNU General Public License for more details.

\ You should have received a copy of the GNU General Public License
\ along with this program. If not, see http://www.gnu.org/licenses/.

-2 Doer: :docol
-3 Doer: :docon
-4 Doer: :dovar
-5 Doer: :douser
-6 Doer: :dodefer
-7 Doer: :dofield
-8 Doer: :dovalue
-9 Doer: :dodoes
-&10 Doer: :doabicode
-&11 Doer: :do;abicode
-&12 Doer: :doextra
-&13 Doer: :dodoesxt
-&2 first-primitive
\ this does not work for (at least) (DODOES),
\ so the following routines are commented out
 0 [if]
154 0 #loc prim Primitive (docol)
172 0 #loc prim Primitive (docon)
180 0 #loc prim Primitive (dovar)
188 0 #loc prim Primitive (douser)
196 0 #loc prim Primitive (dodefer)
204 0 #loc prim Primitive (dofield)
212 0 #loc prim Primitive (dovalue)
220 0 #loc prim Primitive (dodoes)
239 0 #loc prim Primitive (doabicode)
250 0 #loc prim Primitive (do;abicode)
262 0 #loc prim Primitive (doextra)
281 0 #loc prim Primitive (dodoesxt)
 [endif]
12 groupadd
group  control
293 0 #loc prim Primitive noop
297 0 #loc prim Primitive call
315 0 #loc prim Primitive execute
326 0 #loc prim Primitive perform
337 0 #loc prim Primitive ;s
346 0 #loc prim Primitive execute-;s
355 0 #loc prim Primitive unloop
360 0 #loc prim Primitive lit-perform
367 0 #loc prim Primitive does-exec
384 0 #loc prim Primitive extra-exec
401 0 #loc prim Primitive does-xt
11 groupadd
has? glocals [IF]
420 0 #loc prim Primitive branch-lp+!#
1 groupadd
[THEN]
432 0 #loc prim Primitive branch
478 0 #loc prim Primitive ?branch
2 groupadd
has? glocals [IF]
478 0 #loc prim Primitive ?branch-lp+!#
1 groupadd
[THEN]
0 groupadd
has? xconds [IF]
491 0 #loc prim Primitive ?dup-?branch
505 0 #loc prim Primitive ?dup-0=-?branch
2 groupadd
[THEN]
has? skiploopprims 0= [IF]
520 0 #loc prim Primitive (next)
1 groupadd
has? glocals [IF]
520 0 #loc prim Primitive (next)-lp+!#
1 groupadd
[THEN]
527 0 #loc prim Primitive (loop)
1 groupadd
has? glocals [IF]
527 0 #loc prim Primitive (loop)-lp+!#
1 groupadd
[THEN]
535 0 #loc prim Primitive (+loop)
1 groupadd
has? glocals [IF]
535 0 #loc prim Primitive (+loop)-lp+!#
1 groupadd
[THEN]
0 groupadd
has? xconds [IF]
554 0 #loc prim Primitive (-loop)
1 groupadd
has? glocals [IF]
554 0 #loc prim Primitive (-loop)-lp+!#
1 groupadd
[THEN]
560 0 #loc prim Primitive (s+loop)
1 groupadd
has? glocals [IF]
560 0 #loc prim Primitive (s+loop)-lp+!#
1 groupadd
[THEN]
0 groupadd
[THEN]
577 0 #loc prim Primitive (for)
583 0 #loc prim Primitive (do)
587 0 #loc prim Primitive (?do)
3 groupadd
has? xconds [IF]
608 0 #loc prim Primitive (+do)
629 0 #loc prim Primitive (u+do)
650 0 #loc prim Primitive (-do)
671 0 #loc prim Primitive (u-do)
692 0 #loc prim Primitive (try)
701 0 #loc prim Primitive uncatch
704 0 #loc prim Primitive fast-throw
714 0 #loc prim Primitive pushwrap
722 0 #loc prim Primitive dropwrap
725 0 #loc prim Primitive exit-wrap
10 groupadd
[THEN]
739 0 #loc prim Primitive i
744 0 #loc prim Primitive i'
750 0 #loc prim Primitive j
756 0 #loc prim Primitive k
[THEN]
4 groupadd
group  strings
768 0 #loc prim Primitive move
777 0 #loc prim Primitive cmove
786 0 #loc prim Primitive cmove>
797 0 #loc prim Primitive fill
804 0 #loc prim Primitive compare
836 0 #loc prim Primitive toupper
843 0 #loc prim Primitive capscompare
852 0 #loc prim Primitive /string
860 0 #loc prim Primitive safe/string
9 groupadd
group  arith
875 0 #loc prim Primitive lit
879 0 #loc prim Primitive +
884 0 #loc prim Primitive lit+
891 0 #loc prim Primitive under+
897 0 #loc prim Primitive -
902 0 #loc prim Primitive negate
908 0 #loc prim Primitive 1+
913 0 #loc prim Primitive 1-
918 0 #loc prim Primitive max
926 0 #loc prim Primitive min
934 0 #loc prim Primitive abs
942 0 #loc prim Primitive *
947 0 #loc prim Primitive /
960 0 #loc prim Primitive mod
973 0 #loc prim Primitive /mod
988 0 #loc prim Primitive */mod
1012 0 #loc prim Primitive */
1035 0 #loc prim Primitive 2*
1041 0 #loc prim Primitive 2/
1052 0 #loc prim Primitive fm/mod
1071 0 #loc prim Primitive sm/rem
1086 0 #loc prim Primitive m*
1097 0 #loc prim Primitive um*
1113 0 #loc prim Primitive um/mod
1132 0 #loc prim Primitive m+
1142 0 #loc prim Primitive d+
1152 0 #loc prim Primitive d-
1162 0 #loc prim Primitive dnegate
1172 0 #loc prim Primitive d2*
1178 0 #loc prim Primitive d2/
1191 0 #loc prim Primitive and
1194 0 #loc prim Primitive or
1199 0 #loc prim Primitive xor
1202 0 #loc prim Primitive invert
1207 0 #loc prim Primitive rshift
1217 0 #loc prim Primitive lshift
1226 0 #loc prim Primitive umax
1234 0 #loc prim Primitive umin
1242 0 #loc prim Primitive mux
1248 0 #loc prim Primitive select
1254 0 #loc prim Primitive dlshift
1269 0 #loc prim Primitive drshift
1284 0 #loc prim Primitive rol
1288 0 #loc prim Primitive ror
1292 0 #loc prim Primitive drol
1311 0 #loc prim Primitive dror
1330 0 #loc prim Primitive du/mod
1348 0 #loc prim Primitive u/
1355 0 #loc prim Primitive umod
1362 0 #loc prim Primitive u/mod
1370 0 #loc prim Primitive arshift
1376 0 #loc prim Primitive darshift
52 groupadd
group  compare
1444 0 #loc prim Primitive 0=
1444 0 #loc prim Primitive 0<>
1444 0 #loc prim Primitive 0<
1444 0 #loc prim Primitive 0>
1444 0 #loc prim Primitive 0<=
1444 0 #loc prim Primitive 0>=
1445 0 #loc prim Primitive =
1445 0 #loc prim Primitive <>
1445 0 #loc prim Primitive <
1445 0 #loc prim Primitive >
1445 0 #loc prim Primitive <=
1445 0 #loc prim Primitive >=
1446 0 #loc prim Primitive u=
1446 0 #loc prim Primitive u<>
1446 0 #loc prim Primitive u<
1446 0 #loc prim Primitive u>
1446 0 #loc prim Primitive u<=
1446 0 #loc prim Primitive u>=
18 groupadd
has? dcomps [IF]
1496 0 #loc prim Primitive d=
1496 0 #loc prim Primitive d<>
1496 0 #loc prim Primitive d<
1496 0 #loc prim Primitive d>
1496 0 #loc prim Primitive d<=
1496 0 #loc prim Primitive d>=
1497 0 #loc prim Primitive d0=
1497 0 #loc prim Primitive d0<>
1497 0 #loc prim Primitive d0<
1497 0 #loc prim Primitive d0>
1497 0 #loc prim Primitive d0<=
1497 0 #loc prim Primitive d0>=
1498 0 #loc prim Primitive du=
1498 0 #loc prim Primitive du<>
1498 0 #loc prim Primitive du<
1498 0 #loc prim Primitive du>
1498 0 #loc prim Primitive du<=
1498 0 #loc prim Primitive du>=
18 groupadd
[THEN]
1502 0 #loc prim Primitive within
1 groupadd
group  stack
1516 0 #loc prim Primitive useraddr
1519 0 #loc prim Primitive up!
1525 0 #loc prim Primitive sp@
1528 0 #loc prim Primitive sp!
1531 0 #loc prim Primitive rp@
1534 0 #loc prim Primitive rp!
6 groupadd
has? floating [IF]
1539 0 #loc prim Primitive fp@
1542 0 #loc prim Primitive fp!
2 groupadd
[THEN]
1547 0 #loc prim Primitive >r
1552 0 #loc prim Primitive r>
1557 0 #loc prim Primitive rdrop
1561 0 #loc prim Primitive 2>r
1565 0 #loc prim Primitive 2r>
1569 0 #loc prim Primitive 2r@
1573 0 #loc prim Primitive 2rdrop
1577 0 #loc prim Primitive over
1581 0 #loc prim Primitive drop
1585 0 #loc prim Primitive swap
1590 0 #loc prim Primitive dup
1594 0 #loc prim Primitive rot
1603 0 #loc prim Primitive -rot
1607 0 #loc prim Primitive nip
1611 0 #loc prim Primitive tuck
1615 0 #loc prim Primitive ?dup
1624 0 #loc prim Primitive pick
1630 0 #loc prim Primitive 2drop
1634 0 #loc prim Primitive 2dup
1638 0 #loc prim Primitive 2over
1642 0 #loc prim Primitive 2swap
1646 0 #loc prim Primitive 2rot
1650 0 #loc prim Primitive 2nip
1654 0 #loc prim Primitive 2tuck
1658 0 #loc prim Primitive user@
1661 0 #loc prim Primitive sps@
26 groupadd
group  memory
1668 0 #loc prim Primitive @
1674 0 #loc prim Primitive lit@
1677 0 #loc prim Primitive !
1681 0 #loc prim Primitive +!
1687 0 #loc prim Primitive c@
1713 0 #loc prim Primitive c!
1743 0 #loc prim Primitive 2!
1750 0 #loc prim Primitive 2@
1758 0 #loc prim Primitive cell+
1764 0 #loc prim Primitive cells
1775 0 #loc prim Primitive char+
1781 0 #loc prim Primitive (chars)
1786 0 #loc prim Primitive count
1794 0 #loc prim Primitive cell/
1805 0 #loc prim Primitive cell-
15 groupadd
group  compiler
0 groupadd
has? f83headerstring [IF]
1815 0 #loc prim Primitive (f83find)
1 groupadd
[ELSE]
1845 0 #loc prim Primitive (listlfind)
1 groupadd
has? hash [IF]
1866 0 #loc prim Primitive (hashlfind)
1876 0 #loc prim Primitive (tablelfind)
1893 0 #loc prim Primitive (hashkey1)
1909 0 #loc prim Primitive (hashkey2)
1913 0 #loc prim Primitive hashkey2
5 groupadd
[THEN]
0 groupadd
[THEN]
1922 0 #loc prim Primitive (parse-white)
1932 0 #loc prim Primitive aligned
1938 0 #loc prim Primitive faligned
has? standardthreading has? compiler and [IF]
1946 0 #loc prim Primitive threading-method
1961 0 #loc prim Primitive debugging-method
[THEN]
5 groupadd
group  hostos
1975 0 #loc prim Primitive (key-file)
1989 0 #loc prim Primitive key?-file
2001 0 #loc prim Primitive stdin
2005 0 #loc prim Primitive stdout
2009 0 #loc prim Primitive stderr
5 groupadd
has? os [IF]
2015 0 #loc prim Primitive (form)
2028 0 #loc prim Primitive wcwidth
2032 0 #loc prim Primitive flush-icache
2044 0 #loc prim Primitive (bye)
2052 0 #loc prim Primitive (system)
2056 0 #loc prim Primitive getenv
2067 0 #loc prim Primitive open-pipe
2074 0 #loc prim Primitive close-pipe
2078 0 #loc prim Primitive time&date
2092 0 #loc prim Primitive (ms)
2096 0 #loc prim Primitive allocate
2105 0 #loc prim Primitive free
2113 0 #loc prim Primitive resize
2132 0 #loc prim Primitive strerror
2136 0 #loc prim Primitive strsignal
2140 0 #loc prim Primitive call-c
2153 0 #loc prim Primitive call-c#
2166 0 #loc prim Primitive gforth-pointers
18 groupadd
[THEN]
0 groupadd
has? file [IF]
2172 0 #loc prim Primitive close-file
2175 0 #loc prim Primitive open-file
2180 0 #loc prim Primitive create-file
2185 0 #loc prim Primitive delete-file
2190 0 #loc prim Primitive rename-file
2194 0 #loc prim Primitive file-position
2199 0 #loc prim Primitive reposition-file
2202 0 #loc prim Primitive file-size
2212 0 #loc prim Primitive resize-file
2215 0 #loc prim Primitive read-file
2226 0 #loc prim Primitive (read-line)
11 groupadd
[THEN]
2235 0 #loc prim Primitive write-file
2248 0 #loc prim Primitive emit-file
2 groupadd
has? file [IF]
2261 0 #loc prim Primitive flush-file
2264 0 #loc prim Primitive file-status
2269 0 #loc prim Primitive file-eof?
2272 0 #loc prim Primitive open-dir
2280 0 #loc prim Primitive read-dir
2308 0 #loc prim Primitive close-dir
2312 0 #loc prim Primitive filename-match
2319 0 #loc prim Primitive set-dir
2326 0 #loc prim Primitive get-dir
2336 0 #loc prim Primitive =mkdir
10 groupadd
[THEN]
2344 0 #loc prim Primitive newline
1 groupadd
has? os [IF]
2363 0 #loc prim Primitive utime
2369 0 #loc prim Primitive cputime
2387 0 #loc prim Primitive ntime
2400 0 #loc prim Primitive (ns)
4 groupadd
[THEN]
0 groupadd
has? floating [IF]
0 groupadd
group  floating
2420 0 #loc prim Primitive f=
2420 0 #loc prim Primitive f<>
2420 0 #loc prim Primitive f<
2420 0 #loc prim Primitive f>
2420 0 #loc prim Primitive f<=
2420 0 #loc prim Primitive f>=
2421 0 #loc prim Primitive f0=
2421 0 #loc prim Primitive f0<>
2421 0 #loc prim Primitive f0<
2421 0 #loc prim Primitive f0>
2421 0 #loc prim Primitive f0<=
2421 0 #loc prim Primitive f0>=
2423 0 #loc prim Primitive s>f
2426 0 #loc prim Primitive d>f
2442 0 #loc prim Primitive f>d
2446 0 #loc prim Primitive f>s
2449 0 #loc prim Primitive f!
2453 0 #loc prim Primitive f@
2457 0 #loc prim Primitive df@
2465 0 #loc prim Primitive df!
2474 0 #loc prim Primitive sf@
2482 0 #loc prim Primitive sf!
2491 0 #loc prim Primitive f+
2494 0 #loc prim Primitive f-
2497 0 #loc prim Primitive f*
2500 0 #loc prim Primitive f/
2503 0 #loc prim Primitive f**
2509 0 #loc prim Primitive fm*
2512 0 #loc prim Primitive fm/
2515 0 #loc prim Primitive fm*/
2518 0 #loc prim Primitive f**2
2521 0 #loc prim Primitive fnegate
2524 0 #loc prim Primitive fdrop
2526 0 #loc prim Primitive fdup
2528 0 #loc prim Primitive fswap
2530 0 #loc prim Primitive fover
2532 0 #loc prim Primitive frot
2534 0 #loc prim Primitive fnip
2536 0 #loc prim Primitive ftuck
2538 0 #loc prim Primitive float+
2542 0 #loc prim Primitive floats
2546 0 #loc prim Primitive floor
2553 0 #loc prim Primitive fround
2559 0 #loc prim Primitive fmax
2565 0 #loc prim Primitive fmin
2571 0 #loc prim Primitive represent
2596 0 #loc prim Primitive >float
2610 0 #loc prim Primitive fabs
2613 0 #loc prim Primitive facos
2618 0 #loc prim Primitive fasin
2623 0 #loc prim Primitive fatan
2628 0 #loc prim Primitive fatan2
2635 0 #loc prim Primitive fcos
2640 0 #loc prim Primitive fexp
2645 0 #loc prim Primitive fexpm1
2660 0 #loc prim Primitive fln
2665 0 #loc prim Primitive flnp1
2680 0 #loc prim Primitive flog
2686 0 #loc prim Primitive falog
2693 0 #loc prim Primitive fsin
2698 0 #loc prim Primitive fsincos
2704 0 #loc prim Primitive fsqrt
2709 0 #loc prim Primitive ftan
2716 0 #loc prim Primitive fsinh
2723 0 #loc prim Primitive fcosh
2730 0 #loc prim Primitive ftanh
2737 0 #loc prim Primitive fasinh
2744 0 #loc prim Primitive facosh
2751 0 #loc prim Primitive fatanh
2759 0 #loc prim Primitive sfloats
2764 0 #loc prim Primitive dfloats
2769 0 #loc prim Primitive sfaligned
2776 0 #loc prim Primitive dfaligned
2783 0 #loc prim Primitive v*
2793 0 #loc prim Primitive faxpy
2801 0 #loc prim Primitive >float1
2815 0 #loc prim Primitive float/
2818 0 #loc prim Primitive dfloat/
2821 0 #loc prim Primitive sfloat/
2824 0 #loc prim Primitive f-rot
2826 0 #loc prim Primitive flit
81 groupadd
[THEN]
0 groupadd
has? glocals [IF]
0 groupadd
group  locals
2846 0 #loc prim Primitive @local#
2849 0 #loc prim Primitive @local0
2852 0 #loc prim Primitive @local1
2855 0 #loc prim Primitive @local2
2858 0 #loc prim Primitive @local3
5 groupadd
has? floating [IF]
2863 0 #loc prim Primitive f@local#
2866 0 #loc prim Primitive f@local0
2869 0 #loc prim Primitive f@local1
3 groupadd
[THEN]
2874 0 #loc prim Primitive laddr#
2878 0 #loc prim Primitive lp+!#
2884 0 #loc prim Primitive lp-
2887 0 #loc prim Primitive lp+
2890 0 #loc prim Primitive lp+2
2893 0 #loc prim Primitive lp!
2896 0 #loc prim Primitive >l
7 groupadd
has? floating [IF]
2902 0 #loc prim Primitive f>l
2906 0 #loc prim Primitive fpick
2 groupadd
[THEN]
0 groupadd
[THEN]
0 groupadd
has? OS [IF]
0 groupadd
group  syslib
2919 0 #loc prim Primitive open-lib
2922 0 #loc prim Primitive lib-sym
2938 0 #loc prim Primitive wcall
2943 0 #loc prim Primitive uw@
2949 0 #loc prim Primitive sw@
2955 0 #loc prim Primitive w!
2960 0 #loc prim Primitive ul@
2966 0 #loc prim Primitive sl@
2972 0 #loc prim Primitive l!
2977 0 #loc prim Primitive lib-error
2990 0 #loc prim Primitive be-w!
2999 0 #loc prim Primitive be-l!
3008 0 #loc prim Primitive le-w!
3017 0 #loc prim Primitive le-l!
3026 0 #loc prim Primitive be-uw@
3036 0 #loc prim Primitive be-ul@
3046 0 #loc prim Primitive le-uw@
3056 0 #loc prim Primitive le-ul@
3066 0 #loc prim Primitive close-lib
19 groupadd
[THEN]
0 groupadd
group  64bit
0 groupadd
has? 64bit [IF]
3075 0 #loc prim Primitive x!
3080 0 #loc prim Primitive ux@
3086 0 #loc prim Primitive sx@
3092 0 #loc prim Primitive be-x!
3102 0 #loc prim Primitive le-x!
3112 0 #loc prim Primitive be-ux@
3122 0 #loc prim Primitive le-ux@
7 groupadd
[THEN]
0 groupadd
group  memory
3136 0 #loc prim Primitive xd!
3160 0 #loc prim Primitive uxd@
3182 0 #loc prim Primitive sxd@
3204 0 #loc prim Primitive be-xd!
3236 0 #loc prim Primitive le-xd!
3268 0 #loc prim Primitive be-uxd@
3298 0 #loc prim Primitive le-uxd@
3328 0 #loc prim Primitive w><
3331 0 #loc prim Primitive l><
3334 0 #loc prim Primitive x><
3337 0 #loc prim Primitive xd><
3348 0 #loc prim Primitive c>s
3351 0 #loc prim Primitive w>s
3354 0 #loc prim Primitive l>s
3357 0 #loc prim Primitive >pow2
15 groupadd
group  atomic
3376 0 #loc prim Primitive !@
3385 0 #loc prim Primitive +!@
3394 0 #loc prim Primitive ?!@
3403 0 #loc prim Primitive barrier
4 groupadd
group  peephole
0 groupadd
has? peephole [IF]
3413 0 #loc prim Primitive compile-prim1
3417 0 #loc prim Primitive finish-code
3424 0 #loc prim Primitive forget-dyncode
3427 0 #loc prim Primitive decompile-prim
3435 0 #loc prim Primitive set-next-code
3440 0 #loc prim Primitive call2
3449 0 #loc prim Primitive tag-offsets
3453 0 #loc prim Primitive lp-trampoline
8 groupadd
[THEN]
0 groupadd
group  primitive_centric
3470 0 #loc prim Primitive abi-call
3477 0 #loc prim Primitive ;abi-code-exec
3485 0 #loc prim Primitive lit-execute
3 groupadd
group  object_pointer
0 groupadd
has? objects [IF]
3498 0 #loc prim Primitive >o
3502 0 #loc prim Primitive o>
3505 0 #loc prim Primitive o#+
3508 0 #loc prim Primitive o#exec
3516 0 #loc prim Primitive x#exec
3524 0 #loc prim Primitive u#exec
3532 0 #loc prim Primitive u#+
7 groupadd
[THEN]
0 groupadd
group  static_super
0 groupadd
group  end
