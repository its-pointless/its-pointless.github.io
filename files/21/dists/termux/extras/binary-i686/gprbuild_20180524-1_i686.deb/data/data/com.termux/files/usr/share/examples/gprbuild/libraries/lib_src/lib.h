extern void do_something (void);

