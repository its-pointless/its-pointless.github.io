void MVM_spesh_args(MVMThreadContext *tc, MVMSpeshGraph *g, MVMCallsite *cs,
    MVMSpeshStatsType *type_tuple);
void MVM_spesh_args_from_callinfo(MVMThreadContext *tc, MVMSpeshGraph *g,
    MVMSpeshCallInfo *call_info, MVMSpeshStatsType *type_tuple);
