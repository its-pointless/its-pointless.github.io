pub use crate::sys::cloudabi::shims::args::*;

#[allow(dead_code)]
pub fn init(_: isize, _: *const *const u8) {}

#[allow(dead_code)]
pub fn cleanup() {}
