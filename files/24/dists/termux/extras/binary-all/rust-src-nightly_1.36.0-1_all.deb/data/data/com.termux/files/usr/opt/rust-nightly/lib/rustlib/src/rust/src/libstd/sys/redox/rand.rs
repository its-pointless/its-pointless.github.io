pub fn hashmap_random_keys() -> (u64, u64) {
    (0, 0)
}
