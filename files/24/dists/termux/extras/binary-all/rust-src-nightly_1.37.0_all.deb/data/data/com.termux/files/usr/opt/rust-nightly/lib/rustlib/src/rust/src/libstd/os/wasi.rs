//! WASI-specific definitions

#![stable(feature = "raw_ext", since = "1.1.0")]

#[stable(feature = "rust1", since = "1.0.0")]
pub use crate::sys::ext::*;
