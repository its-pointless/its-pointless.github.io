void MVM_profile_start(MVMThreadContext *tc, MVMObject *config);
MVMObject * MVM_profile_end(MVMThreadContext *tc);
