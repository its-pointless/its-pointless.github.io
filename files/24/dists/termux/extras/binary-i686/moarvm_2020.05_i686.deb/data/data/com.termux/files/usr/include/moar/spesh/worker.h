void MVM_spesh_worker_start(MVMThreadContext *tc);
void MVM_spesh_worker_stop(MVMThreadContext *tc);
void MVM_spesh_worker_join(MVMThreadContext *tc);

