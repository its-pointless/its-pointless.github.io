#!/data/data/com.termux/files/usr/bin/env python3
xasyVersion = "2.65"
