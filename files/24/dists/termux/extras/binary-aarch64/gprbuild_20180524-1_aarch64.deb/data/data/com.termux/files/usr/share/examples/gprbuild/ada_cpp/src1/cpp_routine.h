extern "C" void cpp_routine ();
