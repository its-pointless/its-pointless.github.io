#if defined(_MSC_VER) && (_MSC_VER < 1800)
#include <msinttypes/stdint.h>
#else
#include <stdint.h>
#endif
