:- module(del_export, [p1/0, p2/0]).
p1.
p2.
%%%%%%%%%%%%%%%%
:- module(del_export, [p1/0]).
p1.
