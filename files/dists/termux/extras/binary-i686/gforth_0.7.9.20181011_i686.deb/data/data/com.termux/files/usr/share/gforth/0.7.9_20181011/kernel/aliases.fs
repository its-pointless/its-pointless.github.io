\ run-time routine headers

\ Copyright (C) 1997,1998,2002,2003,2006,2007,2010,2013,2015,2016 Free Software Foundation, Inc.

\ This file is part of Gforth.

\ Gforth is free software; you can redistribute it and/or
\ modify it under the terms of the GNU General Public License
\ as published by the Free Software Foundation, either version 3
\ of the License, or (at your option) any later version.

\ This program is distributed in the hope that it will be useful,
\ but WITHOUT ANY WARRANTY; without even the implied warranty of
\ MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
\ GNU General Public License for more details.

\ You should have received a copy of the GNU General Public License
\ along with this program. If not, see http://www.gnu.org/licenses/.

-2 Doer: :docol
-3 Doer: :docon
-4 Doer: :dovar
-5 Doer: :douser
-6 Doer: :dodefer
-7 Doer: :dofield
-8 Doer: :dovalue
-9 Doer: :dodoes
-&10 Doer: :doabicode
-&11 Doer: :do;abicode
-&12 Doer: :doextra
-&13 Doer: :dodoesxt
-&2 first-primitive
\ this does not work for (at least) (DODOES),
\ so the following routines are commented out
 0 [if]
154 0 #loc prim Primitive (docol)
172 0 #loc prim Primitive (docon)
180 0 #loc prim Primitive (dovar)
188 0 #loc prim Primitive (douser)
196 0 #loc prim Primitive (dodefer)
204 0 #loc prim Primitive (dofield)
212 0 #loc prim Primitive (dovalue)
220 0 #loc prim Primitive (dodoes)
239 0 #loc prim Primitive (doabicode)
250 0 #loc prim Primitive (do;abicode)
262 0 #loc prim Primitive (doextra)
281 0 #loc prim Primitive (dodoesxt)
 [endif]
12 groupadd
group  control
293 0 #loc prim Primitive noop
297 0 #loc prim Primitive call
315 0 #loc prim Primitive execute
326 0 #loc prim Primitive perform
337 0 #loc prim Primitive ;s
346 0 #loc prim Primitive execute-;s
355 0 #loc prim Primitive unloop
360 0 #loc prim Primitive lit-perform
367 0 #loc prim Primitive does-exec
384 0 #loc prim Primitive extra-exec
401 0 #loc prim Primitive does-xt
11 groupadd
has? glocals [IF]
420 0 #loc prim Primitive branch-lp+!#
1 groupadd
[THEN]
432 0 #loc prim Primitive branch
478 0 #loc prim Primitive ?branch
2 groupadd
has? glocals [IF]
478 0 #loc prim Primitive ?branch-lp+!#
1 groupadd
[THEN]
0 groupadd
has? xconds [IF]
491 0 #loc prim Primitive ?dup-?branch
505 0 #loc prim Primitive ?dup-0=-?branch
2 groupadd
[THEN]
has? skiploopprims 0= [IF]
520 0 #loc prim Primitive (next)
1 groupadd
has? glocals [IF]
520 0 #loc prim Primitive (next)-lp+!#
1 groupadd
[THEN]
527 0 #loc prim Primitive (loop)
1 groupadd
has? glocals [IF]
527 0 #loc prim Primitive (loop)-lp+!#
1 groupadd
[THEN]
535 0 #loc prim Primitive (+loop)
1 groupadd
has? glocals [IF]
535 0 #loc prim Primitive (+loop)-lp+!#
1 groupadd
[THEN]
0 groupadd
has? xconds [IF]
554 0 #loc prim Primitive (-loop)
1 groupadd
has? glocals [IF]
554 0 #loc prim Primitive (-loop)-lp+!#
1 groupadd
[THEN]
560 0 #loc prim Primitive (s+loop)
1 groupadd
has? glocals [IF]
560 0 #loc prim Primitive (s+loop)-lp+!#
1 groupadd
[THEN]
0 groupadd
[THEN]
577 0 #loc prim Primitive (for)
583 0 #loc prim Primitive (do)
587 0 #loc prim Primitive (?do)
3 groupadd
has? xconds [IF]
608 0 #loc prim Primitive (+do)
629 0 #loc prim Primitive (u+do)
650 0 #loc prim Primitive (-do)
671 0 #loc prim Primitive (u-do)
692 0 #loc prim Primitive (try)
701 0 #loc prim Primitive uncatch
704 0 #loc prim Primitive fast-throw
714 0 #loc prim Primitive pushwrap
722 0 #loc prim Primitive dropwrap
725 0 #loc prim Primitive exit-wrap
10 groupadd
[THEN]
739 0 #loc prim Primitive i
744 0 #loc prim Primitive i'
750 0 #loc prim Primitive j
756 0 #loc prim Primitive k
[THEN]
4 groupadd
group  strings
768 0 #loc prim Primitive move
777 0 #loc prim Primitive cmove
786 0 #loc prim Primitive cmove>
797 0 #loc prim Primitive fill
804 0 #loc prim Primitive compare
836 0 #loc prim Primitive toupper
843 0 #loc prim Primitive capscompare
852 0 #loc prim Primitive /string
860 0 #loc prim Primitive safe/string
9 groupadd
group  arith
875 0 #loc prim Primitive lit
879 0 #loc prim Primitive +
884 0 #loc prim Primitive lit+
891 0 #loc prim Primitive under+
897 0 #loc prim Primitive -
902 0 #loc prim Primitive negate
908 0 #loc prim Primitive 1+
913 0 #loc prim Primitive 1-
918 0 #loc prim Primitive max
926 0 #loc prim Primitive min
934 0 #loc prim Primitive abs
942 0 #loc prim Primitive *
947 0 #loc prim Primitive /
960 0 #loc prim Primitive mod
973 0 #loc prim Primitive /mod
988 0 #loc prim Primitive */mod
1012 0 #loc prim Primitive */
1035 0 #loc prim Primitive 2*
1041 0 #loc prim Primitive 2/
1052 0 #loc prim Primitive fm/mod
1071 0 #loc prim Primitive sm/rem
1086 0 #loc prim Primitive m*
1097 0 #loc prim Primitive um*
1113 0 #loc prim Primitive um/mod
1132 0 #loc prim Primitive m+
1142 0 #loc prim Primitive d+
1152 0 #loc prim Primitive d-
1162 0 #loc prim Primitive dnegate
1172 0 #loc prim Primitive d2*
1178 0 #loc prim Primitive d2/
1191 0 #loc prim Primitive and
1194 0 #loc prim Primitive or
1199 0 #loc prim Primitive xor
1202 0 #loc prim Primitive invert
1207 0 #loc prim Primitive rshift
1217 0 #loc prim Primitive lshift
1226 0 #loc prim Primitive umax
1234 0 #loc prim Primitive umin
1242 0 #loc prim Primitive mux
1248 0 #loc prim Primitive select
1254 0 #loc prim Primitive dlshift
1269 0 #loc prim Primitive drshift
1284 0 #loc prim Primitive rol
1288 0 #loc prim Primitive ror
1292 0 #loc prim Primitive drol
1311 0 #loc prim Primitive dror
1330 0 #loc prim Primitive du/mod
1348 0 #loc prim Primitive u/
1355 0 #loc prim Primitive umod
1362 0 #loc prim Primitive u/mod
1370 0 #loc prim Primitive arshift
1376 0 #loc prim Primitive darshift
52 groupadd
group  compare
1444 0 #loc prim Primitive 0=
1444 0 #loc prim Primitive 0<>
1444 0 #loc prim Primitive 0<
1444 0 #loc prim Primitive 0>
1444 0 #loc prim Primitive 0<=
1444 0 #loc prim Primitive 0>=
1445 0 #loc prim Primitive =
1445 0 #loc prim Primitive <>
1445 0 #loc prim Primitive <
1445 0 #loc prim Primitive >
1445 0 #loc prim Primitive <=
1445 0 #loc prim Primitive >=
1446 0 #loc prim Primitive u=
1446 0 #loc prim Primitive u<>
1446 0 #loc prim Primitive u<
1446 0 #loc prim Primitive u>
1446 0 #loc prim Primitive u<=
1446 0 #loc prim Primitive u>=
18 groupadd
has? dcomps [IF]
1496 0 #loc prim Primitive d=
1496 0 #loc prim Primitive d<>
1496 0 #loc prim Primitive d<
1496 0 #loc prim Primitive d>
1496 0 #loc prim Primitive d<=
1496 0 #loc prim Primitive d>=
1497 0 #loc prim Primitive d0=
1497 0 #loc prim Primitive d0<>
1497 0 #loc prim Primitive d0<
1497 0 #loc prim Primitive d0>
1497 0 #loc prim Primitive d0<=
1497 0 #loc prim Primitive d0>=
1498 0 #loc prim Primitive du=
1498 0 #loc prim Primitive du<>
1498 0 #loc prim Primitive du<
1498 0 #loc prim Primitive du>
1498 0 #loc prim Primitive du<=
1498 0 #loc prim Primitive du>=
18 groupadd
[THEN]
1502 0 #loc prim Primitive within
1 groupadd
group  stack
1516 0 #loc prim Primitive useraddr
1519 0 #loc prim Primitive up!
1525 0 #loc prim Primitive sp@
1528 0 #loc prim Primitive sp!
1531 0 #loc prim Primitive rp@
1534 0 #loc prim Primitive rp!
6 groupadd
has? floating [IF]
1539 0 #loc prim Primitive fp@
1542 0 #loc prim Primitive fp!
2 groupadd
[THEN]
1547 0 #loc prim Primitive >r
1552 0 #loc prim Primitive r>
1557 0 #loc prim Primitive rdrop
1561 0 #loc prim Primitive 2>r
1565 0 #loc prim Primitive 2r>
1569 0 #loc prim Primitive 2r@
1573 0 #loc prim Primitive 2rdrop
1577 0 #loc prim Primitive over
1581 0 #loc prim Primitive drop
1585 0 #loc prim Primitive swap
1590 0 #loc prim Primitive dup
1594 0 #loc prim Primitive rot
1603 0 #loc prim Primitive -rot
1607 0 #loc prim Primitive nip
1611 0 #loc prim Primitive tuck
1615 0 #loc prim Primitive ?dup
1624 0 #loc prim Primitive pick
1630 0 #loc prim Primitive 2drop
1634 0 #loc prim Primitive 2dup
1638 0 #loc prim Primitive 2over
1642 0 #loc prim Primitive 2swap
1646 0 #loc prim Primitive 2rot
1650 0 #loc prim Primitive 2nip
1654 0 #loc prim Primitive 2tuck
1658 0 #loc prim Primitive user@
1661 0 #loc prim Primitive sps@
26 groupadd
group  memory
1668 0 #loc prim Primitive @
1674 0 #loc prim Primitive lit@
1677 0 #loc prim Primitive !
1681 0 #loc prim Primitive +!
1687 0 #loc prim Primitive c@
1713 0 #loc prim Primitive c!
1743 0 #loc prim Primitive 2!
1750 0 #loc prim Primitive 2@
1758 0 #loc prim Primitive cell+
1764 0 #loc prim Primitive cells
1775 0 #loc prim Primitive char+
1781 0 #loc prim Primitive (chars)
1786 0 #loc prim Primitive count
1794 0 #loc prim Primitive cell/
1805 0 #loc prim Primitive cell-
15 groupadd
group  compiler
0 groupadd
has? f83headerstring [IF]
1815 0 #loc prim Primitive (f83find)
1 groupadd
[ELSE]
1845 0 #loc prim Primitive (listlfind)
1 groupadd
has? hash [IF]
1866 0 #loc prim Primitive (hashlfind)
1876 0 #loc prim Primitive (tablelfind)
1893 0 #loc prim Primitive (hashkey1)
1909 0 #loc prim Primitive (hashkey2)
1913 0 #loc prim Primitive hashkey2
5 groupadd
[THEN]
0 groupadd
[THEN]
1922 0 #loc prim Primitive (parse-white)
1932 0 #loc prim Primitive aligned
1938 0 #loc prim Primitive faligned
has? standardthreading has? compiler and [IF]
1946 0 #loc prim Primitive threading-method
1961 0 #loc prim Primitive debugging-method
[THEN]
5 groupadd
group  hostos
1975 0 #loc prim Primitive (key-file)
1989 0 #loc prim Primitive key?-file
2001 0 #loc prim Primitive stdin
2005 0 #loc prim Primitive stdout
2009 0 #loc prim Primitive stderr
5 groupadd
has? os [IF]
2015 0 #loc prim Primitive (form)
2028 0 #loc prim Primitive isatty
2032 0 #loc prim Primitive isfg
2040 0 #loc prim Primitive wcwidth
2044 0 #loc prim Primitive flush-icache
2056 0 #loc prim Primitive (bye)
2064 0 #loc prim Primitive (system)
2068 0 #loc prim Primitive getenv
2079 0 #loc prim Primitive open-pipe
2086 0 #loc prim Primitive close-pipe
2090 0 #loc prim Primitive time&date
2104 0 #loc prim Primitive (ms)
2108 0 #loc prim Primitive allocate
2117 0 #loc prim Primitive free
2125 0 #loc prim Primitive resize
2144 0 #loc prim Primitive strerror
2148 0 #loc prim Primitive strsignal
2152 0 #loc prim Primitive call-c
2165 0 #loc prim Primitive call-c#
2178 0 #loc prim Primitive gforth-pointers
20 groupadd
[THEN]
0 groupadd
has? file [IF]
2184 0 #loc prim Primitive close-file
2187 0 #loc prim Primitive open-file
2192 0 #loc prim Primitive create-file
2197 0 #loc prim Primitive delete-file
2202 0 #loc prim Primitive rename-file
2206 0 #loc prim Primitive file-position
2211 0 #loc prim Primitive reposition-file
2214 0 #loc prim Primitive file-size
2224 0 #loc prim Primitive resize-file
2227 0 #loc prim Primitive read-file
2238 0 #loc prim Primitive (read-line)
11 groupadd
[THEN]
2247 0 #loc prim Primitive write-file
2260 0 #loc prim Primitive emit-file
2 groupadd
has? file [IF]
2273 0 #loc prim Primitive flush-file
2276 0 #loc prim Primitive file-status
2281 0 #loc prim Primitive file-eof?
2284 0 #loc prim Primitive open-dir
2292 0 #loc prim Primitive read-dir
2320 0 #loc prim Primitive close-dir
2324 0 #loc prim Primitive filename-match
2334 0 #loc prim Primitive set-dir
2341 0 #loc prim Primitive get-dir
2351 0 #loc prim Primitive =mkdir
10 groupadd
[THEN]
2359 0 #loc prim Primitive newline
1 groupadd
has? os [IF]
2378 0 #loc prim Primitive utime
2384 0 #loc prim Primitive cputime
2402 0 #loc prim Primitive ntime
2415 0 #loc prim Primitive (ns)
4 groupadd
[THEN]
0 groupadd
has? floating [IF]
0 groupadd
group  floating
2435 0 #loc prim Primitive f=
2435 0 #loc prim Primitive f<>
2435 0 #loc prim Primitive f<
2435 0 #loc prim Primitive f>
2435 0 #loc prim Primitive f<=
2435 0 #loc prim Primitive f>=
2436 0 #loc prim Primitive f0=
2436 0 #loc prim Primitive f0<>
2436 0 #loc prim Primitive f0<
2436 0 #loc prim Primitive f0>
2436 0 #loc prim Primitive f0<=
2436 0 #loc prim Primitive f0>=
2438 0 #loc prim Primitive s>f
2441 0 #loc prim Primitive d>f
2457 0 #loc prim Primitive f>d
2461 0 #loc prim Primitive f>s
2464 0 #loc prim Primitive f!
2468 0 #loc prim Primitive f@
2472 0 #loc prim Primitive df@
2480 0 #loc prim Primitive df!
2489 0 #loc prim Primitive sf@
2497 0 #loc prim Primitive sf!
2506 0 #loc prim Primitive f+
2509 0 #loc prim Primitive f-
2512 0 #loc prim Primitive f*
2515 0 #loc prim Primitive f/
2518 0 #loc prim Primitive f**
2524 0 #loc prim Primitive fm*
2527 0 #loc prim Primitive fm/
2530 0 #loc prim Primitive fm*/
2533 0 #loc prim Primitive f**2
2536 0 #loc prim Primitive fnegate
2539 0 #loc prim Primitive fdrop
2541 0 #loc prim Primitive fdup
2543 0 #loc prim Primitive fswap
2545 0 #loc prim Primitive fover
2547 0 #loc prim Primitive frot
2549 0 #loc prim Primitive fnip
2551 0 #loc prim Primitive ftuck
2553 0 #loc prim Primitive float+
2557 0 #loc prim Primitive floats
2561 0 #loc prim Primitive floor
2568 0 #loc prim Primitive fround
2574 0 #loc prim Primitive fmax
2580 0 #loc prim Primitive fmin
2586 0 #loc prim Primitive represent
2611 0 #loc prim Primitive >float
2625 0 #loc prim Primitive fabs
2628 0 #loc prim Primitive facos
2633 0 #loc prim Primitive fasin
2638 0 #loc prim Primitive fatan
2643 0 #loc prim Primitive fatan2
2650 0 #loc prim Primitive fcos
2655 0 #loc prim Primitive fexp
2660 0 #loc prim Primitive fexpm1
2675 0 #loc prim Primitive fln
2680 0 #loc prim Primitive flnp1
2695 0 #loc prim Primitive flog
2701 0 #loc prim Primitive falog
2708 0 #loc prim Primitive fsin
2713 0 #loc prim Primitive fsincos
2719 0 #loc prim Primitive fsqrt
2724 0 #loc prim Primitive ftan
2731 0 #loc prim Primitive fsinh
2738 0 #loc prim Primitive fcosh
2745 0 #loc prim Primitive ftanh
2752 0 #loc prim Primitive fasinh
2759 0 #loc prim Primitive facosh
2766 0 #loc prim Primitive fatanh
2774 0 #loc prim Primitive sfloats
2779 0 #loc prim Primitive dfloats
2784 0 #loc prim Primitive sfaligned
2791 0 #loc prim Primitive dfaligned
2798 0 #loc prim Primitive v*
2808 0 #loc prim Primitive faxpy
2816 0 #loc prim Primitive >float1
2830 0 #loc prim Primitive float/
2833 0 #loc prim Primitive dfloat/
2836 0 #loc prim Primitive sfloat/
2839 0 #loc prim Primitive f-rot
2841 0 #loc prim Primitive flit
81 groupadd
[THEN]
0 groupadd
has? glocals [IF]
0 groupadd
group  locals
2861 0 #loc prim Primitive @local#
2864 0 #loc prim Primitive @local0
2867 0 #loc prim Primitive @local1
2870 0 #loc prim Primitive @local2
2873 0 #loc prim Primitive @local3
5 groupadd
has? floating [IF]
2878 0 #loc prim Primitive f@local#
2881 0 #loc prim Primitive f@local0
2884 0 #loc prim Primitive f@local1
3 groupadd
[THEN]
2889 0 #loc prim Primitive laddr#
2893 0 #loc prim Primitive lp+!#
2899 0 #loc prim Primitive lp-
2902 0 #loc prim Primitive lp+
2905 0 #loc prim Primitive lp+2
2908 0 #loc prim Primitive lp!
2911 0 #loc prim Primitive >l
7 groupadd
has? floating [IF]
2917 0 #loc prim Primitive f>l
2921 0 #loc prim Primitive fpick
2 groupadd
[THEN]
0 groupadd
[THEN]
0 groupadd
has? OS [IF]
0 groupadd
group  syslib
2934 0 #loc prim Primitive open-lib
2937 0 #loc prim Primitive lib-sym
2953 0 #loc prim Primitive wcall
2958 0 #loc prim Primitive uw@
2964 0 #loc prim Primitive sw@
2970 0 #loc prim Primitive w!
2975 0 #loc prim Primitive ul@
2981 0 #loc prim Primitive sl@
2987 0 #loc prim Primitive l!
2992 0 #loc prim Primitive lib-error
3005 0 #loc prim Primitive be-w!
3014 0 #loc prim Primitive be-l!
3023 0 #loc prim Primitive le-w!
3032 0 #loc prim Primitive le-l!
3041 0 #loc prim Primitive be-uw@
3051 0 #loc prim Primitive be-ul@
3061 0 #loc prim Primitive le-uw@
3071 0 #loc prim Primitive le-ul@
3081 0 #loc prim Primitive close-lib
19 groupadd
[THEN]
0 groupadd
group  64bit
0 groupadd
has? 64bit [IF]
3090 0 #loc prim Primitive x!
3095 0 #loc prim Primitive ux@
3101 0 #loc prim Primitive sx@
3107 0 #loc prim Primitive be-x!
3117 0 #loc prim Primitive le-x!
3127 0 #loc prim Primitive be-ux@
3137 0 #loc prim Primitive le-ux@
7 groupadd
[THEN]
0 groupadd
group  memory
3151 0 #loc prim Primitive xd!
3175 0 #loc prim Primitive uxd@
3197 0 #loc prim Primitive sxd@
3219 0 #loc prim Primitive be-xd!
3251 0 #loc prim Primitive le-xd!
3283 0 #loc prim Primitive be-uxd@
3313 0 #loc prim Primitive le-uxd@
3343 0 #loc prim Primitive w><
3346 0 #loc prim Primitive l><
3349 0 #loc prim Primitive x><
3352 0 #loc prim Primitive xd><
3363 0 #loc prim Primitive c>s
3366 0 #loc prim Primitive w>s
3369 0 #loc prim Primitive l>s
3372 0 #loc prim Primitive >pow2
15 groupadd
group  atomic
3391 0 #loc prim Primitive !@
3400 0 #loc prim Primitive +!@
3409 0 #loc prim Primitive ?!@
3418 0 #loc prim Primitive barrier
4 groupadd
group  peephole
0 groupadd
has? peephole [IF]
3428 0 #loc prim Primitive compile-prim1
3432 0 #loc prim Primitive finish-code
3439 0 #loc prim Primitive forget-dyncode
3442 0 #loc prim Primitive decompile-prim
3450 0 #loc prim Primitive set-next-code
3455 0 #loc prim Primitive call2
3464 0 #loc prim Primitive tag-offsets
3468 0 #loc prim Primitive lp-trampoline
8 groupadd
[THEN]
0 groupadd
group  primitive_centric
3485 0 #loc prim Primitive abi-call
3492 0 #loc prim Primitive ;abi-code-exec
3500 0 #loc prim Primitive lit-execute
3 groupadd
group  object_pointer
0 groupadd
has? objects [IF]
3513 0 #loc prim Primitive >o
3517 0 #loc prim Primitive o>
3520 0 #loc prim Primitive o#+
3523 0 #loc prim Primitive o#exec
3531 0 #loc prim Primitive x#exec
3539 0 #loc prim Primitive u#exec
3547 0 #loc prim Primitive u#+
7 groupadd
[THEN]
0 groupadd
group  static_super
0 groupadd
group  end
