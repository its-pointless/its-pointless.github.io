(function() {var implementors = {};
implementors["alloc"] = ["impl&lt;T&gt; <a class=\"trait\" href=\"core/ops/trait.Boxed.html\" title=\"trait core::ops::Boxed\">Boxed</a> for <a class=\"struct\" href=\"alloc/boxed/struct.Box.html\" title=\"struct alloc::boxed::Box\">Box</a>&lt;T&gt;",];
implementors["collections"] = ["impl&lt;T&gt; <a class=\"trait\" href=\"core/ops/trait.Boxed.html\" title=\"trait core::ops::Boxed\">Boxed</a> for <a class=\"struct\" href=\"collections/boxed/struct.Box.html\" title=\"struct collections::boxed::Box\">Box</a>&lt;T&gt;",];

            if (window.register_implementors) {
                window.register_implementors(implementors);
            } else {
                window.pending_implementors = implementors;
            }
        
})()
