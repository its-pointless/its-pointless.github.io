(function() {var implementors = {};
implementors["std"] = ["impl&lt;'a, 'b&gt; <a class=\"trait\" href=\"std/str/pattern/trait.Pattern.html\" title=\"trait std::str::pattern::Pattern\">Pattern</a>&lt;'a&gt; for &amp;'b <a class=\"struct\" href=\"std/string/struct.String.html\" title=\"struct std::string::String\">String</a>",];

            if (window.register_implementors) {
                window.register_implementors(implementors);
            } else {
                window.pending_implementors = implementors;
            }
        
})()
