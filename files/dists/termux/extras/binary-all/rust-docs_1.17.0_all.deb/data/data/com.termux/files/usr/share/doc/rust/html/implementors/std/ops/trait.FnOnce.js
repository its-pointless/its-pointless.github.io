(function() {var implementors = {};
implementors["std"] = ["impl&lt;'a, A, R&gt; <a class=\"trait\" href=\"std/ops/trait.FnOnce.html\" title=\"trait std::ops::FnOnce\">FnOnce</a>&lt;A&gt; for <a class=\"struct\" href=\"std/boxed/struct.Box.html\" title=\"struct std::boxed::Box\">Box</a>&lt;<a class=\"trait\" href=\"std/boxed/trait.FnBox.html\" title=\"trait std::boxed::FnBox\">FnBox</a>&lt;A, Output=R&gt; + 'a&gt;","impl&lt;'a, A, R&gt; <a class=\"trait\" href=\"std/ops/trait.FnOnce.html\" title=\"trait std::ops::FnOnce\">FnOnce</a>&lt;A&gt; for <a class=\"struct\" href=\"std/boxed/struct.Box.html\" title=\"struct std::boxed::Box\">Box</a>&lt;<a class=\"trait\" href=\"std/boxed/trait.FnBox.html\" title=\"trait std::boxed::FnBox\">FnBox</a>&lt;A, Output=R&gt; + 'a + <a class=\"trait\" href=\"std/marker/trait.Send.html\" title=\"trait std::marker::Send\">Send</a>&gt;","impl&lt;R, F:&nbsp;<a class=\"trait\" href=\"std/ops/trait.FnOnce.html\" title=\"trait std::ops::FnOnce\">FnOnce</a>() -&gt; R&gt; <a class=\"trait\" href=\"std/ops/trait.FnOnce.html\" title=\"trait std::ops::FnOnce\">FnOnce</a>&lt;<a class=\"primitive\" href=\"primitive.tuple.html\">()</a>&gt; for <a class=\"struct\" href=\"std/panic/struct.AssertUnwindSafe.html\" title=\"struct std::panic::AssertUnwindSafe\">AssertUnwindSafe</a>&lt;F&gt;",];

            if (window.register_implementors) {
                window.register_implementors(implementors);
            } else {
                window.pending_implementors = implementors;
            }
        
})()
