(function() {var implementors = {};
implementors["collections"] = [];
implementors["std"] = [];

            if (window.register_implementors) {
                window.register_implementors(implementors);
            } else {
                window.pending_implementors = implementors;
            }
        
})()
