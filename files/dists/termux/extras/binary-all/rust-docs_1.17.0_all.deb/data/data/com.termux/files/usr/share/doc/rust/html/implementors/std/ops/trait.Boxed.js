(function() {var implementors = {};
implementors["std"] = ["impl&lt;T&gt; <a class=\"trait\" href=\"std/ops/trait.Boxed.html\" title=\"trait std::ops::Boxed\">Boxed</a> for <a class=\"struct\" href=\"std/boxed/struct.Box.html\" title=\"struct std::boxed::Box\">Box</a>&lt;T&gt;",];

            if (window.register_implementors) {
                window.register_implementors(implementors);
            } else {
                window.pending_implementors = implementors;
            }
        
})()
