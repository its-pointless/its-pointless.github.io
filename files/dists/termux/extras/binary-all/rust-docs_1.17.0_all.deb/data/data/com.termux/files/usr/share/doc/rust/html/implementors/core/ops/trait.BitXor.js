(function() {var implementors = {};
implementors["collections"] = ["impl&lt;'a, 'b, T:&nbsp;<a class=\"trait\" href=\"core/cmp/trait.Ord.html\" title=\"trait core::cmp::Ord\">Ord</a> + <a class=\"trait\" href=\"core/clone/trait.Clone.html\" title=\"trait core::clone::Clone\">Clone</a>&gt; <a class=\"trait\" href=\"core/ops/trait.BitXor.html\" title=\"trait core::ops::BitXor\">BitXor</a>&lt;&amp;'b <a class=\"struct\" href=\"collections/btree_set/struct.BTreeSet.html\" title=\"struct collections::btree_set::BTreeSet\">BTreeSet</a>&lt;T&gt;&gt; for &amp;'a <a class=\"struct\" href=\"collections/btree_set/struct.BTreeSet.html\" title=\"struct collections::btree_set::BTreeSet\">BTreeSet</a>&lt;T&gt;","impl&lt;E:&nbsp;<a class=\"trait\" href=\"collections/enum_set/trait.CLike.html\" title=\"trait collections::enum_set::CLike\">CLike</a>&gt; <a class=\"trait\" href=\"core/ops/trait.BitXor.html\" title=\"trait core::ops::BitXor\">BitXor</a> for <a class=\"struct\" href=\"collections/enum_set/struct.EnumSet.html\" title=\"struct collections::enum_set::EnumSet\">EnumSet</a>&lt;E&gt;",];
implementors["core"] = [];
implementors["std_unicode"] = [];

            if (window.register_implementors) {
                window.register_implementors(implementors);
            } else {
                window.pending_implementors = implementors;
            }
        
})()
