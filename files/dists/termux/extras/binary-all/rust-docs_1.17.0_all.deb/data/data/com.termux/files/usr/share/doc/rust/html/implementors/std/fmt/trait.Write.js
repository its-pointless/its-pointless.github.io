(function() {var implementors = {};
implementors["std"] = ["impl <a class=\"trait\" href=\"std/fmt/trait.Write.html\" title=\"trait std::fmt::Write\">Write</a> for <a class=\"struct\" href=\"std/string/struct.String.html\" title=\"struct std::string::String\">String</a>",];

            if (window.register_implementors) {
                window.register_implementors(implementors);
            } else {
                window.pending_implementors = implementors;
            }
        
})()
