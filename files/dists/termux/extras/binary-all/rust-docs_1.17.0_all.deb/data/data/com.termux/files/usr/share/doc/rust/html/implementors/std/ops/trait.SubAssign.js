(function() {var implementors = {};
implementors["std"] = ["impl <a class=\"trait\" href=\"std/ops/trait.SubAssign.html\" title=\"trait std::ops::SubAssign\">SubAssign</a> for <a class=\"struct\" href=\"std/time/struct.Duration.html\" title=\"struct std::time::Duration\">Duration</a>","impl <a class=\"trait\" href=\"std/ops/trait.SubAssign.html\" title=\"trait std::ops::SubAssign\">SubAssign</a>&lt;<a class=\"struct\" href=\"std/time/struct.Duration.html\" title=\"struct std::time::Duration\">Duration</a>&gt; for <a class=\"struct\" href=\"std/time/struct.Instant.html\" title=\"struct std::time::Instant\">Instant</a>","impl <a class=\"trait\" href=\"std/ops/trait.SubAssign.html\" title=\"trait std::ops::SubAssign\">SubAssign</a>&lt;<a class=\"struct\" href=\"std/time/struct.Duration.html\" title=\"struct std::time::Duration\">Duration</a>&gt; for <a class=\"struct\" href=\"std/time/struct.SystemTime.html\" title=\"struct std::time::SystemTime\">SystemTime</a>",];

            if (window.register_implementors) {
                window.register_implementors(implementors);
            } else {
                window.pending_implementors = implementors;
            }
        
})()
