(function() {var implementors = {};
implementors["collections"] = ["impl&lt;T&gt; <a class=\"trait\" href=\"collections/fmt/trait.Pointer.html\" title=\"trait collections::fmt::Pointer\">Pointer</a> for <a class=\"struct\" href=\"collections/boxed/struct.Box.html\" title=\"struct collections::boxed::Box\">Box</a>&lt;T&gt; <span class=\"where fmt-newline\">where T: ?<a class=\"trait\" href=\"core/marker/trait.Sized.html\" title=\"trait core::marker::Sized\">Sized</a></span>","impl&lt;T&gt; <a class=\"trait\" href=\"collections/fmt/trait.Pointer.html\" title=\"trait collections::fmt::Pointer\">Pointer</a> for <a class=\"struct\" href=\"alloc/arc/struct.Arc.html\" title=\"struct alloc::arc::Arc\">Arc</a>&lt;T&gt; <span class=\"where fmt-newline\">where T: ?<a class=\"trait\" href=\"core/marker/trait.Sized.html\" title=\"trait core::marker::Sized\">Sized</a></span>","impl&lt;T&gt; <a class=\"trait\" href=\"collections/fmt/trait.Pointer.html\" title=\"trait collections::fmt::Pointer\">Pointer</a> for <a class=\"struct\" href=\"alloc/rc/struct.Rc.html\" title=\"struct alloc::rc::Rc\">Rc</a>&lt;T&gt; <span class=\"where fmt-newline\">where T: ?<a class=\"trait\" href=\"core/marker/trait.Sized.html\" title=\"trait core::marker::Sized\">Sized</a></span>",];

            if (window.register_implementors) {
                window.register_implementors(implementors);
            } else {
                window.pending_implementors = implementors;
            }
        
})()
