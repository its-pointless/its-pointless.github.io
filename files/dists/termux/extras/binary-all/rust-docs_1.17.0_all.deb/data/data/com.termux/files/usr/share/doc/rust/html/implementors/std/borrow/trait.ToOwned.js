(function() {var implementors = {};
implementors["std"] = ["impl <a class=\"trait\" href=\"std/borrow/trait.ToOwned.html\" title=\"trait std::borrow::ToOwned\">ToOwned</a> for <a class=\"struct\" href=\"std/ffi/struct.CStr.html\" title=\"struct std::ffi::CStr\">CStr</a>","impl <a class=\"trait\" href=\"std/borrow/trait.ToOwned.html\" title=\"trait std::borrow::ToOwned\">ToOwned</a> for <a class=\"struct\" href=\"std/ffi/struct.OsStr.html\" title=\"struct std::ffi::OsStr\">OsStr</a>","impl <a class=\"trait\" href=\"std/borrow/trait.ToOwned.html\" title=\"trait std::borrow::ToOwned\">ToOwned</a> for <a class=\"struct\" href=\"std/path/struct.Path.html\" title=\"struct std::path::Path\">Path</a>",];

            if (window.register_implementors) {
                window.register_implementors(implementors);
            } else {
                window.pending_implementors = implementors;
            }
        
})()
