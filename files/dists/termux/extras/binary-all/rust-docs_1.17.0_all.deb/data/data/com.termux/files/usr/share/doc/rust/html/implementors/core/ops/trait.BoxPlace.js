(function() {var implementors = {};
implementors["alloc"] = ["impl&lt;T&gt; <a class=\"trait\" href=\"core/ops/trait.BoxPlace.html\" title=\"trait core::ops::BoxPlace\">BoxPlace</a>&lt;T&gt; for <a class=\"struct\" href=\"alloc/boxed/struct.IntermediateBox.html\" title=\"struct alloc::boxed::IntermediateBox\">IntermediateBox</a>&lt;T&gt;",];
implementors["collections"] = ["impl&lt;T&gt; <a class=\"trait\" href=\"core/ops/trait.BoxPlace.html\" title=\"trait core::ops::BoxPlace\">BoxPlace</a>&lt;T&gt; for <a class=\"struct\" href=\"collections/boxed/struct.IntermediateBox.html\" title=\"struct collections::boxed::IntermediateBox\">IntermediateBox</a>&lt;T&gt;",];

            if (window.register_implementors) {
                window.register_implementors(implementors);
            } else {
                window.pending_implementors = implementors;
            }
        
})()
