(function() {var implementors = {};
implementors["std"] = ["impl <a class=\"trait\" href=\"std/ops/trait.Div.html\" title=\"trait std::ops::Div\">Div</a>&lt;<a class=\"primitive\" href=\"primitive.u32.html\">u32</a>&gt; for <a class=\"struct\" href=\"std/time/struct.Duration.html\" title=\"struct std::time::Duration\">Duration</a>",];

            if (window.register_implementors) {
                window.register_implementors(implementors);
            } else {
                window.pending_implementors = implementors;
            }
        
})()
