(function() {var implementors = {};
implementors["collections"] = ["impl&lt;'a&gt; <a class=\"trait\" href=\"core/ops/trait.AddAssign.html\" title=\"trait core::ops::AddAssign\">AddAssign</a>&lt;&amp;'a str&gt; for <a class=\"enum\" href=\"collections/borrow/enum.Cow.html\" title=\"enum collections::borrow::Cow\">Cow</a>&lt;'a, str&gt;","impl&lt;'a&gt; <a class=\"trait\" href=\"core/ops/trait.AddAssign.html\" title=\"trait core::ops::AddAssign\">AddAssign</a>&lt;<a class=\"enum\" href=\"collections/borrow/enum.Cow.html\" title=\"enum collections::borrow::Cow\">Cow</a>&lt;'a, str&gt;&gt; for <a class=\"enum\" href=\"collections/borrow/enum.Cow.html\" title=\"enum collections::borrow::Cow\">Cow</a>&lt;'a, str&gt;","impl&lt;'a&gt; <a class=\"trait\" href=\"core/ops/trait.AddAssign.html\" title=\"trait core::ops::AddAssign\">AddAssign</a>&lt;&amp;'a str&gt; for <a class=\"struct\" href=\"collections/string/struct.String.html\" title=\"struct collections::string::String\">String</a>",];
implementors["core"] = [];
implementors["std_unicode"] = [];

            if (window.register_implementors) {
                window.register_implementors(implementors);
            } else {
                window.pending_implementors = implementors;
            }
        
})()
