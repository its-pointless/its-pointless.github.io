(function() {var implementors = {};
implementors["collections"] = ["impl <a class=\"trait\" href=\"collections/str/trait.FromStr.html\" title=\"trait collections::str::FromStr\">FromStr</a> for <a class=\"struct\" href=\"collections/string/struct.String.html\" title=\"struct collections::string::String\">String</a>",];

            if (window.register_implementors) {
                window.register_implementors(implementors);
            } else {
                window.pending_implementors = implementors;
            }
        
})()
