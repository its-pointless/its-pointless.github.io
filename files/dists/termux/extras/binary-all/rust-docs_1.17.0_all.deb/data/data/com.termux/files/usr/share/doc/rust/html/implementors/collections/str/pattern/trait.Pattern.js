(function() {var implementors = {};
implementors["collections"] = ["impl&lt;'a, 'b&gt; <a class=\"trait\" href=\"collections/str/pattern/trait.Pattern.html\" title=\"trait collections::str::pattern::Pattern\">Pattern</a>&lt;'a&gt; for &amp;'b <a class=\"struct\" href=\"collections/string/struct.String.html\" title=\"struct collections::string::String\">String</a>",];

            if (window.register_implementors) {
                window.register_implementors(implementors);
            } else {
                window.pending_implementors = implementors;
            }
        
})()
