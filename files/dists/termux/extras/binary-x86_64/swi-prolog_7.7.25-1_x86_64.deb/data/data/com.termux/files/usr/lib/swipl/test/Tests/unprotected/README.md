# Unprotected tests

This   directory   contains   tests   that     cannot    function   with
`protect_static_code` enabled. As core/test_db.pl  tests the functioning
of this flag and setting this flag cannot   be  undone we must run these
tests first.
