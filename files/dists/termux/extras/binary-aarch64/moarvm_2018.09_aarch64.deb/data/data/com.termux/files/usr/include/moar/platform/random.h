MVMint32 MVM_getrandom (MVMThreadContext *tc, void *out, size_t size);
