#!/data/data/com.termux/files/usr/bin/env python
xasyVersion = "2.41"
