\ This file has been generated using SWIG and fsi,
\ and is already platform dependent, search for the corresponding
\ fsi-file to compile it where no one has compiled it before ;)
\ Forth systems have their own own dynamic loader and don't need addional C-Code.
\ That's why this file will just print normal forth-code once compiled
\ and can be used directly with include or require.
\ As all comments are stripped during the compilation, please
\ insert the copyright notice of the original file here.

\ ----===< int constants ===>-----
#1	constant XA_DOMAINTYPE_AUDIO
#2	constant XA_DOMAINTYPE_VIDEO
#3	constant XA_DOMAINTYPE_IMAGE
#4	constant XA_DOMAINTYPE_TIMEDTEXT
#5	constant XA_DOMAINTYPE_MIDI
#4294967294	constant XA_DOMAINTYPE_VENDOR
#4294967295	constant XA_DOMAINTYPE_UNKNOWN
#1	constant XA_MIDIBANK_DEVICE
#2	constant XA_MIDIBANK_CUSTOM
#4294967295	constant XA_MIDI_UNKNOWN

\ -------===< structs >===--------
\ XAInterfaceID_
begin-structure XAInterfaceID_
	drop 10 6 +field XAInterfaceID-node
	drop 0 4 +field XAInterfaceID-time_low
	drop 6 2 +field XAInterfaceID-time_hi_and_version
	drop 8 2 +field XAInterfaceID-clock_seq
	drop 4 2 +field XAInterfaceID-time_mid
drop 16 end-structure
\ XAObjectItf_
begin-structure XAObjectItf_
	drop 24 8 +field XAObjectItf-GetInterface
	drop 56 8 +field XAObjectItf-SetPriority
	drop 64 8 +field XAObjectItf-GetPriority
	drop 16 8 +field XAObjectItf-GetState
	drop 48 8 +field XAObjectItf-Destroy
	drop 40 8 +field XAObjectItf-AbortAsyncOperation
	drop 8 8 +field XAObjectItf-Resume
	drop 0 8 +field XAObjectItf-Realize
	drop 32 8 +field XAObjectItf-RegisterCallback
	drop 72 8 +field XAObjectItf-SetLossOfControlInterfaces
drop 80 end-structure
\ XAConfigExtensionsItf_
begin-structure XAConfigExtensionsItf_
	drop 0 8 +field XAConfigExtensionsItf-SetConfiguration
	drop 8 8 +field XAConfigExtensionsItf-GetConfiguration
drop 16 end-structure
\ XADynamicInterfaceManagementItf_
begin-structure XADynamicInterfaceManagementItf_
	drop 0 8 +field XADynamicInterfaceManagementItf-AddInterface
	drop 8 8 +field XADynamicInterfaceManagementItf-RemoveInterface
	drop 16 8 +field XADynamicInterfaceManagementItf-ResumeInterface
	drop 24 8 +field XADynamicInterfaceManagementItf-RegisterCallback
drop 32 end-structure
\ XADataSink
begin-structure XADataSink
drop 16 end-structure
\ XADataSource
begin-structure XADataSource
drop 16 end-structure
\ XADataFormat_MIME
begin-structure XADataFormat_MIME
drop 24 end-structure
\ XADataFormat_PCM
begin-structure XADataFormat_PCM
drop 28 end-structure
\ XADataFormat_RawImage
begin-structure XADataFormat_RawImage
drop 20 end-structure
\ XADataLocator_Address
begin-structure XADataLocator_Address
drop 24 end-structure
\ XADataLocator_IODevice
begin-structure XADataLocator_IODevice
drop 24 end-structure
\ XADataLocator_NativeDisplay
begin-structure XADataLocator_NativeDisplay
drop 24 end-structure
\ XADataLocator_OutputMix
begin-structure XADataLocator_OutputMix
	drop 8 8 +field XADataLocator_OutputMix-outputMix
	drop 0 4 +field XADataLocator_OutputMix-locatorType
drop 16 end-structure
\ XADataLocator_URI
begin-structure XADataLocator_URI
drop 16 end-structure
\ XAEngineOption
begin-structure XAEngineOption
drop 8 end-structure
\ XALEDDescriptor
begin-structure XALEDDescriptor
drop 8 end-structure
\ XAVibraDescriptor
begin-structure XAVibraDescriptor
drop 16 end-structure
\ XAEngineItf_
begin-structure XAEngineItf_
	drop 16 8 +field XAEngineItf-CreateLEDDevice
	drop 48 8 +field XAEngineItf-CreateOutputMix
	drop 64 8 +field XAEngineItf-CreateExtensionObject
	drop 128 8 +field XAEngineItf-QueryLEDCapabilities
	drop 136 8 +field XAEngineItf-QueryVibraCapabilities
	drop 72 8 +field XAEngineItf-GetImplementationInfo
	drop 104 8 +field XAEngineItf-QueryNumSupportedExtensions
	drop 80 8 +field XAEngineItf-QuerySupportedProfiles
	drop 56 8 +field XAEngineItf-CreateMetadataExtractor
	drop 40 8 +field XAEngineItf-CreateMediaRecorder
	drop 96 8 +field XAEngineItf-QuerySupportedInterfaces
	drop 88 8 +field XAEngineItf-QueryNumSupportedInterfaces
	drop 24 8 +field XAEngineItf-CreateVibraDevice
	drop 8 8 +field XAEngineItf-CreateRadioDevice
	drop 0 8 +field XAEngineItf-CreateCameraDevice
	drop 120 8 +field XAEngineItf-IsExtensionSupported
	drop 112 8 +field XAEngineItf-QuerySupportedExtension
	drop 32 8 +field XAEngineItf-CreateMediaPlayer
drop 144 end-structure
\ XAThreadSyncItf_
begin-structure XAThreadSyncItf_
	drop 0 8 +field XAThreadSyncItf-EnterCriticalSection
	drop 8 8 +field XAThreadSyncItf-ExitCriticalSection
drop 16 end-structure
\ XAPlayItf_
begin-structure XAPlayItf_
	drop 24 8 +field XAPlayItf-GetPosition
	drop 56 8 +field XAPlayItf-SetMarkerPosition
	drop 64 8 +field XAPlayItf-ClearMarkerPosition
	drop 72 8 +field XAPlayItf-GetMarkerPosition
	drop 16 8 +field XAPlayItf-GetDuration
	drop 40 8 +field XAPlayItf-SetCallbackEventsMask
	drop 48 8 +field XAPlayItf-GetCallbackEventsMask
	drop 80 8 +field XAPlayItf-SetPositionUpdatePeriod
	drop 88 8 +field XAPlayItf-GetPositionUpdatePeriod
	drop 0 8 +field XAPlayItf-SetPlayState
	drop 8 8 +field XAPlayItf-GetPlayState
	drop 32 8 +field XAPlayItf-RegisterCallback
drop 96 end-structure
\ XAPlaybackRateItf_
begin-structure XAPlaybackRateItf_
	drop 40 8 +field XAPlaybackRateItf-GetRateRange
	drop 24 8 +field XAPlaybackRateItf-GetProperties
	drop 0 8 +field XAPlaybackRateItf-SetRate
	drop 8 8 +field XAPlaybackRateItf-GetRate
	drop 16 8 +field XAPlaybackRateItf-SetPropertyConstraints
	drop 32 8 +field XAPlaybackRateItf-GetCapabilitiesOfRate
drop 48 end-structure
\ XAPrefetchStatusItf_
begin-structure XAPrefetchStatusItf_
	drop 0 8 +field XAPrefetchStatusItf-GetPrefetchStatus
	drop 8 8 +field XAPrefetchStatusItf-GetFillLevel
	drop 24 8 +field XAPrefetchStatusItf-SetCallbackEventsMask
	drop 32 8 +field XAPrefetchStatusItf-GetCallbackEventsMask
	drop 40 8 +field XAPrefetchStatusItf-SetFillUpdatePeriod
	drop 48 8 +field XAPrefetchStatusItf-GetFillUpdatePeriod
	drop 16 8 +field XAPrefetchStatusItf-RegisterCallback
drop 56 end-structure
\ XASeekItf_
begin-structure XASeekItf_
	drop 0 8 +field XASeekItf-SetPosition
	drop 8 8 +field XASeekItf-SetLoop
	drop 16 8 +field XASeekItf-GetLoop
drop 24 end-structure
\ XAVolumeItf_
begin-structure XAVolumeItf_
	drop 0 8 +field XAVolumeItf-SetVolumeLevel
	drop 8 8 +field XAVolumeItf-GetVolumeLevel
	drop 16 8 +field XAVolumeItf-GetMaxVolumeLevel
	drop 40 8 +field XAVolumeItf-EnableStereoPosition
	drop 48 8 +field XAVolumeItf-IsEnabledStereoPosition
	drop 56 8 +field XAVolumeItf-SetStereoPosition
	drop 64 8 +field XAVolumeItf-GetStereoPosition
	drop 24 8 +field XAVolumeItf-SetMute
	drop 32 8 +field XAVolumeItf-GetMute
drop 72 end-structure
\ XAImageControlsItf_
begin-structure XAImageControlsItf_
	drop 0 8 +field XAImageControlsItf-SetBrightness
	drop 8 8 +field XAImageControlsItf-GetBrightness
	drop 32 8 +field XAImageControlsItf-SetGamma
	drop 40 8 +field XAImageControlsItf-GetGamma
	drop 16 8 +field XAImageControlsItf-SetContrast
	drop 24 8 +field XAImageControlsItf-GetContrast
	drop 48 8 +field XAImageControlsItf-GetSupportedGammaSettings
drop 56 end-structure
\ XAImageEffectsItf_
begin-structure XAImageEffectsItf_
	drop 24 8 +field XAImageEffectsItf-IsImageEffectEnabled
	drop 0 8 +field XAImageEffectsItf-QuerySupportedImageEffects
	drop 8 8 +field XAImageEffectsItf-EnableImageEffect
	drop 16 8 +field XAImageEffectsItf-DisableImageEffect
drop 32 end-structure
\ XARectangle
begin-structure XARectangle
drop 16 end-structure
\ XAVideoPostProcessingItf_
begin-structure XAVideoPostProcessingItf_
	drop 40 8 +field XAVideoPostProcessingItf-SetMirror
	drop 24 8 +field XAVideoPostProcessingItf-SetSourceRectangle
	drop 32 8 +field XAVideoPostProcessingItf-SetDestinationRectangle
	drop 8 8 +field XAVideoPostProcessingItf-IsArbitraryRotationSupported
	drop 48 8 +field XAVideoPostProcessingItf-Commit
	drop 0 8 +field XAVideoPostProcessingItf-SetRotation
	drop 16 8 +field XAVideoPostProcessingItf-SetScaleOptions
drop 56 end-structure
\ XARecordItf_
begin-structure XARecordItf_
	drop 16 8 +field XARecordItf-SetDurationLimit
	drop 24 8 +field XARecordItf-GetPosition
	drop 56 8 +field XARecordItf-SetMarkerPosition
	drop 64 8 +field XARecordItf-ClearMarkerPosition
	drop 72 8 +field XARecordItf-GetMarkerPosition
	drop 40 8 +field XARecordItf-SetCallbackEventsMask
	drop 48 8 +field XARecordItf-GetCallbackEventsMask
	drop 80 8 +field XARecordItf-SetPositionUpdatePeriod
	drop 88 8 +field XARecordItf-GetPositionUpdatePeriod
	drop 0 8 +field XARecordItf-SetRecordState
	drop 8 8 +field XARecordItf-GetRecordState
	drop 32 8 +field XARecordItf-RegisterCallback
drop 96 end-structure
\ XASnapshotItf_
begin-structure XASnapshotItf_
	drop 48 8 +field XASnapshotItf-SetShutterFeedback
	drop 56 8 +field XASnapshotItf-GetShutterFeedback
	drop 24 8 +field XASnapshotItf-ReleaseBuffers
	drop 32 8 +field XASnapshotItf-GetMaxPicsPerBurst
	drop 0 8 +field XASnapshotItf-InitiateSnapshot
	drop 8 8 +field XASnapshotItf-TakeSnapshot
	drop 16 8 +field XASnapshotItf-CancelSnapshot
	drop 40 8 +field XASnapshotItf-GetBurstFPSRange
drop 64 end-structure
\ XAMetadataInfo
begin-structure XAMetadataInfo
drop 28 end-structure
\ XAMetadataExtractionItf_
begin-structure XAMetadataExtractionItf_
	drop 40 8 +field XAMetadataExtractionItf-AddKeyFilter
	drop 48 8 +field XAMetadataExtractionItf-ClearKeyFilter
	drop 8 8 +field XAMetadataExtractionItf-GetKeySize
	drop 0 8 +field XAMetadataExtractionItf-GetItemCount
	drop 16 8 +field XAMetadataExtractionItf-GetKey
	drop 24 8 +field XAMetadataExtractionItf-GetValueSize
	drop 32 8 +field XAMetadataExtractionItf-GetValue
drop 56 end-structure
\ XAMetadataInsertionItf_
begin-structure XAMetadataInsertionItf_
	drop 0 8 +field XAMetadataInsertionItf-CreateChildNode
	drop 40 8 +field XAMetadataInsertionItf-InsertMetadataItem
	drop 32 8 +field XAMetadataInsertionItf-GetFreeKeysEncoding
	drop 8 8 +field XAMetadataInsertionItf-GetSupportedKeysCount
	drop 16 8 +field XAMetadataInsertionItf-GetKeySize
	drop 24 8 +field XAMetadataInsertionItf-GetKey
	drop 48 8 +field XAMetadataInsertionItf-RegisterCallback
drop 56 end-structure
\ XAMetadataTraversalItf_
begin-structure XAMetadataTraversalItf_
	drop 0 8 +field XAMetadataTraversalItf-SetMode
	drop 8 8 +field XAMetadataTraversalItf-GetChildCount
	drop 16 8 +field XAMetadataTraversalItf-GetChildMIMETypeSize
	drop 32 8 +field XAMetadataTraversalItf-SetActiveNode
	drop 24 8 +field XAMetadataTraversalItf-GetChildInfo
drop 40 end-structure
\ XADynamicSourceItf_
begin-structure XADynamicSourceItf_
	drop 0 8 +field XADynamicSourceItf-SetSource
drop 8 end-structure
\ XAFocusPointPosition
begin-structure XAFocusPointPosition
drop 16 end-structure
\ XACameraDescriptor
begin-structure XACameraDescriptor
drop 48 end-structure
\ XACameraCapabilitiesItf_
begin-structure XACameraCapabilitiesItf_
	drop 0 8 +field XACameraCapabilitiesItf-GetCameraCapabilities
	drop 8 8 +field XACameraCapabilitiesItf-QueryFocusRegionPatterns
	drop 16 8 +field XACameraCapabilitiesItf-GetSupportedAutoLocks
	drop 24 8 +field XACameraCapabilitiesItf-GetSupportedFocusManualSettings
	drop 32 8 +field XACameraCapabilitiesItf-GetSupportedISOSensitivitySettings
	drop 40 8 +field XACameraCapabilitiesItf-GetSupportedApertureManualSettings
	drop 48 8 +field XACameraCapabilitiesItf-GetSupportedShutterSpeedManualSettings
	drop 56 8 +field XACameraCapabilitiesItf-GetSupportedWhiteBalanceManualSettings
	drop 64 8 +field XACameraCapabilitiesItf-GetSupportedZoomSettings
drop 72 end-structure
\ XACameraItf_
begin-structure XACameraItf_
	drop 160 8 +field XACameraItf-SetWhiteBalance
	drop 168 8 +field XACameraItf-GetWhiteBalance
	drop 128 8 +field XACameraItf-SetAperture
	drop 136 8 +field XACameraItf-GetAperture
	drop 16 8 +field XACameraItf-GetFlashMode
	drop 8 8 +field XACameraItf-SetFlashMode
	drop 104 8 +field XACameraItf-GetExposureMode
	drop 96 8 +field XACameraItf-SetExposureMode
	drop 56 8 +field XACameraItf-GetFocusRegionPattern
	drop 48 8 +field XACameraItf-SetFocusRegionPattern
	drop 144 8 +field XACameraItf-SetShutterSpeed
	drop 152 8 +field XACameraItf-GetShutterSpeed
	drop 176 8 +field XACameraItf-SetAutoLocks
	drop 184 8 +field XACameraItf-GetAutoLocks
	drop 0 8 +field XACameraItf-RegisterCallback
	drop 88 8 +field XACameraItf-GetMeteringMode
	drop 80 8 +field XACameraItf-SetMeteringMode
	drop 64 8 +field XACameraItf-GetFocusRegionPositions
	drop 24 8 +field XACameraItf-IsFlashReady
	drop 40 8 +field XACameraItf-GetFocusMode
	drop 32 8 +field XACameraItf-SetFocusMode
	drop 72 8 +field XACameraItf-GetFocusModeStatus
	drop 112 8 +field XACameraItf-SetISOSensitivity
	drop 120 8 +field XACameraItf-GetISOSensitivity
	drop 192 8 +field XACameraItf-SetZoom
	drop 200 8 +field XACameraItf-GetZoom
drop 208 end-structure
\ XAAudioInputDescriptor
begin-structure XAAudioInputDescriptor
drop 48 end-structure
\ XAAudioOutputDescriptor
begin-structure XAAudioOutputDescriptor
drop 48 end-structure
\ XAAudioIODeviceCapabilitiesItf_
begin-structure XAAudioIODeviceCapabilitiesItf_
	drop 8 8 +field XAAudioIODeviceCapabilitiesItf-QueryAudioInputCapabilities
	drop 32 8 +field XAAudioIODeviceCapabilitiesItf-QueryAudioOutputCapabilities
	drop 24 8 +field XAAudioIODeviceCapabilitiesItf-GetAvailableAudioOutputs
	drop 64 8 +field XAAudioIODeviceCapabilitiesItf-GetAssociatedAudioOutputs
	drop 72 8 +field XAAudioIODeviceCapabilitiesItf-GetDefaultAudioDevices
	drop 80 8 +field XAAudioIODeviceCapabilitiesItf-QuerySampleFormatsSupported
	drop 0 8 +field XAAudioIODeviceCapabilitiesItf-GetAvailableAudioInputs
	drop 16 8 +field XAAudioIODeviceCapabilitiesItf-RegisterAvailableAudioInputsChangedCallback
	drop 40 8 +field XAAudioIODeviceCapabilitiesItf-RegisterAvailableAudioOutputsChangedCallback
	drop 48 8 +field XAAudioIODeviceCapabilitiesItf-RegisterDefaultDeviceIDMapChangedCallback
	drop 56 8 +field XAAudioIODeviceCapabilitiesItf-GetAssociatedAudioInputs
drop 88 end-structure
\ XADeviceVolumeItf_
begin-structure XADeviceVolumeItf_
	drop 8 8 +field XADeviceVolumeItf-SetVolume
	drop 16 8 +field XADeviceVolumeItf-GetVolume
	drop 0 8 +field XADeviceVolumeItf-GetVolumeScale
drop 24 end-structure
\ XAEqualizerItf_
begin-structure XAEqualizerItf_
	drop 32 8 +field XAEqualizerItf-SetBandLevel
	drop 40 8 +field XAEqualizerItf-GetBandLevel
	drop 64 8 +field XAEqualizerItf-GetBand
	drop 88 8 +field XAEqualizerItf-GetNumberOfPresets
	drop 48 8 +field XAEqualizerItf-GetCenterFreq
	drop 0 8 +field XAEqualizerItf-SetEnabled
	drop 8 8 +field XAEqualizerItf-IsEnabled
	drop 16 8 +field XAEqualizerItf-GetNumberOfBands
	drop 56 8 +field XAEqualizerItf-GetBandFreqRange
	drop 72 8 +field XAEqualizerItf-GetCurrentPreset
	drop 96 8 +field XAEqualizerItf-GetPresetName
	drop 80 8 +field XAEqualizerItf-UsePreset
	drop 24 8 +field XAEqualizerItf-GetBandLevelRange
drop 104 end-structure
\ XAOutputMixItf_
begin-structure XAOutputMixItf_
	drop 16 8 +field XAOutputMixItf-ReRoute
	drop 8 8 +field XAOutputMixItf-RegisterDeviceChangeCallback
	drop 0 8 +field XAOutputMixItf-GetDestinationOutputDeviceIDs
drop 24 end-structure
\ XARadioItf_
begin-structure XARadioItf_
	drop 96 8 +field XARadioItf-Seek
	drop 104 8 +field XARadioItf-StopSeeking
	drop 8 8 +field XARadioItf-GetFreqRange
	drop 0 8 +field XARadioItf-SetFreqRange
	drop 136 8 +field XARadioItf-RegisterRadioCallback
	drop 64 8 +field XARadioItf-GetSquelch
	drop 56 8 +field XARadioItf-SetSquelch
	drop 24 8 +field XARadioItf-GetFreqRangeProperties
	drop 120 8 +field XARadioItf-SetPreset
	drop 128 8 +field XARadioItf-GetPreset
	drop 112 8 +field XARadioItf-GetNumberOfPresets
	drop 16 8 +field XARadioItf-IsFreqRangeSupported
	drop 88 8 +field XARadioItf-GetSignalStrength
	drop 80 8 +field XARadioItf-GetStereoMode
	drop 72 8 +field XARadioItf-SetStereoMode
	drop 48 8 +field XARadioItf-GetFrequency
	drop 40 8 +field XARadioItf-CancelSetFrequency
	drop 32 8 +field XARadioItf-SetFrequency
drop 144 end-structure
\ XARDSItf_
begin-structure XARDSItf_
	drop 48 8 +field XARDSItf-GetProgrammeIdentificationCode
	drop 0 8 +field XARDSItf-QueryRDSSignal
	drop 96 8 +field XARDSItf-SeekTrafficProgramme
	drop 72 8 +field XARDSItf-GetTrafficProgramme
	drop 16 8 +field XARDSItf-GetRadioText
	drop 136 8 +field XARDSItf-GetODAGroup
	drop 144 8 +field XARDSItf-SubscribeODAGroup
	drop 152 8 +field XARDSItf-UnsubscribeODAGroup
	drop 80 8 +field XARDSItf-SeekByProgrammeType
	drop 32 8 +field XARDSItf-GetProgrammeType
	drop 56 8 +field XARDSItf-GetClockTime
	drop 40 8 +field XARDSItf-GetProgrammeTypeString
	drop 104 8 +field XARDSItf-SetAutomaticSwitching
	drop 112 8 +field XARDSItf-GetAutomaticSwitching
	drop 168 8 +field XARDSItf-RegisterRDSCallback
	drop 176 8 +field XARDSItf-RegisterODADataCallback
	drop 88 8 +field XARDSItf-SeekTrafficAnnouncement
	drop 64 8 +field XARDSItf-GetTrafficAnnouncement
	drop 120 8 +field XARDSItf-SetAutomaticTrafficAnnouncement
	drop 128 8 +field XARDSItf-GetAutomaticTrafficAnnouncement
	drop 160 8 +field XARDSItf-ListODAGroupSubscriptions
	drop 8 8 +field XARDSItf-GetProgrammeServiceName
	drop 24 8 +field XARDSItf-GetRadioTextPlus
drop 184 end-structure
\ XAVibraItf_
begin-structure XAVibraItf_
	drop 0 8 +field XAVibraItf-Vibrate
	drop 16 8 +field XAVibraItf-SetFrequency
	drop 24 8 +field XAVibraItf-GetFrequency
	drop 32 8 +field XAVibraItf-SetIntensity
	drop 40 8 +field XAVibraItf-GetIntensity
	drop 8 8 +field XAVibraItf-IsVibrating
drop 48 end-structure
\ XAHSL
begin-structure XAHSL
drop 8 end-structure
\ XALEDArrayItf_
begin-structure XALEDArrayItf_
	drop 0 8 +field XALEDArrayItf-ActivateLEDArray
	drop 8 8 +field XALEDArrayItf-IsLEDArrayActivated
	drop 16 8 +field XALEDArrayItf-SetColor
	drop 24 8 +field XALEDArrayItf-GetColor
drop 32 end-structure
\ XAAudioCodecDescriptor
begin-structure XAAudioCodecDescriptor
drop 72 end-structure
\ XAAudioEncoderSettings
begin-structure XAAudioEncoderSettings
drop 52 end-structure
\ XAAudioDecoderCapabilitiesItf_
begin-structure XAAudioDecoderCapabilitiesItf_
	drop 0 8 +field XAAudioDecoderCapabilitiesItf-GetAudioDecoders
	drop 8 8 +field XAAudioDecoderCapabilitiesItf-GetAudioDecoderCapabilities
drop 16 end-structure
\ XAAudioEncoderItf_
begin-structure XAAudioEncoderItf_
	drop 0 8 +field XAAudioEncoderItf-SetEncoderSettings
	drop 8 8 +field XAAudioEncoderItf-GetEncoderSettings
drop 16 end-structure
\ XAAudioEncoderCapabilitiesItf_
begin-structure XAAudioEncoderCapabilitiesItf_
	drop 0 8 +field XAAudioEncoderCapabilitiesItf-GetAudioEncoders
	drop 8 8 +field XAAudioEncoderCapabilitiesItf-GetAudioEncoderCapabilities
drop 16 end-structure
\ XAImageCodecDescriptor
begin-structure XAImageCodecDescriptor
drop 12 end-structure
\ XAImageSettings
begin-structure XAImageSettings
drop 20 end-structure
\ XAImageEncoderCapabilitiesItf_
begin-structure XAImageEncoderCapabilitiesItf_
	drop 0 8 +field XAImageEncoderCapabilitiesItf-GetImageEncoderCapabilities
	drop 8 8 +field XAImageEncoderCapabilitiesItf-QueryColorFormats
drop 16 end-structure
\ XAImageDecoderCapabilitiesItf_
begin-structure XAImageDecoderCapabilitiesItf_
	drop 0 8 +field XAImageDecoderCapabilitiesItf-GetImageDecoderCapabilities
	drop 8 8 +field XAImageDecoderCapabilitiesItf-QueryColorFormats
drop 16 end-structure
\ XAImageEncoderItf_
begin-structure XAImageEncoderItf_
	drop 0 8 +field XAImageEncoderItf-SetImageSettings
	drop 8 8 +field XAImageEncoderItf-GetImageSettings
	drop 16 8 +field XAImageEncoderItf-GetSizeEstimate
drop 24 end-structure
\ XAVideoCodecDescriptor
begin-structure XAVideoCodecDescriptor
drop 32 end-structure
\ XAVideoSettings
begin-structure XAVideoSettings
drop 36 end-structure
\ XAVideoDecoderCapabilitiesItf_
begin-structure XAVideoDecoderCapabilitiesItf_
	drop 0 8 +field XAVideoDecoderCapabilitiesItf-GetVideoDecoders
	drop 8 8 +field XAVideoDecoderCapabilitiesItf-GetVideoDecoderCapabilities
drop 16 end-structure
\ XAVideoEncoderCapabilitiesItf_
begin-structure XAVideoEncoderCapabilitiesItf_
	drop 0 8 +field XAVideoEncoderCapabilitiesItf-GetVideoEncoders
	drop 8 8 +field XAVideoEncoderCapabilitiesItf-GetVideoEncoderCapabilities
drop 16 end-structure
\ XAVideoEncoderItf_
begin-structure XAVideoEncoderItf_
	drop 0 8 +field XAVideoEncoderItf-SetVideoSettings
	drop 8 8 +field XAVideoEncoderItf-GetVideoSettings
drop 16 end-structure
\ XAMediaContainerInformation
begin-structure XAMediaContainerInformation
drop 12 end-structure
\ XAVideoStreamInformation
begin-structure XAVideoStreamInformation
drop 24 end-structure
\ XAAudioStreamInformation
begin-structure XAAudioStreamInformation
drop 36 end-structure
\ XAImageStreamInformation
begin-structure XAImageStreamInformation
drop 16 end-structure
\ XATimedTextStreamInformation
begin-structure XATimedTextStreamInformation
drop 40 end-structure
\ XAMIDIStreamInformation
begin-structure XAMIDIStreamInformation
drop 32 end-structure
\ XAVendorStreamInformation
begin-structure XAVendorStreamInformation
drop 8 end-structure
\ XAStreamInformationItf_
begin-structure XAStreamInformationItf_
	drop 0 8 +field XAStreamInformationItf-QueryMediaContainerInformation
	drop 16 8 +field XAStreamInformationItf-QueryStreamInformation
	drop 48 8 +field XAStreamInformationItf-SetActiveStream
	drop 24 8 +field XAStreamInformationItf-QueryStreamName
	drop 8 8 +field XAStreamInformationItf-QueryStreamType
	drop 32 8 +field XAStreamInformationItf-RegisterStreamChangeCallback
	drop 40 8 +field XAStreamInformationItf-QueryActiveStreams
drop 56 end-structure
\ XAAndroidBufferItem
begin-structure XAAndroidBufferItem
drop 8 end-structure
\ XAAndroidBufferQueueState
begin-structure XAAndroidBufferQueueState
drop 8 end-structure
\ XAAndroidBufferQueueItf_
begin-structure XAAndroidBufferQueueItf_
	drop 24 8 +field XAAndroidBufferQueueItf-GetState
	drop 8 8 +field XAAndroidBufferQueueItf-Clear
	drop 32 8 +field XAAndroidBufferQueueItf-SetCallbackEventsMask
	drop 40 8 +field XAAndroidBufferQueueItf-GetCallbackEventsMask
	drop 16 8 +field XAAndroidBufferQueueItf-Enqueue
	drop 0 8 +field XAAndroidBufferQueueItf-RegisterCallback
drop 48 end-structure
\ XADataLocator_AndroidBufferQueue
begin-structure XADataLocator_AndroidBufferQueue
drop 8 end-structure
\ XADataLocator_AndroidFD
begin-structure XADataLocator_AndroidFD
drop 24 end-structure

\ --===< function pointers >===---
c-funptr XAObjectItf-Realize() {((struct XAObjectItf_*)ptr)->Realize} a u -- u	( self async -- )
c-funptr XAObjectItf-Resume() {((struct XAObjectItf_*)ptr)->Resume} a u -- u	( self async -- )
c-funptr XAObjectItf-GetState() {((struct XAObjectItf_*)ptr)->GetState} a a -- u	( self pState -- )
c-funptr XAObjectItf-GetInterface() {((struct XAObjectItf_*)ptr)->GetInterface} a a a -- u	( self iid pInterface -- )
c-funptr XAObjectItf-RegisterCallback() {((struct XAObjectItf_*)ptr)->RegisterCallback} a a a -- u	( self callback pContext -- )
c-funptr XAObjectItf-AbortAsyncOperation() {((struct XAObjectItf_*)ptr)->AbortAsyncOperation} a -- void	( self -- )
c-funptr XAObjectItf-Destroy() {((struct XAObjectItf_*)ptr)->Destroy} a -- void	( self -- )
c-funptr XAObjectItf-SetPriority() {((struct XAObjectItf_*)ptr)->SetPriority} a n u -- u	( self priority preemptable -- )
c-funptr XAObjectItf-GetPriority() {((struct XAObjectItf_*)ptr)->GetPriority} a a a -- u	( self pPriority pPreemptable -- )
c-funptr XAObjectItf-SetLossOfControlInterfaces() {((struct XAObjectItf_*)ptr)->SetLossOfControlInterfaces} a n a u -- u	( self numInterfaces pInterfaceIDs enabled -- )
c-funptr XAConfigExtensionsItf-SetConfiguration() {((struct XAConfigExtensionsItf_*)ptr)->SetConfiguration} a a u a -- u	( self configKey valueSize pConfigValue -- )
c-funptr XAConfigExtensionsItf-GetConfiguration() {((struct XAConfigExtensionsItf_*)ptr)->GetConfiguration} a a a a -- u	( self configKey pValueSize pConfigValue -- )
c-funptr XADynamicInterfaceManagementItf-AddInterface() {((struct XADynamicInterfaceManagementItf_*)ptr)->AddInterface} a a u -- u	( self iid aysnc -- )
c-funptr XADynamicInterfaceManagementItf-RemoveInterface() {((struct XADynamicInterfaceManagementItf_*)ptr)->RemoveInterface} a a -- u	( self iid -- )
c-funptr XADynamicInterfaceManagementItf-ResumeInterface() {((struct XADynamicInterfaceManagementItf_*)ptr)->ResumeInterface} a a u -- u	( self iid aysnc -- )
c-funptr XADynamicInterfaceManagementItf-RegisterCallback() {((struct XADynamicInterfaceManagementItf_*)ptr)->RegisterCallback} a a a -- u	( self callback pContext -- )
c-funptr XAEngineItf-CreateCameraDevice() {((struct XAEngineItf_*)ptr)->CreateCameraDevice} a a u u a a -- u	( self pDevice deviceID numInterfaces pInterfaceIds pInterfaceRequired -- )
c-funptr XAEngineItf-CreateRadioDevice() {((struct XAEngineItf_*)ptr)->CreateRadioDevice} a a u a a -- u	( self pDevice numInterfaces pInterfaceIds pInterfaceRequired -- )
c-funptr XAEngineItf-CreateLEDDevice() {((struct XAEngineItf_*)ptr)->CreateLEDDevice} a a u u a a -- u	( self pDevice deviceID numInterfaces pInterfaceIds pInterfaceRequired -- )
c-funptr XAEngineItf-CreateVibraDevice() {((struct XAEngineItf_*)ptr)->CreateVibraDevice} a a u u a a -- u	( self pDevice deviceID numInterfaces pInterfaceIds pInterfaceRequired -- )
c-funptr XAEngineItf-CreateMediaPlayer() {((struct XAEngineItf_*)ptr)->CreateMediaPlayer} a a a a a a a a u a a -- u	( self pPlayer pDataSrc pBankSrc pAudioSnk pImageVideoSnk pVibra pLEDArray numInterfaces pInterfaceIds pInterfaceRequired -- )
c-funptr XAEngineItf-CreateMediaRecorder() {((struct XAEngineItf_*)ptr)->CreateMediaRecorder} a a a a a u a a -- u	( self pRecorder pAudioSrc pImageVideoSrc pDataSnk numInterfaces pInterfaceIds pInterfaceRequired -- )
c-funptr XAEngineItf-CreateOutputMix() {((struct XAEngineItf_*)ptr)->CreateOutputMix} a a u a a -- u	( self pMix numInterfaces pInterfaceIds pInterfaceRequired -- )
c-funptr XAEngineItf-CreateMetadataExtractor() {((struct XAEngineItf_*)ptr)->CreateMetadataExtractor} a a a u a a -- u	( self pMetadataExtractor pDataSource numInterfaces pInterfaceIds pInterfaceRequired -- )
c-funptr XAEngineItf-CreateExtensionObject() {((struct XAEngineItf_*)ptr)->CreateExtensionObject} a a a u u a a -- u	( self pObject pParameters objectID numInterfaces pInterfaceIds pInterfaceRequired -- )
c-funptr XAEngineItf-GetImplementationInfo() {((struct XAEngineItf_*)ptr)->GetImplementationInfo} a a a a a -- u	( self pMajor pMinor pStep pImplementationText -- )
c-funptr XAEngineItf-QuerySupportedProfiles() {((struct XAEngineItf_*)ptr)->QuerySupportedProfiles} a a -- u	( self pProfilesSupported -- )
c-funptr XAEngineItf-QueryNumSupportedInterfaces() {((struct XAEngineItf_*)ptr)->QueryNumSupportedInterfaces} a u a -- u	( self objectID pNumSupportedInterfaces -- )
c-funptr XAEngineItf-QuerySupportedInterfaces() {((struct XAEngineItf_*)ptr)->QuerySupportedInterfaces} a u u a -- u	( self objectID index pInterfaceId -- )
c-funptr XAEngineItf-QueryNumSupportedExtensions() {((struct XAEngineItf_*)ptr)->QueryNumSupportedExtensions} a a -- u	( self pNumExtensions -- )
c-funptr XAEngineItf-QuerySupportedExtension() {((struct XAEngineItf_*)ptr)->QuerySupportedExtension} a u a a -- u	( self index pExtensionName pNameLength -- )
c-funptr XAEngineItf-IsExtensionSupported() {((struct XAEngineItf_*)ptr)->IsExtensionSupported} a a a -- u	( self pExtensionName pSupported -- )
c-funptr XAEngineItf-QueryLEDCapabilities() {((struct XAEngineItf_*)ptr)->QueryLEDCapabilities} a a a a -- u	( self pIndex pLEDDeviceID pDescriptor -- )
c-funptr XAEngineItf-QueryVibraCapabilities() {((struct XAEngineItf_*)ptr)->QueryVibraCapabilities} a a a a -- u	( self pIndex pVibraDeviceID pDescriptor -- )
c-funptr XAThreadSyncItf-EnterCriticalSection() {((struct XAThreadSyncItf_*)ptr)->EnterCriticalSection} a -- u	( self -- )
c-funptr XAThreadSyncItf-ExitCriticalSection() {((struct XAThreadSyncItf_*)ptr)->ExitCriticalSection} a -- u	( self -- )
c-funptr XAPlayItf-SetPlayState() {((struct XAPlayItf_*)ptr)->SetPlayState} a u -- u	( self state -- )
c-funptr XAPlayItf-GetPlayState() {((struct XAPlayItf_*)ptr)->GetPlayState} a a -- u	( self pState -- )
c-funptr XAPlayItf-GetDuration() {((struct XAPlayItf_*)ptr)->GetDuration} a a -- u	( self pMsec -- )
c-funptr XAPlayItf-GetPosition() {((struct XAPlayItf_*)ptr)->GetPosition} a a -- u	( self pMsec -- )
c-funptr XAPlayItf-RegisterCallback() {((struct XAPlayItf_*)ptr)->RegisterCallback} a a a -- u	( self callback pContext -- )
c-funptr XAPlayItf-SetCallbackEventsMask() {((struct XAPlayItf_*)ptr)->SetCallbackEventsMask} a u -- u	( self eventFlags -- )
c-funptr XAPlayItf-GetCallbackEventsMask() {((struct XAPlayItf_*)ptr)->GetCallbackEventsMask} a a -- u	( self pEventFlags -- )
c-funptr XAPlayItf-SetMarkerPosition() {((struct XAPlayItf_*)ptr)->SetMarkerPosition} a u -- u	( self mSec -- )
c-funptr XAPlayItf-ClearMarkerPosition() {((struct XAPlayItf_*)ptr)->ClearMarkerPosition} a -- u	( self -- )
c-funptr XAPlayItf-GetMarkerPosition() {((struct XAPlayItf_*)ptr)->GetMarkerPosition} a a -- u	( self pMsec -- )
c-funptr XAPlayItf-SetPositionUpdatePeriod() {((struct XAPlayItf_*)ptr)->SetPositionUpdatePeriod} a u -- u	( self mSec -- )
c-funptr XAPlayItf-GetPositionUpdatePeriod() {((struct XAPlayItf_*)ptr)->GetPositionUpdatePeriod} a a -- u	( self pMsec -- )
c-funptr XAPlaybackRateItf-SetRate() {((struct XAPlaybackRateItf_*)ptr)->SetRate} a n -- u	( self rate -- )
c-funptr XAPlaybackRateItf-GetRate() {((struct XAPlaybackRateItf_*)ptr)->GetRate} a a -- u	( self pRate -- )
c-funptr XAPlaybackRateItf-SetPropertyConstraints() {((struct XAPlaybackRateItf_*)ptr)->SetPropertyConstraints} a u -- u	( self constraints -- )
c-funptr XAPlaybackRateItf-GetProperties() {((struct XAPlaybackRateItf_*)ptr)->GetProperties} a a -- u	( self pProperties -- )
c-funptr XAPlaybackRateItf-GetCapabilitiesOfRate() {((struct XAPlaybackRateItf_*)ptr)->GetCapabilitiesOfRate} a n a -- u	( self rate pCapabilities -- )
c-funptr XAPlaybackRateItf-GetRateRange() {((struct XAPlaybackRateItf_*)ptr)->GetRateRange} a u a a a a -- u	( self index pMinRate pMaxRate pStepSize pCapabilities -- )
c-funptr XAPrefetchStatusItf-GetPrefetchStatus() {((struct XAPrefetchStatusItf_*)ptr)->GetPrefetchStatus} a a -- u	( self pStatus -- )
c-funptr XAPrefetchStatusItf-GetFillLevel() {((struct XAPrefetchStatusItf_*)ptr)->GetFillLevel} a a -- u	( self pLevel -- )
c-funptr XAPrefetchStatusItf-RegisterCallback() {((struct XAPrefetchStatusItf_*)ptr)->RegisterCallback} a a a -- u	( self callback pContext -- )
c-funptr XAPrefetchStatusItf-SetCallbackEventsMask() {((struct XAPrefetchStatusItf_*)ptr)->SetCallbackEventsMask} a u -- u	( self eventFlags -- )
c-funptr XAPrefetchStatusItf-GetCallbackEventsMask() {((struct XAPrefetchStatusItf_*)ptr)->GetCallbackEventsMask} a a -- u	( self pEventFlags -- )
c-funptr XAPrefetchStatusItf-SetFillUpdatePeriod() {((struct XAPrefetchStatusItf_*)ptr)->SetFillUpdatePeriod} a n -- u	( self period -- )
c-funptr XAPrefetchStatusItf-GetFillUpdatePeriod() {((struct XAPrefetchStatusItf_*)ptr)->GetFillUpdatePeriod} a a -- u	( self pPeriod -- )
c-funptr XASeekItf-SetPosition() {((struct XASeekItf_*)ptr)->SetPosition} a u u -- u	( self pos seekMode -- )
c-funptr XASeekItf-SetLoop() {((struct XASeekItf_*)ptr)->SetLoop} a u u u -- u	( self loopEnable startPos endPos -- )
c-funptr XASeekItf-GetLoop() {((struct XASeekItf_*)ptr)->GetLoop} a a a a -- u	( self pLoopEnabled pStartPos pEndPos -- )
c-funptr XAVolumeItf-SetVolumeLevel() {((struct XAVolumeItf_*)ptr)->SetVolumeLevel} a n -- u	( self level -- )
c-funptr XAVolumeItf-GetVolumeLevel() {((struct XAVolumeItf_*)ptr)->GetVolumeLevel} a a -- u	( self pLevel -- )
c-funptr XAVolumeItf-GetMaxVolumeLevel() {((struct XAVolumeItf_*)ptr)->GetMaxVolumeLevel} a a -- u	( self pMaxLevel -- )
c-funptr XAVolumeItf-SetMute() {((struct XAVolumeItf_*)ptr)->SetMute} a u -- u	( self mute -- )
c-funptr XAVolumeItf-GetMute() {((struct XAVolumeItf_*)ptr)->GetMute} a a -- u	( self pMute -- )
c-funptr XAVolumeItf-EnableStereoPosition() {((struct XAVolumeItf_*)ptr)->EnableStereoPosition} a u -- u	( self enable -- )
c-funptr XAVolumeItf-IsEnabledStereoPosition() {((struct XAVolumeItf_*)ptr)->IsEnabledStereoPosition} a a -- u	( self pEnable -- )
c-funptr XAVolumeItf-SetStereoPosition() {((struct XAVolumeItf_*)ptr)->SetStereoPosition} a n -- u	( self stereoPosition -- )
c-funptr XAVolumeItf-GetStereoPosition() {((struct XAVolumeItf_*)ptr)->GetStereoPosition} a a -- u	( self pStereoPosition -- )
c-funptr XAImageControlsItf-SetBrightness() {((struct XAImageControlsItf_*)ptr)->SetBrightness} a u -- u	( self brightness -- )
c-funptr XAImageControlsItf-GetBrightness() {((struct XAImageControlsItf_*)ptr)->GetBrightness} a a -- u	( self pBrightness -- )
c-funptr XAImageControlsItf-SetContrast() {((struct XAImageControlsItf_*)ptr)->SetContrast} a n -- u	( self contrast -- )
c-funptr XAImageControlsItf-GetContrast() {((struct XAImageControlsItf_*)ptr)->GetContrast} a a -- u	( self pContrast -- )
c-funptr XAImageControlsItf-SetGamma() {((struct XAImageControlsItf_*)ptr)->SetGamma} a n -- u	( self gamma -- )
c-funptr XAImageControlsItf-GetGamma() {((struct XAImageControlsItf_*)ptr)->GetGamma} a a -- u	( self pGamma -- )
c-funptr XAImageControlsItf-GetSupportedGammaSettings() {((struct XAImageControlsItf_*)ptr)->GetSupportedGammaSettings} a a a a a -- u	( self pMinValue pMaxValue pNumSettings ppSettings -- )
c-funptr XAImageEffectsItf-QuerySupportedImageEffects() {((struct XAImageEffectsItf_*)ptr)->QuerySupportedImageEffects} a u a -- u	( self index pImageEffectId -- )
c-funptr XAImageEffectsItf-EnableImageEffect() {((struct XAImageEffectsItf_*)ptr)->EnableImageEffect} a u -- u	( self imageEffectID -- )
c-funptr XAImageEffectsItf-DisableImageEffect() {((struct XAImageEffectsItf_*)ptr)->DisableImageEffect} a u -- u	( self imageEffectID -- )
c-funptr XAImageEffectsItf-IsImageEffectEnabled() {((struct XAImageEffectsItf_*)ptr)->IsImageEffectEnabled} a u a -- u	( self imageEffectID pEnabled -- )
c-funptr XAVideoPostProcessingItf-SetRotation() {((struct XAVideoPostProcessingItf_*)ptr)->SetRotation} a u -- u	( self rotation -- )
c-funptr XAVideoPostProcessingItf-IsArbitraryRotationSupported() {((struct XAVideoPostProcessingItf_*)ptr)->IsArbitraryRotationSupported} a a -- u	( self pSupported -- )
c-funptr XAVideoPostProcessingItf-SetScaleOptions() {((struct XAVideoPostProcessingItf_*)ptr)->SetScaleOptions} a u u u -- u	( self scaleOptions backgroundColor renderingHints -- )
c-funptr XAVideoPostProcessingItf-SetSourceRectangle() {((struct XAVideoPostProcessingItf_*)ptr)->SetSourceRectangle} a a -- u	( self pSrcRect -- )
c-funptr XAVideoPostProcessingItf-SetDestinationRectangle() {((struct XAVideoPostProcessingItf_*)ptr)->SetDestinationRectangle} a a -- u	( self pDestRect -- )
c-funptr XAVideoPostProcessingItf-SetMirror() {((struct XAVideoPostProcessingItf_*)ptr)->SetMirror} a u -- u	( self mirror -- )
c-funptr XAVideoPostProcessingItf-Commit() {((struct XAVideoPostProcessingItf_*)ptr)->Commit} a -- u	( self -- )
c-funptr XARecordItf-SetRecordState() {((struct XARecordItf_*)ptr)->SetRecordState} a u -- u	( self state -- )
c-funptr XARecordItf-GetRecordState() {((struct XARecordItf_*)ptr)->GetRecordState} a a -- u	( self pState -- )
c-funptr XARecordItf-SetDurationLimit() {((struct XARecordItf_*)ptr)->SetDurationLimit} a u -- u	( self msec -- )
c-funptr XARecordItf-GetPosition() {((struct XARecordItf_*)ptr)->GetPosition} a a -- u	( self pMsec -- )
c-funptr XARecordItf-RegisterCallback() {((struct XARecordItf_*)ptr)->RegisterCallback} a a a -- u	( self callback pContext -- )
c-funptr XARecordItf-SetCallbackEventsMask() {((struct XARecordItf_*)ptr)->SetCallbackEventsMask} a u -- u	( self eventFlags -- )
c-funptr XARecordItf-GetCallbackEventsMask() {((struct XARecordItf_*)ptr)->GetCallbackEventsMask} a a -- u	( self pEventFlags -- )
c-funptr XARecordItf-SetMarkerPosition() {((struct XARecordItf_*)ptr)->SetMarkerPosition} a u -- u	( self mSec -- )
c-funptr XARecordItf-ClearMarkerPosition() {((struct XARecordItf_*)ptr)->ClearMarkerPosition} a -- u	( self -- )
c-funptr XARecordItf-GetMarkerPosition() {((struct XARecordItf_*)ptr)->GetMarkerPosition} a a -- u	( self pMsec -- )
c-funptr XARecordItf-SetPositionUpdatePeriod() {((struct XARecordItf_*)ptr)->SetPositionUpdatePeriod} a u -- u	( self mSec -- )
c-funptr XARecordItf-GetPositionUpdatePeriod() {((struct XARecordItf_*)ptr)->GetPositionUpdatePeriod} a a -- u	( self pMsec -- )
c-funptr XASnapshotItf-InitiateSnapshot() {((struct XASnapshotItf_*)ptr)->InitiateSnapshot} a u u u a{*(XADataSink*)} a a a -- u	( self numberOfPictures fps freezeViewFinder sink initiatedCallback takenCallback pContext -- )
c-funptr XASnapshotItf-TakeSnapshot() {((struct XASnapshotItf_*)ptr)->TakeSnapshot} a -- u	( self -- )
c-funptr XASnapshotItf-CancelSnapshot() {((struct XASnapshotItf_*)ptr)->CancelSnapshot} a -- u	( self -- )
c-funptr XASnapshotItf-ReleaseBuffers() {((struct XASnapshotItf_*)ptr)->ReleaseBuffers} a a -- u	( self image -- )
c-funptr XASnapshotItf-GetMaxPicsPerBurst() {((struct XASnapshotItf_*)ptr)->GetMaxPicsPerBurst} a a -- u	( self maxNumberOfPictures -- )
c-funptr XASnapshotItf-GetBurstFPSRange() {((struct XASnapshotItf_*)ptr)->GetBurstFPSRange} a a a -- u	( self minFPS maxFPS -- )
c-funptr XASnapshotItf-SetShutterFeedback() {((struct XASnapshotItf_*)ptr)->SetShutterFeedback} a u -- u	( self enabled -- )
c-funptr XASnapshotItf-GetShutterFeedback() {((struct XASnapshotItf_*)ptr)->GetShutterFeedback} a a -- u	( self enabled -- )
c-funptr XAMetadataExtractionItf-GetItemCount() {((struct XAMetadataExtractionItf_*)ptr)->GetItemCount} a a -- u	( self pItemCount -- )
c-funptr XAMetadataExtractionItf-GetKeySize() {((struct XAMetadataExtractionItf_*)ptr)->GetKeySize} a u a -- u	( self index pKeySize -- )
c-funptr XAMetadataExtractionItf-GetKey() {((struct XAMetadataExtractionItf_*)ptr)->GetKey} a u u a -- u	( self index keySize pKey -- )
c-funptr XAMetadataExtractionItf-GetValueSize() {((struct XAMetadataExtractionItf_*)ptr)->GetValueSize} a u a -- u	( self index pValueSize -- )
c-funptr XAMetadataExtractionItf-GetValue() {((struct XAMetadataExtractionItf_*)ptr)->GetValue} a u u a -- u	( self index valueSize pValue -- )
c-funptr XAMetadataExtractionItf-AddKeyFilter() {((struct XAMetadataExtractionItf_*)ptr)->AddKeyFilter} a u a u a u u -- u	( self keySize pKey keyEncoding pValueLangCountry valueEncoding filterMask -- )
c-funptr XAMetadataExtractionItf-ClearKeyFilter() {((struct XAMetadataExtractionItf_*)ptr)->ClearKeyFilter} a -- u	( self -- )
c-funptr XAMetadataInsertionItf-CreateChildNode() {((struct XAMetadataInsertionItf_*)ptr)->CreateChildNode} a n u a a -- u	( self parentNodeID type mimeType pChildNodeID -- )
c-funptr XAMetadataInsertionItf-GetSupportedKeysCount() {((struct XAMetadataInsertionItf_*)ptr)->GetSupportedKeysCount} a n a a a -- u	( self nodeID pFreeKeys pKeyCount pEncodingCount -- )
c-funptr XAMetadataInsertionItf-GetKeySize() {((struct XAMetadataInsertionItf_*)ptr)->GetKeySize} a n u a -- u	( self nodeID keyIndex pKeySize -- )
c-funptr XAMetadataInsertionItf-GetKey() {((struct XAMetadataInsertionItf_*)ptr)->GetKey} a n u u a -- u	( self nodeID keyIndex keySize pKey -- )
c-funptr XAMetadataInsertionItf-GetFreeKeysEncoding() {((struct XAMetadataInsertionItf_*)ptr)->GetFreeKeysEncoding} a n u a -- u	( self nodeID encodingIndex pEncoding -- )
c-funptr XAMetadataInsertionItf-InsertMetadataItem() {((struct XAMetadataInsertionItf_*)ptr)->InsertMetadataItem} a n a a u -- u	( self nodeID pKey pValue overwrite -- )
c-funptr XAMetadataInsertionItf-RegisterCallback() {((struct XAMetadataInsertionItf_*)ptr)->RegisterCallback} a a a -- u	( self callback pContext -- )
c-funptr XAMetadataTraversalItf-SetMode() {((struct XAMetadataTraversalItf_*)ptr)->SetMode} a u -- u	( self mode -- )
c-funptr XAMetadataTraversalItf-GetChildCount() {((struct XAMetadataTraversalItf_*)ptr)->GetChildCount} a a -- u	( self pCount -- )
c-funptr XAMetadataTraversalItf-GetChildMIMETypeSize() {((struct XAMetadataTraversalItf_*)ptr)->GetChildMIMETypeSize} a u a -- u	( self index pSize -- )
c-funptr XAMetadataTraversalItf-GetChildInfo() {((struct XAMetadataTraversalItf_*)ptr)->GetChildInfo} a u a a u a -- u	( self index pNodeID pType size pMimeType -- )
c-funptr XAMetadataTraversalItf-SetActiveNode() {((struct XAMetadataTraversalItf_*)ptr)->SetActiveNode} a u -- u	( self index -- )
c-funptr XADynamicSourceItf-SetSource() {((struct XADynamicSourceItf_*)ptr)->SetSource} a a -- u	( self pDataSource -- )
c-funptr XACameraCapabilitiesItf-GetCameraCapabilities() {((struct XACameraCapabilitiesItf_*)ptr)->GetCameraCapabilities} a a a a -- u	( self pIndex pCameraDeviceID pDescriptor -- )
c-funptr XACameraCapabilitiesItf-QueryFocusRegionPatterns() {((struct XACameraCapabilitiesItf_*)ptr)->QueryFocusRegionPatterns} a u a a a a -- u	( self cameraDeviceID pPatternID pFocusPattern pCustomPoints1 pCustomPoints2 -- )
c-funptr XACameraCapabilitiesItf-GetSupportedAutoLocks() {((struct XACameraCapabilitiesItf_*)ptr)->GetSupportedAutoLocks} a u a a -- u	( self cameraDeviceID pNumCombinations ppLocks -- )
c-funptr XACameraCapabilitiesItf-GetSupportedFocusManualSettings() {((struct XACameraCapabilitiesItf_*)ptr)->GetSupportedFocusManualSettings} a u u a a a a -- u	( self cameraDeviceID macroEnabled pMinValue pMaxValue pNumSettings ppSettings -- )
c-funptr XACameraCapabilitiesItf-GetSupportedISOSensitivitySettings() {((struct XACameraCapabilitiesItf_*)ptr)->GetSupportedISOSensitivitySettings} a u a a a a -- u	( self cameraDeviceID pMinValue pMaxValue pNumSettings ppSettings -- )
c-funptr XACameraCapabilitiesItf-GetSupportedApertureManualSettings() {((struct XACameraCapabilitiesItf_*)ptr)->GetSupportedApertureManualSettings} a u a a a a -- u	( self cameraDeviceID pMinValue pMaxValue pNumSettings ppSettings -- )
c-funptr XACameraCapabilitiesItf-GetSupportedShutterSpeedManualSettings() {((struct XACameraCapabilitiesItf_*)ptr)->GetSupportedShutterSpeedManualSettings} a u a a a a -- u	( self cameraDeviceID pMinValue pMaxValue pNumSettings ppSettings -- )
c-funptr XACameraCapabilitiesItf-GetSupportedWhiteBalanceManualSettings() {((struct XACameraCapabilitiesItf_*)ptr)->GetSupportedWhiteBalanceManualSettings} a u a a a a -- u	( self cameraDeviceID pMinValue pMaxValue pNumSettings ppSettings -- )
c-funptr XACameraCapabilitiesItf-GetSupportedZoomSettings() {((struct XACameraCapabilitiesItf_*)ptr)->GetSupportedZoomSettings} a u u u a a a a -- u	( self cameraDeviceID digitalEnabled macroEnabled pMaxValue pNumSettings ppSettings pSpeedSupported -- )
c-funptr XACameraItf-RegisterCallback() {((struct XACameraItf_*)ptr)->RegisterCallback} a a a -- u	( self callback pContext -- )
c-funptr XACameraItf-SetFlashMode() {((struct XACameraItf_*)ptr)->SetFlashMode} a u -- u	( self flashMode -- )
c-funptr XACameraItf-GetFlashMode() {((struct XACameraItf_*)ptr)->GetFlashMode} a a -- u	( self pFlashMode -- )
c-funptr XACameraItf-IsFlashReady() {((struct XACameraItf_*)ptr)->IsFlashReady} a a -- u	( self pReady -- )
c-funptr XACameraItf-SetFocusMode() {((struct XACameraItf_*)ptr)->SetFocusMode} a u n u -- u	( self focusMode manualSetting macroEnabled -- )
c-funptr XACameraItf-GetFocusMode() {((struct XACameraItf_*)ptr)->GetFocusMode} a a a a -- u	( self pFocusMode pManualSetting pMacroEnabled -- )
c-funptr XACameraItf-SetFocusRegionPattern() {((struct XACameraItf_*)ptr)->SetFocusRegionPattern} a u u u -- u	( self focusPattern activePoints1 activePoints2 -- )
c-funptr XACameraItf-GetFocusRegionPattern() {((struct XACameraItf_*)ptr)->GetFocusRegionPattern} a a a a -- u	( self pFocusPattern pActivePoints1 pActivePoints2 -- )
c-funptr XACameraItf-GetFocusRegionPositions() {((struct XACameraItf_*)ptr)->GetFocusRegionPositions} a a a -- u	( self pNumPositionEntries pFocusPosition -- )
c-funptr XACameraItf-GetFocusModeStatus() {((struct XACameraItf_*)ptr)->GetFocusModeStatus} a a a a -- u	( self pFocusStatus pRegionStatus1 pRegionStatus2 -- )
c-funptr XACameraItf-SetMeteringMode() {((struct XACameraItf_*)ptr)->SetMeteringMode} a u -- u	( self meteringMode -- )
c-funptr XACameraItf-GetMeteringMode() {((struct XACameraItf_*)ptr)->GetMeteringMode} a a -- u	( self pMeteringMode -- )
c-funptr XACameraItf-SetExposureMode() {((struct XACameraItf_*)ptr)->SetExposureMode} a u u -- u	( self exposure compensation -- )
c-funptr XACameraItf-GetExposureMode() {((struct XACameraItf_*)ptr)->GetExposureMode} a a a -- u	( self pExposure pCompensation -- )
c-funptr XACameraItf-SetISOSensitivity() {((struct XACameraItf_*)ptr)->SetISOSensitivity} a u u -- u	( self isoSensitivity manualSetting -- )
c-funptr XACameraItf-GetISOSensitivity() {((struct XACameraItf_*)ptr)->GetISOSensitivity} a a a -- u	( self pIsoSensitivity pManualSetting -- )
c-funptr XACameraItf-SetAperture() {((struct XACameraItf_*)ptr)->SetAperture} a u u -- u	( self aperture manualSetting -- )
c-funptr XACameraItf-GetAperture() {((struct XACameraItf_*)ptr)->GetAperture} a a a -- u	( self pAperture pManualSetting -- )
c-funptr XACameraItf-SetShutterSpeed() {((struct XACameraItf_*)ptr)->SetShutterSpeed} a u u -- u	( self shutterSpeed manualSetting -- )
c-funptr XACameraItf-GetShutterSpeed() {((struct XACameraItf_*)ptr)->GetShutterSpeed} a a a -- u	( self pShutterSpeed pManualSetting -- )
c-funptr XACameraItf-SetWhiteBalance() {((struct XACameraItf_*)ptr)->SetWhiteBalance} a u u -- u	( self whiteBalance manualSetting -- )
c-funptr XACameraItf-GetWhiteBalance() {((struct XACameraItf_*)ptr)->GetWhiteBalance} a a a -- u	( self pWhiteBalance pManualSetting -- )
c-funptr XACameraItf-SetAutoLocks() {((struct XACameraItf_*)ptr)->SetAutoLocks} a u -- u	( self locks -- )
c-funptr XACameraItf-GetAutoLocks() {((struct XACameraItf_*)ptr)->GetAutoLocks} a a -- u	( self locks -- )
c-funptr XACameraItf-SetZoom() {((struct XACameraItf_*)ptr)->SetZoom} a n u u u -- u	( self zoom digitalEnabled speed async -- )
c-funptr XACameraItf-GetZoom() {((struct XACameraItf_*)ptr)->GetZoom} a a a -- u	( self pZoom pDigital -- )
c-funptr XAAudioIODeviceCapabilitiesItf-GetAvailableAudioInputs() {((struct XAAudioIODeviceCapabilitiesItf_*)ptr)->GetAvailableAudioInputs} a a a -- u	( self pNumInputs pInputDeviceIDs -- )
c-funptr XAAudioIODeviceCapabilitiesItf-QueryAudioInputCapabilities() {((struct XAAudioIODeviceCapabilitiesItf_*)ptr)->QueryAudioInputCapabilities} a u a -- u	( self deviceID pDescriptor -- )
c-funptr XAAudioIODeviceCapabilitiesItf-RegisterAvailableAudioInputsChangedCallback() {((struct XAAudioIODeviceCapabilitiesItf_*)ptr)->RegisterAvailableAudioInputsChangedCallback} a a a -- u	( self callback pContext -- )
c-funptr XAAudioIODeviceCapabilitiesItf-GetAvailableAudioOutputs() {((struct XAAudioIODeviceCapabilitiesItf_*)ptr)->GetAvailableAudioOutputs} a a a -- u	( self pNumOutputs pOutputDeviceIDs -- )
c-funptr XAAudioIODeviceCapabilitiesItf-QueryAudioOutputCapabilities() {((struct XAAudioIODeviceCapabilitiesItf_*)ptr)->QueryAudioOutputCapabilities} a u a -- u	( self deviceID pDescriptor -- )
c-funptr XAAudioIODeviceCapabilitiesItf-RegisterAvailableAudioOutputsChangedCallback() {((struct XAAudioIODeviceCapabilitiesItf_*)ptr)->RegisterAvailableAudioOutputsChangedCallback} a a a -- u	( self callback pContext -- )
c-funptr XAAudioIODeviceCapabilitiesItf-RegisterDefaultDeviceIDMapChangedCallback() {((struct XAAudioIODeviceCapabilitiesItf_*)ptr)->RegisterDefaultDeviceIDMapChangedCallback} a a a -- u	( self callback pContext -- )
c-funptr XAAudioIODeviceCapabilitiesItf-GetAssociatedAudioInputs() {((struct XAAudioIODeviceCapabilitiesItf_*)ptr)->GetAssociatedAudioInputs} a u a a -- u	( self deviceID pNumAudioInputs pAudioInputDeviceIDs -- )
c-funptr XAAudioIODeviceCapabilitiesItf-GetAssociatedAudioOutputs() {((struct XAAudioIODeviceCapabilitiesItf_*)ptr)->GetAssociatedAudioOutputs} a u a a -- u	( self deviceID pNumAudioOutputs pAudioOutputDeviceIDs -- )
c-funptr XAAudioIODeviceCapabilitiesItf-GetDefaultAudioDevices() {((struct XAAudioIODeviceCapabilitiesItf_*)ptr)->GetDefaultAudioDevices} a u a a -- u	( self defaultDeviceID pNumAudioDevices pAudioDeviceIDs -- )
c-funptr XAAudioIODeviceCapabilitiesItf-QuerySampleFormatsSupported() {((struct XAAudioIODeviceCapabilitiesItf_*)ptr)->QuerySampleFormatsSupported} a u u a a -- u	( self deviceID samplingRate pSampleFormats pNumOfSampleFormats -- )
c-funptr XADeviceVolumeItf-GetVolumeScale() {((struct XADeviceVolumeItf_*)ptr)->GetVolumeScale} a u a a a -- u	( self deviceID pMinValue pMaxValue pIsMillibelScale -- )
c-funptr XADeviceVolumeItf-SetVolume() {((struct XADeviceVolumeItf_*)ptr)->SetVolume} a u n -- u	( self deviceID volume -- )
c-funptr XADeviceVolumeItf-GetVolume() {((struct XADeviceVolumeItf_*)ptr)->GetVolume} a u a -- u	( self deviceID pVolume -- )
c-funptr XAEqualizerItf-SetEnabled() {((struct XAEqualizerItf_*)ptr)->SetEnabled} a u -- u	( self enabled -- )
c-funptr XAEqualizerItf-IsEnabled() {((struct XAEqualizerItf_*)ptr)->IsEnabled} a a -- u	( self pEnabled -- )
c-funptr XAEqualizerItf-GetNumberOfBands() {((struct XAEqualizerItf_*)ptr)->GetNumberOfBands} a a -- u	( self pNumBands -- )
c-funptr XAEqualizerItf-GetBandLevelRange() {((struct XAEqualizerItf_*)ptr)->GetBandLevelRange} a a a -- u	( self pMin pMax -- )
c-funptr XAEqualizerItf-SetBandLevel() {((struct XAEqualizerItf_*)ptr)->SetBandLevel} a u n -- u	( self band level -- )
c-funptr XAEqualizerItf-GetBandLevel() {((struct XAEqualizerItf_*)ptr)->GetBandLevel} a u a -- u	( self band pLevel -- )
c-funptr XAEqualizerItf-GetCenterFreq() {((struct XAEqualizerItf_*)ptr)->GetCenterFreq} a u a -- u	( self band pCenter -- )
c-funptr XAEqualizerItf-GetBandFreqRange() {((struct XAEqualizerItf_*)ptr)->GetBandFreqRange} a u a a -- u	( self band pMin pMax -- )
c-funptr XAEqualizerItf-GetBand() {((struct XAEqualizerItf_*)ptr)->GetBand} a u a -- u	( self frequency pBand -- )
c-funptr XAEqualizerItf-GetCurrentPreset() {((struct XAEqualizerItf_*)ptr)->GetCurrentPreset} a a -- u	( self pPreset -- )
c-funptr XAEqualizerItf-UsePreset() {((struct XAEqualizerItf_*)ptr)->UsePreset} a u -- u	( self index -- )
c-funptr XAEqualizerItf-GetNumberOfPresets() {((struct XAEqualizerItf_*)ptr)->GetNumberOfPresets} a a -- u	( self pNumPresets -- )
c-funptr XAEqualizerItf-GetPresetName() {((struct XAEqualizerItf_*)ptr)->GetPresetName} a u a -- u	( self index ppName -- )
c-funptr XAOutputMixItf-GetDestinationOutputDeviceIDs() {((struct XAOutputMixItf_*)ptr)->GetDestinationOutputDeviceIDs} a a a -- u	( self pNumDevices pDeviceIDs -- )
c-funptr XAOutputMixItf-RegisterDeviceChangeCallback() {((struct XAOutputMixItf_*)ptr)->RegisterDeviceChangeCallback} a a a -- u	( self callback pContext -- )
c-funptr XAOutputMixItf-ReRoute() {((struct XAOutputMixItf_*)ptr)->ReRoute} a n a -- u	( self numOutputDevices pOutputDeviceIDs -- )
c-funptr XARadioItf-SetFreqRange() {((struct XARadioItf_*)ptr)->SetFreqRange} a u -- u	( self range -- )
c-funptr XARadioItf-GetFreqRange() {((struct XARadioItf_*)ptr)->GetFreqRange} a a -- u	( self pRange -- )
c-funptr XARadioItf-IsFreqRangeSupported() {((struct XARadioItf_*)ptr)->IsFreqRangeSupported} a u a -- u	( self range pSupported -- )
c-funptr XARadioItf-GetFreqRangeProperties() {((struct XARadioItf_*)ptr)->GetFreqRangeProperties} a u a a a -- u	( self range pMinFreq pMaxFreq pFreqInterval -- )
c-funptr XARadioItf-SetFrequency() {((struct XARadioItf_*)ptr)->SetFrequency} a u -- u	( self freq -- )
c-funptr XARadioItf-CancelSetFrequency() {((struct XARadioItf_*)ptr)->CancelSetFrequency} a -- u	( self -- )
c-funptr XARadioItf-GetFrequency() {((struct XARadioItf_*)ptr)->GetFrequency} a a -- u	( self pFreq -- )
c-funptr XARadioItf-SetSquelch() {((struct XARadioItf_*)ptr)->SetSquelch} a u -- u	( self squelch -- )
c-funptr XARadioItf-GetSquelch() {((struct XARadioItf_*)ptr)->GetSquelch} a a -- u	( self pSquelch -- )
c-funptr XARadioItf-SetStereoMode() {((struct XARadioItf_*)ptr)->SetStereoMode} a u -- u	( self mode -- )
c-funptr XARadioItf-GetStereoMode() {((struct XARadioItf_*)ptr)->GetStereoMode} a a -- u	( self pMode -- )
c-funptr XARadioItf-GetSignalStrength() {((struct XARadioItf_*)ptr)->GetSignalStrength} a a -- u	( self pStrength -- )
c-funptr XARadioItf-Seek() {((struct XARadioItf_*)ptr)->Seek} a u -- u	( self upwards -- )
c-funptr XARadioItf-StopSeeking() {((struct XARadioItf_*)ptr)->StopSeeking} a -- u	( self -- )
c-funptr XARadioItf-GetNumberOfPresets() {((struct XARadioItf_*)ptr)->GetNumberOfPresets} a a -- u	( self pNumPresets -- )
c-funptr XARadioItf-SetPreset() {((struct XARadioItf_*)ptr)->SetPreset} a u u u u a -- u	( self preset freq range mode pName -- )
c-funptr XARadioItf-GetPreset() {((struct XARadioItf_*)ptr)->GetPreset} a u a a a a a -- u	( self preset pFreq pRange pMode pName pNameLength -- )
c-funptr XARadioItf-RegisterRadioCallback() {((struct XARadioItf_*)ptr)->RegisterRadioCallback} a a a -- u	( self callback pContext -- )
c-funptr XARDSItf-QueryRDSSignal() {((struct XARDSItf_*)ptr)->QueryRDSSignal} a a -- u	( self isSignal -- )
c-funptr XARDSItf-GetProgrammeServiceName() {((struct XARDSItf_*)ptr)->GetProgrammeServiceName} a a -- u	( self ps -- )
c-funptr XARDSItf-GetRadioText() {((struct XARDSItf_*)ptr)->GetRadioText} a a -- u	( self rt -- )
c-funptr XARDSItf-GetRadioTextPlus() {((struct XARDSItf_*)ptr)->GetRadioTextPlus} a u a a a -- u	( self contentType informationElement descriptor descriptorContentType -- )
c-funptr XARDSItf-GetProgrammeType() {((struct XARDSItf_*)ptr)->GetProgrammeType} a a -- u	( self pty -- )
c-funptr XARDSItf-GetProgrammeTypeString() {((struct XARDSItf_*)ptr)->GetProgrammeTypeString} a u a -- u	( self isLengthMax16 pty -- )
c-funptr XARDSItf-GetProgrammeIdentificationCode() {((struct XARDSItf_*)ptr)->GetProgrammeIdentificationCode} a a -- u	( self pi -- )
c-funptr XARDSItf-GetClockTime() {((struct XARDSItf_*)ptr)->GetClockTime} a a -- u	( self dateAndTime -- )
c-funptr XARDSItf-GetTrafficAnnouncement() {((struct XARDSItf_*)ptr)->GetTrafficAnnouncement} a a -- u	( self ta -- )
c-funptr XARDSItf-GetTrafficProgramme() {((struct XARDSItf_*)ptr)->GetTrafficProgramme} a a -- u	( self tp -- )
c-funptr XARDSItf-SeekByProgrammeType() {((struct XARDSItf_*)ptr)->SeekByProgrammeType} a u u -- u	( self pty upwards -- )
c-funptr XARDSItf-SeekTrafficAnnouncement() {((struct XARDSItf_*)ptr)->SeekTrafficAnnouncement} a u -- u	( self upwards -- )
c-funptr XARDSItf-SeekTrafficProgramme() {((struct XARDSItf_*)ptr)->SeekTrafficProgramme} a u -- u	( self upwards -- )
c-funptr XARDSItf-SetAutomaticSwitching() {((struct XARDSItf_*)ptr)->SetAutomaticSwitching} a u -- u	( self automatic -- )
c-funptr XARDSItf-GetAutomaticSwitching() {((struct XARDSItf_*)ptr)->GetAutomaticSwitching} a a -- u	( self automatic -- )
c-funptr XARDSItf-SetAutomaticTrafficAnnouncement() {((struct XARDSItf_*)ptr)->SetAutomaticTrafficAnnouncement} a u -- u	( self automatic -- )
c-funptr XARDSItf-GetAutomaticTrafficAnnouncement() {((struct XARDSItf_*)ptr)->GetAutomaticTrafficAnnouncement} a a -- u	( self automatic -- )
c-funptr XARDSItf-GetODAGroup() {((struct XARDSItf_*)ptr)->GetODAGroup} a u a a -- u	( self AID callback pContext -- )
c-funptr XARDSItf-SubscribeODAGroup() {((struct XARDSItf_*)ptr)->SubscribeODAGroup} a n u -- u	( self group useErrorCorrection -- )
c-funptr XARDSItf-UnsubscribeODAGroup() {((struct XARDSItf_*)ptr)->UnsubscribeODAGroup} a n -- u	( self group -- )
c-funptr XARDSItf-ListODAGroupSubscriptions() {((struct XARDSItf_*)ptr)->ListODAGroupSubscriptions} a a a -- u	( self pGroups pLength -- )
c-funptr XARDSItf-RegisterRDSCallback() {((struct XARDSItf_*)ptr)->RegisterRDSCallback} a a a -- u	( self callback pContext -- )
c-funptr XARDSItf-RegisterODADataCallback() {((struct XARDSItf_*)ptr)->RegisterODADataCallback} a a a -- u	( self callback pContext -- )
c-funptr XAVibraItf-Vibrate() {((struct XAVibraItf_*)ptr)->Vibrate} a u -- u	( self vibrate -- )
c-funptr XAVibraItf-IsVibrating() {((struct XAVibraItf_*)ptr)->IsVibrating} a a -- u	( self pVibrating -- )
c-funptr XAVibraItf-SetFrequency() {((struct XAVibraItf_*)ptr)->SetFrequency} a u -- u	( self frequency -- )
c-funptr XAVibraItf-GetFrequency() {((struct XAVibraItf_*)ptr)->GetFrequency} a a -- u	( self pFrequency -- )
c-funptr XAVibraItf-SetIntensity() {((struct XAVibraItf_*)ptr)->SetIntensity} a n -- u	( self intensity -- )
c-funptr XAVibraItf-GetIntensity() {((struct XAVibraItf_*)ptr)->GetIntensity} a a -- u	( self pIntensity -- )
c-funptr XALEDArrayItf-ActivateLEDArray() {((struct XALEDArrayItf_*)ptr)->ActivateLEDArray} a u -- u	( self lightMask -- )
c-funptr XALEDArrayItf-IsLEDArrayActivated() {((struct XALEDArrayItf_*)ptr)->IsLEDArrayActivated} a a -- u	( self pLightMask -- )
c-funptr XALEDArrayItf-SetColor() {((struct XALEDArrayItf_*)ptr)->SetColor} a u a -- u	( self index pColor -- )
c-funptr XALEDArrayItf-GetColor() {((struct XALEDArrayItf_*)ptr)->GetColor} a u a -- u	( self index pColor -- )
c-funptr XAAudioDecoderCapabilitiesItf-GetAudioDecoders() {((struct XAAudioDecoderCapabilitiesItf_*)ptr)->GetAudioDecoders} a a a -- u	( self pNumDecoders pDecoderIds -- )
c-funptr XAAudioDecoderCapabilitiesItf-GetAudioDecoderCapabilities() {((struct XAAudioDecoderCapabilitiesItf_*)ptr)->GetAudioDecoderCapabilities} a u a a -- u	( self decoderId pIndex pDescriptor -- )
c-funptr XAAudioEncoderItf-SetEncoderSettings() {((struct XAAudioEncoderItf_*)ptr)->SetEncoderSettings} a a -- u	( self pSettings -- )
c-funptr XAAudioEncoderItf-GetEncoderSettings() {((struct XAAudioEncoderItf_*)ptr)->GetEncoderSettings} a a -- u	( self pSettings -- )
c-funptr XAAudioEncoderCapabilitiesItf-GetAudioEncoders() {((struct XAAudioEncoderCapabilitiesItf_*)ptr)->GetAudioEncoders} a a a -- u	( self pNumEncoders pEncoderIds -- )
c-funptr XAAudioEncoderCapabilitiesItf-GetAudioEncoderCapabilities() {((struct XAAudioEncoderCapabilitiesItf_*)ptr)->GetAudioEncoderCapabilities} a u a a -- u	( self encoderId pIndex pDescriptor -- )
c-funptr XAImageEncoderCapabilitiesItf-GetImageEncoderCapabilities() {((struct XAImageEncoderCapabilitiesItf_*)ptr)->GetImageEncoderCapabilities} a a a -- u	( self pEncoderId pDescriptor -- )
c-funptr XAImageEncoderCapabilitiesItf-QueryColorFormats() {((struct XAImageEncoderCapabilitiesItf_*)ptr)->QueryColorFormats} a a a -- u	( self pIndex pColorFormat -- )
c-funptr XAImageDecoderCapabilitiesItf-GetImageDecoderCapabilities() {((struct XAImageDecoderCapabilitiesItf_*)ptr)->GetImageDecoderCapabilities} a a a -- u	( self pDecoderId pDescriptor -- )
c-funptr XAImageDecoderCapabilitiesItf-QueryColorFormats() {((struct XAImageDecoderCapabilitiesItf_*)ptr)->QueryColorFormats} a a a -- u	( self pIndex pColorFormat -- )
c-funptr XAImageEncoderItf-SetImageSettings() {((struct XAImageEncoderItf_*)ptr)->SetImageSettings} a a -- u	( self pSettings -- )
c-funptr XAImageEncoderItf-GetImageSettings() {((struct XAImageEncoderItf_*)ptr)->GetImageSettings} a a -- u	( self pSettings -- )
c-funptr XAImageEncoderItf-GetSizeEstimate() {((struct XAImageEncoderItf_*)ptr)->GetSizeEstimate} a a -- u	( self pSize -- )
c-funptr XAVideoDecoderCapabilitiesItf-GetVideoDecoders() {((struct XAVideoDecoderCapabilitiesItf_*)ptr)->GetVideoDecoders} a a a -- u	( self pNumDecoders pDecoderIds -- )
c-funptr XAVideoDecoderCapabilitiesItf-GetVideoDecoderCapabilities() {((struct XAVideoDecoderCapabilitiesItf_*)ptr)->GetVideoDecoderCapabilities} a u a a -- u	( self decoderId pIndex pDescriptor -- )
c-funptr XAVideoEncoderCapabilitiesItf-GetVideoEncoders() {((struct XAVideoEncoderCapabilitiesItf_*)ptr)->GetVideoEncoders} a a a -- u	( self pNumEncoders pEncoderIds -- )
c-funptr XAVideoEncoderCapabilitiesItf-GetVideoEncoderCapabilities() {((struct XAVideoEncoderCapabilitiesItf_*)ptr)->GetVideoEncoderCapabilities} a u a a -- u	( self encoderId pIndex pDescriptor -- )
c-funptr XAVideoEncoderItf-SetVideoSettings() {((struct XAVideoEncoderItf_*)ptr)->SetVideoSettings} a a -- u	( self pSettings -- )
c-funptr XAVideoEncoderItf-GetVideoSettings() {((struct XAVideoEncoderItf_*)ptr)->GetVideoSettings} a a -- u	( self pSettings -- )
c-funptr XAStreamInformationItf-QueryMediaContainerInformation() {((struct XAStreamInformationItf_*)ptr)->QueryMediaContainerInformation} a a -- u	( self info -- )
c-funptr XAStreamInformationItf-QueryStreamType() {((struct XAStreamInformationItf_*)ptr)->QueryStreamType} a u a -- u	( self streamIndex domain -- )
c-funptr XAStreamInformationItf-QueryStreamInformation() {((struct XAStreamInformationItf_*)ptr)->QueryStreamInformation} a u a -- u	( self streamIndex info -- )
c-funptr XAStreamInformationItf-QueryStreamName() {((struct XAStreamInformationItf_*)ptr)->QueryStreamName} a u a a -- u	( self streamIndex pNameSize pName -- )
c-funptr XAStreamInformationItf-RegisterStreamChangeCallback() {((struct XAStreamInformationItf_*)ptr)->RegisterStreamChangeCallback} a a a -- u	( self callback pContext -- )
c-funptr XAStreamInformationItf-QueryActiveStreams() {((struct XAStreamInformationItf_*)ptr)->QueryActiveStreams} a a a -- u	( self numStreams activeStreams -- )
c-funptr XAStreamInformationItf-SetActiveStream() {((struct XAStreamInformationItf_*)ptr)->SetActiveStream} a u u u -- u	( self streamNum active commitNow -- )
c-funptr XAAndroidBufferQueueItf-RegisterCallback() {((struct XAAndroidBufferQueueItf_*)ptr)->RegisterCallback} a a a -- u	( self callback pCallbackContext -- )
c-funptr XAAndroidBufferQueueItf-Clear() {((struct XAAndroidBufferQueueItf_*)ptr)->Clear} a -- u	( self -- )
c-funptr XAAndroidBufferQueueItf-Enqueue() {((struct XAAndroidBufferQueueItf_*)ptr)->Enqueue} a a a u a u -- u	( self pBufferContext pData dataLength pItems itemsLength -- )
c-funptr XAAndroidBufferQueueItf-GetState() {((struct XAAndroidBufferQueueItf_*)ptr)->GetState} a a -- u	( self pState -- )
c-funptr XAAndroidBufferQueueItf-SetCallbackEventsMask() {((struct XAAndroidBufferQueueItf_*)ptr)->SetCallbackEventsMask} a u -- u	( self eventFlags -- )
c-funptr XAAndroidBufferQueueItf-GetCallbackEventsMask() {((struct XAAndroidBufferQueueItf_*)ptr)->GetCallbackEventsMask} a a -- u	( self pEventFlags -- )

\ ------===< callbacks >===-------
c-callback xaObjectCallback: a a u u u a -- void	( caller pContext event result param pInterface -- )
c-callback xaDynamicInterfaceManagementCallback: a a u u a -- void	( caller pContext event result iid -- )
c-callback xaPlayCallback: a a u -- void	( caller pContext event -- )
c-callback xaPrefetchCallback: a a u -- void	( caller pContext event -- )
c-callback xaRecordCallback: a a u -- void	( caller pContext event -- )
c-callback xaSnapshotInitiatedCallback: a a -- void	( caller context -- )
c-callback xaSnapshotTakenCallback: a a u a -- void	( caller context numberOfPicsTaken image -- )
c-callback xaMetadataInsertionCallback: a a a a n u -- void	( caller pContext pKey pValue nodeID result -- )
c-callback xaCameraCallback: a a u u -- void	( caller pContext eventId eventData -- )
c-callback xaAvailableAudioInputsChangedCallback: a a u n u -- void	( caller pContext deviceID numInputs isNew -- )
c-callback xaAvailableAudioOutputsChangedCallback: a a u n u -- void	( caller pContext deviceID numOutputs isNew -- )
c-callback xaDefaultDeviceIDMapChangedCallback: a a u n -- void	( caller pContext isOutput numDevices -- )
c-callback xaMixDeviceChangeCallback: a a -- void	( caller pContext -- )
c-callback xaRadioCallback: a a u u u -- void	( caller pContext event eventIntData eventBooleanData -- )
c-callback xaGetODAGroupCallback: a a u n u -- void	( caller pContext success group message -- )
c-callback xaNewODADataCallback: a a n ud -- void	( caller pContext group data -- )
c-callback xaRDSCallback: a a u u -- void	( caller pContext event eventData -- )
c-callback xaStreamEventChangeCallback: a u u a a -- void	( caller eventId streamIndex pEventData pContext -- )
c-callback xaAndroidBufferQueueCallback: a a a a u u a u -- u	( caller pCallbackContext pBufferContext pBufferData dataSize dataUsed pItems itemsLength -- )

\ ------===< functions >===-------
c-function xaCreateEngine xaCreateEngine a u a u a a -- u	( pEngine numOptions pEngineOptions numInterfaces pInterfaceIds pInterfaceRequired -- )
c-function xaQueryNumSupportedEngineInterfaces xaQueryNumSupportedEngineInterfaces a -- u	( pNumSupportedInterfaces -- )
c-function xaQuerySupportedEngineInterfaces xaQuerySupportedEngineInterfaces u a -- u	( index pInterfaceId -- )
