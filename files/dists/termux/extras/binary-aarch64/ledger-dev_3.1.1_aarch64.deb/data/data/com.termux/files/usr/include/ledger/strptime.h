#ifndef STRPTIME_H
#define STRPTIME_H

char* strptime(const char *buf, const char *fmt, struct tm *tm);

#endif