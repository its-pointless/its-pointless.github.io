p(a).
%%%%%%%%%%%%%%%%
:- thread_local p/1.
