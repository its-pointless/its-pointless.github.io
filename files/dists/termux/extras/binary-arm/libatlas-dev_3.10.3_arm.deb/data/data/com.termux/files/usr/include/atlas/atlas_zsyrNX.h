#ifndef ATLAS_ZSYR_H
   #define ATLAS_ZSYR_H
   #define ATL_S1NX 1880
#endif
