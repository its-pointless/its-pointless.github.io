#ifndef ATL_CSYSINFO_H
   #define ATL_CSYSINFO_H

#define ATL_MULADD
#define ATL_L1elts 1024
#define ATL_fplat  3
#define ATL_lbnreg 16
#define ATL_mmnreg 32
#define ATL_nkflop 1969773

#endif
