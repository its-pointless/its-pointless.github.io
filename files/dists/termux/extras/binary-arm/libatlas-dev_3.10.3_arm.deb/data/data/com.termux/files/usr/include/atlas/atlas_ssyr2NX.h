#ifndef ATLAS_SSYR2_H
   #define ATLAS_SSYR2_H
   #define ATL_S2NX 0
#endif
