#ifndef ZXOVER_H
#define ZXOVER_H

#define ATL_3NB 96
#define NN_MNK_M 28800
#define NN_MNK_N 28800
#define NN_MNK_MN 15360
#define NN_MNK_K 28800
#define NN_MNK_GE 27000
#define NT_MNK_M 28800
#define NT_MNK_N 7200
#define NT_MNK_MN 10240
#define NT_MNK_K 28800
#define NT_MNK_GE 27000
#define TN_MNK_M 28800
#define TN_MNK_N 7200
#define TN_MNK_MN 15360
#define TN_MNK_K 28800
#define TN_MNK_GE 3375
#define TT_MNK_M 28800
#define TT_MNK_N 7200
#define TT_MNK_MN 488448
#define TT_MNK_K 28800
#define TT_MNK_GE 27000
#define C2R_K 4450

#endif
