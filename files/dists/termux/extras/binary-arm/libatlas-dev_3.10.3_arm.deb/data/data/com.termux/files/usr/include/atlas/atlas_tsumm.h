#ifndef ATLAS_SUMM_H
   #define ATLAS_SUMM_H
#define ATL_TAFFINITY 0
#define ATL_ATOMIC_COUNT_MUT 1
#endif
