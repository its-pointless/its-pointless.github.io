#ifndef CXOVER_H
#define CXOVER_H

#define ATL_3NB 120
#define NN_MNK_M 23040
#define NN_MNK_N 88360
#define NN_MNK_MN 75200
#define NN_MNK_K 23040
#define NN_MNK_GE 103823
#define NT_MNK_M 88360
#define NT_MNK_N 88360
#define NT_MNK_MN 75200
#define NT_MNK_K 23040
#define NT_MNK_GE 103823
#define TN_MNK_M 23040
#define TN_MNK_N 23040
#define TN_MNK_MN 38400
#define TN_MNK_K 9000
#define TN_MNK_GE 13824
#define TT_MNK_M 88360
#define TT_MNK_N 23040
#define TT_MNK_MN 38400
#define TT_MNK_K 23040
#define TT_MNK_GE 13824
#define C2R_K 2147483647

#endif
