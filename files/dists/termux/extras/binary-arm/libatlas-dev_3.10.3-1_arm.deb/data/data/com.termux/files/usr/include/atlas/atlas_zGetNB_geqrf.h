#ifndef ATL_zGetNB_geqrf

/*
 * NB selection for GEQRF: Side='RIGHT', Uplo='UPPER'
 * M : 25,96,224,320,384,448,928
 * N : 25,96,224,320,384,448,928
 * NB : 1,40,24,20,32,32,32
 */
#define ATL_zGetNB_geqrf(n_, nb_) \
{ \
   if ((n_) < 60) (nb_) = 1; \
   else if ((n_) < 160) (nb_) = 40; \
   else if ((n_) < 272) (nb_) = 24; \
   else if ((n_) < 352) (nb_) = 20; \
   else (nb_) = 32; \
}


#endif    /* end ifndef ATL_zGetNB_geqrf */
