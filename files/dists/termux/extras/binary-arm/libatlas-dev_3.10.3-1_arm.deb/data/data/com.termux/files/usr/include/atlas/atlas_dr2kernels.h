/*
 * This file generated on line 754 of /data/data/com.termux/files/home/ATLAS//tune/blas/ger/r2hgen.c
 */
#ifndef ATLAS_DR2KERNELS_H
   #define ATLAS_DR2KERNELS_H

void ATL_dger2k__900001
   (ATL_CINT, ATL_CINT, const double*, const double*, const double*,
    const double*, double*, ATL_CINT);
void ATL_dger2k__900003
   (ATL_CINT, ATL_CINT, const double*, const double*, const double*,
    const double*, double*, ATL_CINT);
void ATL_dger2k__900002
   (ATL_CINT, ATL_CINT, const double*, const double*, const double*,
    const double*, double*, ATL_CINT);
void ATL_dger2k__900001
   (ATL_CINT, ATL_CINT, const double*, const double*, const double*,
    const double*, double*, ATL_CINT);


#endif /* end guard around atlas_dr2kernels.h */
