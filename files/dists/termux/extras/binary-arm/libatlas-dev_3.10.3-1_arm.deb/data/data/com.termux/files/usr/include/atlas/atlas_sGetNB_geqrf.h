#ifndef ATL_sGetNB_geqrf

/*
 * NB selection for GEQRF: Side='RIGHT', Uplo='UPPER'
 * M : 25,192,448,896,1344,1792
 * N : 25,192,448,896,1344,1792
 * NB : 12,64,32,32,64,64
 */
#define ATL_sGetNB_geqrf(n_, nb_) \
{ \
   if ((n_) < 108) (nb_) = 12; \
   else if ((n_) < 320) (nb_) = 64; \
   else if ((n_) < 1120) (nb_) = 32; \
   else (nb_) = 64; \
}


#endif    /* end ifndef ATL_sGetNB_geqrf */
