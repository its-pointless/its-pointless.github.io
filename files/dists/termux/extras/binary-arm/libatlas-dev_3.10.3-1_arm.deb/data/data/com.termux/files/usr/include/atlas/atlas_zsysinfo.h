#ifndef ATL_ZSYSINFO_H
   #define ATL_ZSYSINFO_H

#define ATL_MULADD
#define ATL_L1elts 2048
#define ATL_fplat  3
#define ATL_lbnreg 32
#define ATL_mmnreg 32
#define ATL_nkflop 1867882

#endif
