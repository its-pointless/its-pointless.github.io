/*
 * This file generated on line 730 of /data/data/com.termux/files/home/ATLAS//tune/blas/ger/r1hgen.c
 */
#ifndef ATLAS_ZR1KERNELS_H
   #define ATLAS_ZR1KERNELS_H

void ATL_zgerk__2
   (ATL_CINT, ATL_CINT, const double*, const double*, double*, ATL_CINT);
void ATL_zgerk__900003
   (ATL_CINT, ATL_CINT, const double*, const double*, double*, ATL_CINT);
void ATL_zgerk__900001
   (ATL_CINT, ATL_CINT, const double*, const double*, double*, ATL_CINT);
void ATL_zgerk__2
   (ATL_CINT, ATL_CINT, const double*, const double*, double*, ATL_CINT);


#endif /* end guard around atlas_zr1kernels.h */
