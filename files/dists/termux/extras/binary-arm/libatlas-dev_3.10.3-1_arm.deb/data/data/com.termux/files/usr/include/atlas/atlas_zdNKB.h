#ifndef ATLAS_ZDNKB_H
   #define ATLAS_ZDNKB_H
   #define ATL_ZDNKB 0
#endif
