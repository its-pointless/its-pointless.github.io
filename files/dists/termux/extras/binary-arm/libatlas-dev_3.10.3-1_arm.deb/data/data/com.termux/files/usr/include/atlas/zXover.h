#ifndef ZXOVER_H
#define ZXOVER_H

#define ATL_3NB 96
#define NN_MNK_M 70688
#define NN_MNK_N 18432
#define NN_MNK_MN 48128
#define NN_MNK_K 18432
#define NN_MNK_GE 103823
#define NT_MNK_M 70688
#define NT_MNK_N 18432
#define NT_MNK_MN 48128
#define NT_MNK_K 18432
#define NT_MNK_GE 54872
#define TN_MNK_M 70688
#define TN_MNK_N 70688
#define TN_MNK_MN 48128
#define TN_MNK_K 46208
#define TN_MNK_GE 103823
#define TT_MNK_M 70688
#define TT_MNK_N 46208
#define TT_MNK_MN 48128
#define TT_MNK_K 18432
#define TT_MNK_GE 103823
#define C2R_K 2147483647

#endif
